#!/usr/bin/env python3
"""AI7 Fractal Energy Forge runner v0.1.

Local-first scanner/scorer for AI7-FEF artifacts.
It does not deploy hardware or make autonomous irreversible changes.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable

KEYWORDS = {
    "dct": 2.0,
    "safety": 2.0,
    "rollback": 1.5,
    "ledger": 1.5,
    "rlc": 1.4,
    "twin": 1.3,
    "omega": 1.1,
    "bot": 1.0,
    "test": 1.7,
    "risk": 1.4,
    "equation": 1.2,
    "canon": 1.2,
    "repair": 1.1,
}

RISK_WORDS = {
    "weapon": 5.0,
    "harm": 4.0,
    "bypass": 3.0,
    "disable safety": 5.0,
    "high voltage": 2.0,
    "uncontrolled": 2.0,
    "no rollback": 3.0,
}

@dataclass
class ArtifactScore:
    path: str
    sha256: str
    bytes: int
    canon_score: float
    risk_score: float
    verdict: str
    signals: dict


def iter_files(root: Path) -> Iterable[Path]:
    for path in root.rglob("*"):
        if path.is_file() and path.suffix.lower() in {".md", ".txt", ".yaml", ".yml", ".json", ".py"}:
            yield path


def read_text(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        return path.read_text(encoding="latin-1", errors="ignore")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def score_text(text: str) -> tuple[float, float, dict]:
    lower = text.lower()
    signals = {}
    canon = 0.0
    for key, weight in KEYWORDS.items():
        count = lower.count(key)
        if count:
            signals[key] = count
            canon += min(count, 5) * weight
    risk = 0.0
    risk_signals = {}
    for key, weight in RISK_WORDS.items():
        count = lower.count(key)
        if count:
            risk_signals[key] = count
            risk += min(count, 3) * weight
    length_factor = min(len(text) / 4000.0, 1.0)
    canon = round((canon / 30.0 + length_factor * 0.2), 4)
    risk = round(risk / 15.0, 4)
    signals["risk_terms"] = risk_signals
    return canon, risk, signals


def verdict(canon: float, risk: float) -> str:
    if risk >= 0.7:
        return "blocked_review"
    if canon >= 0.7 and risk < 0.4:
        return "crystallizable"
    if canon >= 0.35:
        return "watch"
    return "exploratory"


def scan(root: Path) -> list[ArtifactScore]:
    results = []
    for path in iter_files(root):
        data = path.read_bytes()
        text = read_text(path)
        canon, risk, signals = score_text(text)
        results.append(ArtifactScore(
            path=str(path.relative_to(root)),
            sha256=sha256_bytes(data),
            bytes=len(data),
            canon_score=canon,
            risk_score=risk,
            verdict=verdict(canon, risk),
            signals=signals,
        ))
    return sorted(results, key=lambda x: (x.verdict, -x.canon_score, x.risk_score, x.path))


def summarize(results: list[ArtifactScore]) -> dict:
    counts = {}
    for item in results:
        counts[item.verdict] = counts.get(item.verdict, 0) + 1
    return {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "total": len(results),
        "counts": counts,
        "top_crystallizable": [asdict(x) for x in results if x.verdict == "crystallizable"][:10],
        "blocked_review": [asdict(x) for x in results if x.verdict == "blocked_review"][:10],
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", required=True, help="Source folder to scan")
    parser.add_argument("--out", default="reports/latest_run.json", help="Output JSON path")
    args = parser.parse_args()

    root = Path(args.source).resolve()
    if not root.exists() or not root.is_dir():
        raise SystemExit(f"Source is not a directory: {root}")

    results = scan(root)
    report = {
        "summary": summarize(results),
        "artifacts": [asdict(x) for x in results],
        "note": "This runner is advisory. It does not deploy, modify hardware, or bypass safety gates.",
    }
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(report["summary"], indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
