"""AI7 Fractal Energy Forge package skeleton."""
__version__ = "0.1.0"
