from __future__ import annotations

def energy_power(output: float, efficiency: float, resilience: float, repairability: float, learning_rate: float, reusability: float, risk: float, waste: float, complexity: float, failure_propagation: float) -> float:
    numerator = output * efficiency * resilience * repairability * learning_rate * reusability
    denominator = 1.0 + risk + waste + complexity + failure_propagation
    return numerator / denominator

def tid_score(p_useful: float, pf: float, eta: float, i_gain: float, stability: float, safety: float, p_loss: float, p_thermal: float, thermal_risk: float, noise: float, uncertainty: float, complexity: float) -> float:
    numerator = p_useful * pf * eta * i_gain * stability * safety
    denominator = 1.0 + p_loss + p_thermal + thermal_risk + noise + uncertainty + complexity
    return numerator / denominator
