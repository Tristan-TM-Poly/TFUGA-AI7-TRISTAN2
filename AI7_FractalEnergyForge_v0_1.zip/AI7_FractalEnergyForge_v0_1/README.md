# AI7 Fractal Energy Forge v0.1

AI7 Fractal Energy Forge is a safe, reusable, local-first architecture for designing, scoring, simulating, documenting, and governing low-power AI-7 fractal energy prototypes.

It combines:

- Fractal energy plant architecture
- RLC-kT fractal-mycelial circuit models
- TC-nPCI-kE topology family
- Digital Twin 4D/8D+ specification
- AI-Bot permission matrix
- DCT: Document + Calculation/Code + Test
- SafetyGate and LedgerStack
- Omega Energy Plaza dashboard specification

## Prime directive

Generate broadly. Simulate before building. Test at low power. Protect always. Promote slowly. Reuse massively.

## Hard safety line

This repository is for safe energy quality, filtering, sensing, diagnostics, stability, education, and low-power prototyping. It is not for harmful directed energy, weaponization, bypassing protections, or unsafe high-power scaling.

## Quick run

```bash
python runner/ai7_fef_runner.py --source . --out reports/latest_run.json
```

## Folder map

```text
equations/   analytical equations and scoring models
configs/     YAML safety gates and bot permissions
templates/   DCT and card templates
specs/       digital twin and dashboard specifications
runner/      local runner prototype
ledger/      JSON schemas for change, incident, repair and canon records
roadmap/     iteration plan
reports/     generated outputs
src/         Python package skeleton
```

## Status

v0.1 is a scaffold and governance kernel. It is designed to become the seed for a local runner on a personal PC, not an autonomous uncontrolled system.
