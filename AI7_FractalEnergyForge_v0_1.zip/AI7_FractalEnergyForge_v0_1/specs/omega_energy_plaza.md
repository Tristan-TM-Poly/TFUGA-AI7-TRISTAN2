# Omega Energy Plaza Specification v0.1

Omega Energy Plaza is the cockpit for AI7-FractalEnergyForge.

## Required panels

1. Production
2. Storage
3. SOC and SOH
4. Critical loads
5. Flexible loads
6. RLC modes
7. Thermal status
8. SafetyGate status
9. Active bots
10. DCT status
11. Ledger events
12. Maintenance and repair
13. Recycling/circularity
14. Next action

## Global score

\[
EnergyPower=\frac{Output\cdot Efficiency\cdot Resilience\cdot Repairability\cdot LearningRate\cdot Reusability}{1+Risk+Waste+Complexity+FailurePropagation}
\]

## Action states

- observe
- simulate
- low_power_test
- repair
- optimize
- block
- promote_candidate
- canon_review

## Non-negotiable display

SafetyGate must always be visible.
