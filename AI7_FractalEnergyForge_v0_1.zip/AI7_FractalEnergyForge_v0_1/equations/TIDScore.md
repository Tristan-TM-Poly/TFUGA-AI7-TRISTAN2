# Thermo-Info-Dynamic Score v0.1

Useful electrical output:

\[
P_{useful}=\langle v_{load}(t)i_{load}(t)\rangle
\]

Power factor:

\[
PF=\cos\phi=\frac{P}{V_{rms}I_{rms}}
\]

Efficiency:

\[
\eta=\frac{P_{useful}}{P_{source}}
\]

Information gain:

\[
I_{gain}=H(Prior)-H(Posterior)
\]

Thermal loss:

\[
P_{th}=\sum_i I_i^2R_i
\]

Score:

\[
TIDScore=\frac{P_{useful}\cdot PF\cdot \eta\cdot I_{gain}\cdot Stability\cdot Safety}{1+P_{loss}+P_{thermal}+ThermalRisk+Noise+ModelUncertainty+Complexity}
\]

Interpretation: maximize useful energy, useful information, stability, and safety while minimizing losses, heat, noise, uncertainty, and unnecessary complexity.
