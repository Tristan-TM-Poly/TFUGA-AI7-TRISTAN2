# RLC-kT Fractal-Mycelial Circuit Model v0.1

## Hypergraph definition

\[
\mathcal{H}_{RLC}=(V,E_R,E_L,E_C,E_M,E_T,E_S,E_{ctrl})
\]

- \(E_R\): resistive bridges
- \(E_L\): inductive bridges
- \(E_C\): capacitive bridges
- \(E_M\): magnetic mutual couplings
- \(E_T\): transformer couplings
- \(E_S\): safety/isolation/fuses
- \(E_{ctrl}\): measurement and control links

## Second-order model

\[
\mathbf{M}\ddot q+\mathbf{R}\dot q+\mathbf{K}q=u(t)
\]

where \(\mathbf{M}\sim L_{eff}\) and \(\mathbf{K}\sim C_{eff}^{-1}\).

In harmonic regime:

\[
(-\omega^2\mathbf{M}+i\omega\mathbf{R}+\mathbf{K})\hat q=\hat u
\]

Resonances:

\[
\det(-\omega^2\mathbf{M}+i\omega\mathbf{R}+\mathbf{K})=0
\]

Outputs:

\[
\{\omega_j,f_j,Q_j,\psi_j,Loss_j,Risk_j\}_{j=1}^{m}
\]

## Solenoid-on-solenoid recursion

\[
\mathcal{S}_{n+1}=Embed_{\gamma_n}(\mathcal{S}_n)
\]

\[
L_{n+1}=\alpha_nL_n+\beta_nM_n+L_{bridge,n}
\]

\[
C_{n+1}=a_nC_n,\qquad R_{n+1}=b_nR_n
\]

\[
M_{ij}=k_{ij}\sqrt{L_iL_j}
\]

\[
\omega_{0,n}=\frac{1}{\sqrt{L_nC_n}}
\]

If:

\[
L_n=L_0\lambda_L^n,\qquad C_n=C_0\lambda_C^n
\]

then:

\[
\omega_{0,n}=\omega_{0,0}(\lambda_L\lambda_C)^{-n/2}
\]

## Mode score

\[
ModeScore_j=\frac{Q_j^{useful}\,Selectivity_j\,Stability_j\,Measurability_j\,Safety_j}{1+Loss_j+ThermalDrift_j+ParasiticCoupling_j+Complexity_j}
\]

A mode is promotable only if it improves measurement, filtering, stability, or diagnostics.
