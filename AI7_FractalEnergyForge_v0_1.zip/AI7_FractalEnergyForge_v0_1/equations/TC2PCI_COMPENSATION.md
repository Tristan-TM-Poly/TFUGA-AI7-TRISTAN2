# TC-2PCI Reactive Compensation Module v0.1

Goal: make the source see a mostly resistive input at the target frequency, without claiming free power or unsafe behavior.

## Input admittance

\[
Y_{in}(\omega)=Y_{pri}(\omega)+Y_{comp}(\omega)
\]

\[
Y_{pri}=G_{pri}+iB_{pri}
\]

Secondary RLC branch:

\[
Z_{sec}(\omega)=R_s+iX_s(\omega)
\]

\[
X_s(\omega)=\omega L_s-\frac{1}{\omega C_s}
\]

Transformer reflection factor:

\[
n=\frac{Z_{ref}}{Z_{sec}}=\frac{1}{\mu^2},\qquad \mu=\frac{N_s}{N_p}
\]

\[
Z_{comp}=nZ_{sec}
\]

\[
Y_{comp}=\frac{1}{n}\frac{R_s-iX_s}{R_s^2+X_s^2}
\]

Thus:

\[
G_{in}=G_{pri}+\frac{1}{n}\frac{R_s}{R_s^2+X_s^2}
\]

\[
B_{in}=B_{pri}-\frac{1}{n}\frac{X_s}{R_s^2+X_s^2}
\]

Purely resistive source condition:

\[
B_{in}(\omega)=0
\]

\[
B_{pri}(\omega)=\frac{1}{n}\frac{X_s(\omega)}{R_s^2+X_s^2(\omega)}
\]

Equivalent source resistance:

\[
R_{eq,src}=\frac{1}{G_{in}}
\]

## Optimization

\[
\min_\theta\left[w_BB_{in}^2+w_RR_{eq,src}+w_LL_{loss}+w_TT_{risk}+w_Q(Q-Q_{target})^2\right]
\]

subject to:

\[
I<I_{max},\quad V_C<V_{C,max},\quad V_L<V_{L,max},\quad T<T_{max},\quad Q<Q_{max}
\]

## Physical constraint

A passive network can cancel susceptance, but it cannot create real low input resistance without real dissipation or real power transfer.
