# TC-nPCI-kE Canonical Definition v0.1

TC-nPCI-kE means:

Transformateurs-Couplés, n_phase + GND, Ponts-Capacitifs-Interconnectés, k_Etage.

## Indexed nodes

\[
(i,j),\qquad i\in\{1,\dots,n\},\quad j\in\{1,\dots,k\}
\]

with \(i\) phase and \(j\) stage.

State variables:

\[
v_{i,j}(t),\quad i_{i,j}(t),\quad \phi_{i,j}(t),\quad q_{i,j}(t)
\]

## Matrix model

The full RLC model uses:

\[
\mathbf{C},\quad \mathbf{G},\quad \mathbf{L},\quad \mathbf{R},\quad \mathbf{K}
\]

First-order state equations:

\[
\mathbf{C}\dot{\mathbf v}+\mathbf{G}\mathbf v+\mathbf{K}^\top\mathbf i=\mathbf{B}_Iu(t)
\]

\[
\mathbf{L}\dot{\mathbf i}+\mathbf{R}\mathbf i-\mathbf K\mathbf v=\mathbf{B}_Vu(t)
\]

State form:

\[
\mathbf x=\begin{bmatrix}\mathbf v\\\mathbf i\end{bmatrix}
\]

\[
\dot{\mathbf x}=\mathbf A\mathbf x+\mathbf B u
\]

\[
\mathbf A=\begin{bmatrix}
-\mathbf C^{-1}\mathbf G & -\mathbf C^{-1}\mathbf K^\top\\
\mathbf L^{-1}\mathbf K & -\mathbf L^{-1}\mathbf R
\end{bmatrix}
\]

## Modal analysis

\[
\mathbf A\mathbf p_r=\lambda_r\mathbf p_r
\]

\[
\lambda_r=-\sigma_r+j\omega_{d,r}
\]

Safe design requires \(\sigma_r>0\) for damped modes.
