# Axiom Dashboard v0.6

## Promotion
promoted

## Global score
5.82

## Passed
14

## Failed
0

## Canon guard
passed
