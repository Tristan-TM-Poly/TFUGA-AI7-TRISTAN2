pub fn axiom_add(a: i32, b: i32) -> i32 { a + b }
#[cfg(test)]
mod tests { use super::*; #[test] fn adds(){ assert_eq!(axiom_add(2,3),5); } }
