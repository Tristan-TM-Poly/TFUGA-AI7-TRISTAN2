#include "axiom_core.h"
int axiom_add(int a, int b){ return a + b; }
