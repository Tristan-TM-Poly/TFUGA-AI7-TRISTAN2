#include <stdio.h>
#include "axiom_core.h"
int main(void){ if(axiom_add(2,3)!=5) return 1; puts("c:ok"); return 0; }
