#include <stdio.h>
int main(void){ puts("c-main:ok"); return 0; }
