#ifndef AXIOM_CORE_H
#define AXIOM_CORE_H
int axiom_add(int a, int b);
#endif
