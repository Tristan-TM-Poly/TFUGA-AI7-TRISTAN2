using AxiomCore;
Console.WriteLine(Core.Add(2,3) == 5 ? "csharp:ok" : "csharp:fail");
