namespace AxiomCore;
public static class Core { public static int Add(int a, int b) => a + b; }
