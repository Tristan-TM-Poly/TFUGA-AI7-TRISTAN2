# FFI Plan

v0.4 keeps FFI as a clean interface contract:
- C exports minimal stable ABI.
- C++ wraps richer systems but exposes C-compatible boundaries.
- Rust can call C ABI or expose cdylib later.
- Python should bind only to stable C ABI, never experimental branches.
