from axiom_module import axiom_health, compute_synergy

assert axiom_health()["status"] == "ok"
assert compute_synergy(2, 2) == 4.0
print("python:ok")
