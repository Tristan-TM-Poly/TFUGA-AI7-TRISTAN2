from __future__ import annotations

def axiom_health() -> dict:
    return {"language": "python", "status": "ok", "layer": "core"}

def compute_synergy(a: float, b: float, coupling: float = 1.0) -> float:
    return round((a * b * coupling) / (1.0 + abs(a - b)), 6)
