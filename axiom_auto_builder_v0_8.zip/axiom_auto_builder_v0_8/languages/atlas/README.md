# Atlas Layer

The Atlas layer is a planning/execution abstraction. It is intentionally language-neutral and stores loop definitions, reports, and future dashboard hooks.
