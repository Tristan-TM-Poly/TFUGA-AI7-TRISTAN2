#include "axiom_core.hpp"
int axiom_mul(int a, int b){ return a * b; }
