#pragma once
int axiom_mul(int a, int b);
