#include <iostream>
#include "axiom_core.hpp"
int main(){ if(axiom_mul(3,4)!=12) return 1; std::cout << "cpp:ok
"; return 0; }
