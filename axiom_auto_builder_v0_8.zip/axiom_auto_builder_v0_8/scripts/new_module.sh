#!/usr/bin/env bash
set -e
name="${1:-new_component}"
mkdir -p "generated/components/$name"
echo "# $name" > "generated/components/$name/README.md"
