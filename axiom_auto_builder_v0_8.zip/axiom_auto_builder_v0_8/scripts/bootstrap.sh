#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 -S core/orchestrator.py run-all
