#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/.."
python3 -S axiom.py run
cd ..
zip -qr axiom_auto_builder_v0_4.zip axiom_auto_builder_v0_4
