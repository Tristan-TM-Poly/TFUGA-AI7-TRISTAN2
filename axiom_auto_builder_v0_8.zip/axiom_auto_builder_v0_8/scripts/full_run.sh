#!/usr/bin/env bash
set -e
AXIOM_FULL_BUILD=1 python3 -S axiom.py run
