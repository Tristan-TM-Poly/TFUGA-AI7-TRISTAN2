#!/usr/bin/env bash
set -e
python3 -S axiom.py run
