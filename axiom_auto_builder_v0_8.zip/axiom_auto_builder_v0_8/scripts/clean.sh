#!/usr/bin/env bash
set -e
rm -rf generated/bin/* reports/*.json reports/*.md reports/*.tex
