#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 -S axiom.py evolve --generations 1000 --population 12 --checkpoint-every 100
