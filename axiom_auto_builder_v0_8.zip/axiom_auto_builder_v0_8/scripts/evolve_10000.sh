#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
for i in $(seq 1 10); do
  echo "[axiom] thousand-generation batch $i/10"
  python3 -S axiom.py evolve --generations 1000 --population 12 --checkpoint-every 100
done
