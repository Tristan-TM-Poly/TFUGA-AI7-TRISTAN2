# Changelog

## v0.4
- Added top-100 expansion plan implementation.
- Added modular core components.
- Added CLI, validators, hypergraph rules, build matrix, Atlas workflows, GOLIATH report factory.
- Added tests, scripts, docs, and promotion/canon guard logic.

## v0.7

- Added resumable evolution engine.
- Added candidate genomes, mutation, evaluation, lineage, checkpoints, and reports.
- Added canon-safe evolution policy.
- Added CLI command: `python3 -S axiom.py evolve`.
