from __future__ import annotations
import json
from pathlib import Path

def run_audit(root: Path) -> dict:
    checks=[]
    required=['README.md','axiom.py','core/orchestrator.py','configs/project_manifest.yaml','docs/CANON.md','hypergraph/synergy_rules.json']
    for rel in required:
        checks.append({'id':'exists:'+rel,'status':'passed' if (root/rel).exists() else 'failed'})
    py_files=list(root.glob('core/*.py'))
    checks.append({'id':'core_modules_count','status':'passed' if len(py_files)>=20 else 'warning','value':len(py_files)})
    score=sum(1 for c in checks if c['status']=='passed')/max(1,len(checks))
    out={'schema':'axiom-audit-v0.6','score':round(score,3),'checks':checks,'verdict':'passed' if score>=0.9 else 'review'}
    dst=root/'audit/audit_report.json'; dst.write_text(json.dumps(out, indent=2), encoding='utf-8')
    md=['# Audit Report v0.6','',f"score: {out['score']}",f"verdict: {out['verdict']}",'','## Checks',*(f"- {c['id']}: {c['status']}" for c in checks)]
    (root/'audit/audit_report.md').write_text('\n'.join(md)+'\n', encoding='utf-8')
    return out
