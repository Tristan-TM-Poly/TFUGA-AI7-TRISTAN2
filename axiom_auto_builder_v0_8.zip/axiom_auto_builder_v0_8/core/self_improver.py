from __future__ import annotations

import json
from pathlib import Path
from core.mutation_planner import next_mutations

def write_plan(root: Path, report: dict) -> Path:
    path = root / 'generated' / 'self_improvement_plan.json'
    path.parent.mkdir(parents=True, exist_ok=True)
    plan = {'schema':'axiom-self-improvement-v0.4','mutations':next_mutations(report), 'principle':'protect trunk, grow branches, promote only verified nodes'}
    path.write_text(json.dumps(plan, indent=2, ensure_ascii=False), encoding='utf-8')
    return path
