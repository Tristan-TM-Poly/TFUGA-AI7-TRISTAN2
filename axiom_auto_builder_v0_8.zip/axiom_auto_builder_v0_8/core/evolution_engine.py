from __future__ import annotations

import hashlib
import json
import random
import time
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _write_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False), encoding='utf-8')


def _read_json(path: Path, default: Any) -> Any:
    if not path.exists():
        return default
    return json.loads(path.read_text(encoding='utf-8'))


def _hash_obj(obj: Any) -> str:
    blob = json.dumps(obj, sort_keys=True, ensure_ascii=False).encode('utf-8')
    return hashlib.sha256(blob).hexdigest()


@dataclass
class Genome:
    generation: int
    genome_id: str
    mutation_rate: float
    canon_weight: float
    validation_weight: float
    automation_weight: float
    synergy_weight: float
    risk_penalty: float
    complexity_penalty: float
    modules_target: int
    test_intensity: int
    report_depth: int

    def vector(self) -> dict[str, Any]:
        return asdict(self)


def seed_genome() -> Genome:
    raw = dict(
        generation=0,
        genome_id='seed',
        mutation_rate=0.075,
        canon_weight=1.0,
        validation_weight=1.0,
        automation_weight=1.0,
        synergy_weight=1.0,
        risk_penalty=0.45,
        complexity_penalty=0.25,
        modules_target=5,
        test_intensity=3,
        report_depth=3,
    )
    raw['genome_id'] = _hash_obj(raw)[:16]
    return Genome(**raw)


def clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def mutate(parent: Genome, generation: int, rng: random.Random) -> Genome:
    scale = parent.mutation_rate
    raw = parent.vector()
    raw['generation'] = generation
    raw['mutation_rate'] = clamp(parent.mutation_rate * rng.uniform(0.92, 1.08), 0.01, 0.25)
    for key in ['canon_weight', 'validation_weight', 'automation_weight', 'synergy_weight']:
        raw[key] = round(clamp(float(raw[key]) + rng.gauss(0, scale), 0.1, 3.0), 5)
    for key in ['risk_penalty', 'complexity_penalty']:
        raw[key] = round(clamp(float(raw[key]) + rng.gauss(0, scale / 2), 0.0, 2.0), 5)
    raw['modules_target'] = int(clamp(int(raw['modules_target']) + rng.choice([-1, 0, 0, 1]), 1, 50))
    raw['test_intensity'] = int(clamp(int(raw['test_intensity']) + rng.choice([-1, 0, 0, 1]), 1, 10))
    raw['report_depth'] = int(clamp(int(raw['report_depth']) + rng.choice([-1, 0, 0, 1]), 1, 10))
    raw['genome_id'] = _hash_obj(raw)[:16]
    return Genome(**raw)


def evaluate(genome: Genome, repo_metrics: dict[str, Any]) -> dict[str, Any]:
    files = float(repo_metrics.get('files', 1))
    python_files = float(repo_metrics.get('python_files', 1))
    json_files = float(repo_metrics.get('json_files', 1))
    md_files = float(repo_metrics.get('md_files', 1))
    reports = float(repo_metrics.get('reports', 1))
    tests = float(repo_metrics.get('tests', 1))

    canon = genome.canon_weight * min(1.5, md_files / 20.0)
    validation = genome.validation_weight * min(1.5, tests / 6.0)
    automation = genome.automation_weight * min(1.5, python_files / 30.0)
    synergy = genome.synergy_weight * min(1.5, (json_files + reports) / 30.0)
    complexity = genome.complexity_penalty * min(2.0, files / 250.0)
    risk = genome.risk_penalty * abs(genome.modules_target - 8) / 20.0
    endurance_bonus = min(0.5, genome.generation / 2000.0)
    score = canon + validation + automation + synergy + endurance_bonus - complexity - risk
    return {
        'genome_id': genome.genome_id,
        'generation': genome.generation,
        'score': round(score, 6),
        'components': {
            'canon': round(canon, 6),
            'validation': round(validation, 6),
            'automation': round(automation, 6),
            'synergy': round(synergy, 6),
            'complexity_penalty': round(complexity, 6),
            'risk_penalty': round(risk, 6),
            'endurance_bonus': round(endurance_bonus, 6),
        },
    }


def repo_metrics(root: Path) -> dict[str, Any]:
    files = [p for p in root.rglob('*') if p.is_file() and '.git' not in p.parts]
    return {
        'files': len(files),
        'python_files': sum(1 for p in files if p.suffix == '.py'),
        'json_files': sum(1 for p in files if p.suffix == '.json'),
        'md_files': sum(1 for p in files if p.suffix == '.md'),
        'reports': sum(1 for p in files if 'reports' in p.parts),
        'tests': sum(1 for p in files if 'tests' in p.parts),
        'bytes': sum(p.stat().st_size for p in files),
    }


def load_state(root: Path) -> dict[str, Any]:
    default = {
        'schema': 'axiom-evolution-state-v0.7',
        'created_at': _now(),
        'last_generation': 0,
        'best': None,
        'lineage': [],
        'checkpoints': [],
    }
    return _read_json(root / 'evolution' / 'state.json', default)


def run_evolution(root: Path, generations: int = 1000, population: int = 12, checkpoint_every: int = 100, seed: int = 7, max_seconds: float | None = None) -> dict[str, Any]:
    root = Path(root)
    rng = random.Random(seed)
    state = load_state(root)
    metrics = repo_metrics(root)
    start_time = time.time()

    if state.get('best'):
        parent_raw = state['best']['genome']
        parent = Genome(**parent_raw)
    else:
        parent = seed_genome()

    best_eval = evaluate(parent, metrics)
    if state.get('best') and state['best'].get('evaluation', {}).get('score', -10**9) > best_eval['score']:
        best_eval = state['best']['evaluation']

    lineage = state.get('lineage', [])[-250:]
    start_generation = int(state.get('last_generation', 0)) + 1
    end_generation = start_generation + int(generations) - 1
    checkpoints = state.get('checkpoints', [])[-50:]

    for gen in range(start_generation, end_generation + 1):
        if max_seconds is not None and (time.time() - start_time) >= max_seconds:
            break
        candidates = [mutate(parent, gen, rng) for _ in range(max(1, population))]
        evaluated = [(cand, evaluate(cand, metrics)) for cand in candidates]
        evaluated.sort(key=lambda item: item[1]['score'], reverse=True)
        winner, winner_eval = evaluated[0]
        parent = winner
        if winner_eval['score'] >= best_eval['score']:
            best_eval = winner_eval
            best = {'genome': winner.vector(), 'evaluation': winner_eval, 'selected_at': _now()}
        else:
            best = state.get('best') or {'genome': parent.vector(), 'evaluation': best_eval, 'selected_at': _now()}
        lineage.append({'generation': gen, 'winner': winner.vector(), 'evaluation': winner_eval})
        if gen % max(1, checkpoint_every) == 0:
            checkpoint = {
                'generation': gen,
                'best_score': best_eval['score'],
                'best_genome_id': best.get('genome', {}).get('genome_id'),
                'created_at': _now(),
            }
            checkpoints.append(checkpoint)
            _write_json(root / 'evolution' / 'checkpoints' / f'generation_{gen:06d}.json', checkpoint)
        state.update({
            'last_generation': gen,
            'updated_at': _now(),
            'repo_metrics': metrics,
            'best': best,
            'lineage': lineage[-250:],
            'checkpoints': checkpoints[-50:],
        })
        if gen % max(1, checkpoint_every) == 0:
            _write_json(root / 'evolution' / 'state.json', state)

    _write_json(root / 'evolution' / 'state.json', state)
    summary = {
        'schema': 'axiom-evolution-summary-v0.7',
        'generated_at': _now(),
        'requested_generations': generations,
        'executed_until_generation': state['last_generation'],
        'population': population,
        'checkpoint_every': checkpoint_every,
        'best_score': state['best']['evaluation']['score'] if state.get('best') else best_eval['score'],
        'best_genome': state['best']['genome'] if state.get('best') else parent.vector(),
        'repo_metrics': metrics,
        'status': 'completed' if state['last_generation'] >= end_generation else 'time_bounded_partial',
        'resume_command': 'python3 -S axiom.py evolve --generations 1000 --population 12 --checkpoint-every 100',
    }
    _write_json(root / 'evolution' / 'summary.json', summary)
    write_markdown(root, summary, state)
    return summary


def write_markdown(root: Path, summary: dict[str, Any], state: dict[str, Any]) -> None:
    best = summary['best_genome']
    lines = [
        '# Axiom Evolution Loop v0.7',
        '',
        f"Generated: {summary['generated_at']}",
        '',
        '## Summary',
        '',
        f"- status: {summary['status']}",
        f"- executed_until_generation: {summary['executed_until_generation']}",
        f"- best_score: {summary['best_score']}",
        f"- population: {summary['population']}",
        f"- checkpoint_every: {summary['checkpoint_every']}",
        '',
        '## Best genome',
        '',
    ]
    for key, value in best.items():
        lines.append(f'- {key}: {value}')
    lines += ['', '## Recent lineage']
    for row in state.get('lineage', [])[-10:]:
        lines.append(f"- generation {row['generation']}: {row['evaluation']['score']} / {row['winner']['genome_id']}")
    lines += ['', '## Resume', '', f"`{summary['resume_command']}`", '']
    out = root / 'evolution' / 'EVOLUTION_REPORT.md'
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text('\n'.join(lines), encoding='utf-8')
