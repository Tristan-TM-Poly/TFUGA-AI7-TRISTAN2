from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

@dataclass
class AxiomContext:
    root: Path
    version: str = "0.4"
    state: dict[str, Any] = field(default_factory=dict)

    @property
    def reports(self) -> Path:
        return self.root / "reports"

    @property
    def generated(self) -> Path:
        return self.root / "generated"

    def ensure(self) -> None:
        for path in [self.reports, self.generated, self.generated / "bin", self.generated / "hypergraph", self.generated / "plans"]:
            path.mkdir(parents=True, exist_ok=True)
