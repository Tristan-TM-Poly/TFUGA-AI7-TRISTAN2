#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, os, shutil, sys, hashlib
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from core.config_loader import tiny_yaml
from core.context import AxiomContext
from core.task_registry import TaskRegistry, TaskSpec
from core.dependency_resolver import topological_sort
from core.execution_engine import ExecutionEngine, result_dicts
from core.module_generator import ModuleGenerator
from core.promotion_engine import score, verdict
from core.canon_guard import check as canon_check
from core.duplicate_detector import find_duplicate_files
from core.refactor_advisor import advise
from core.self_improver import write_plan
from core.rollback_manager import snapshot

VERSION = '0.8'
MANIFEST = ROOT / 'configs' / 'project_manifest.yaml'

def now() -> str: return datetime.now(timezone.utc).isoformat()
def write_json(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False), encoding='utf-8')
def read_json(path: Path, default):
    return json.loads(path.read_text(encoding='utf-8')) if path.exists() else default

def inspect_toolchains() -> list[dict]:
    tools=['/usr/bin/python3','gcc','g++','cargo','rustc','dotnet','cmake','make','git','node','npm','pytest']
    rows=[{'name':t,'available':shutil.which(t) is not None,'path':shutil.which(t)} for t in tools]
    write_json(ROOT/'reports/toolchain_inspection.json', rows)
    return rows

def plan_tasks(manifest: dict) -> list[TaskSpec]:
    reg=TaskRegistry()
    reg.add(TaskSpec('generate:templates','generate',None,[],[]))
    reg.add(TaskSpec('generate:modules','generate',None,[],['generate:templates']))
    reg.add(TaskSpec('canon:guard','validate','/usr/bin/python3 -S -B -c "from pathlib import Path; from core.canon_guard import check; import json; r=check(Path(\'.\')); print(json.dumps(r)); raise SystemExit(0 if r[\'status\']==\'passed\' else 1)"',['/usr/bin/python3'],['generate:modules']))
    full=os.environ.get('AXIOM_FULL_BUILD','0')=='1'
    for lang in manifest.get('languages',[]):
        lid=lang['id']; tool=lang.get('required_tool'); optional=lang.get('tier')=='optional'
        if optional and not full:
            reg.add(TaskSpec(f'{lid}:policy','policy',None,[],[],True)); continue
        if lang.get('build'):
            reg.add(TaskSpec(f'{lid}:build','build',lang['build'],[tool] if tool else [],['generate:modules'],optional))
        if lang.get('test'):
            deps=[f'{lid}:build'] if lang.get('build') else ['generate:modules']
            reg.add(TaskSpec(f'{lid}:test','test',lang['test'],[tool] if tool else [],deps,optional))
    reg.add(TaskSpec('validate:repo','validate','/usr/bin/python3 -S -B tools/validate_repo.py',['/usr/bin/python3'],['canon:guard']))
    reg.add(TaskSpec('validate:manifest','validate','/usr/bin/python3 -S -B tools/validate_manifest.py',['/usr/bin/python3'],['validate:repo']))
    reg.add(TaskSpec('graph:export','graph','/usr/bin/python3 -S -B tools/export_mermaid.py && /usr/bin/python3 -S -B tools/export_graphviz.py',['/usr/bin/python3'],['validate:manifest']))
    reg.add(TaskSpec('score:synergies','score','/usr/bin/python3 -S -B tools/score_synergies.py',['/usr/bin/python3'],['graph:export']))
    tasks=topological_sort(reg.all())
    write_json(ROOT/'generated/hypergraph/task_graph.json', {'schema':'axiom-task-graph-v0.6','generated_at':now(),'tasks':[asdict(t) for t in tasks], 'edges':[{'source':d,'target':t.name,'type':'precedes'} for t in tasks for d in t.depends_on]})
    return tasks

def build_project_hypergraph(manifest: dict, toolchains: list[dict], tasks: list[TaskSpec]) -> dict:
    nodes=[{'id':'canon','type':'canon','status':'stable','version':VERSION},{'id':'orchestrator','type':'pipeline','status':'crystallized','version':VERSION},{'id':'self_improver','type':'meta-pipeline','status':'seed','version':VERSION},{'id':'goliath','type':'report-factory','status':'seed','version':VERSION},{'id':'atlas','type':'workflow-runtime','status':'seed','version':VERSION}]
    edges=[{'source':'orchestrator','target':'canon','type':'protects'},{'source':'self_improver','target':'orchestrator','type':'improves'},{'source':'goliath','target':'reports','type':'produces'},{'source':'atlas','target':'orchestrator','type':'guides'}]
    for lang in manifest.get('languages',[]):
        lid=lang['id']; nodes.append({'id':f'lang:{lid}','type':'language','status':'seed','tier':lang.get('tier')}); edges.append({'source':'orchestrator','target':f'lang:{lid}','type':'builds'})
        if lang.get('entry'):
            nodes.append({'id':f'entry:{lid}','type':'module','path':lang['entry'],'status':'generated'}); edges.append({'source':f'lang:{lid}','target':f'entry:{lid}','type':'contains'})
    for t in toolchains: nodes.append({'id':f"tool:{t['name']}",'type':'toolchain','status':'available' if t['available'] else 'missing','path':t['path']})
    for task in tasks:
        nodes.append({'id':f'task:{task.name}','type':'task','kind':task.kind,'status':'planned','optional':task.optional})
        edges.append({'source':'orchestrator','target':f'task:{task.name}','type':'schedules'})
        for req in task.requires: edges.append({'source':f'tool:{req}','target':f'task:{task.name}','type':'required_by'})
    graph={'schema':'axiom-hypergraph-instance-v0.6','generated_at':now(),'nodes':nodes,'edges':edges}
    write_json(ROOT/'generated/hypergraph/project_hypergraph.json', graph)
    return graph

def artifact_ledger() -> dict:
    rows=[]
    for p in ROOT.rglob('*'):
        if p.is_file() and '.git' not in p.parts and p.stat().st_size < 2_000_000:
            rows.append({'path':str(p.relative_to(ROOT)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size})
    out={'schema':'artifact-ledger-v0.6','generated_at':now(),'count':len(rows),'artifacts':rows}
    write_json(ROOT/'reports/artifact_ledger.json', out)
    return out

def run_all() -> dict:
    ctx=AxiomContext(ROOT, VERSION); ctx.ensure(); snapshot(ROOT)
    manifest=tiny_yaml(MANIFEST)
    mg=ModuleGenerator(ROOT); templates=mg.write_templates(); api=mg.generate_api()
    toolchains=inspect_toolchains()
    tasks=plan_tasks(manifest)
    graph=build_project_hypergraph(manifest, toolchains, tasks)
    engine=ExecutionEngine(ROOT)
    results=[]
    for task in tasks:
        if task.name == 'generate:templates':
            results.append(engine.run(TaskSpec(task.name, task.kind, None, [], [], task.optional)))
        elif task.name == 'generate:modules':
            mg.generate_api(); results.append(engine.run(TaskSpec(task.name, task.kind, None, [], [], task.optional)))
        else:
            results.append(engine.run(task))
    passed=sum(1 for r in results if r.status=='passed'); failed=sum(1 for r in results if r.status=='failed'); skipped=sum(1 for r in results if r.status=='skipped')
    guard=canon_check(ROOT)
    metrics={'proof':1.0 if failed==0 else 0.2,'validation':min(1.2, passed/8),'reuse':1.0,'fertility':1.0,'compression':0.8,'automation':1.0,'dedupe':0.1*len(find_duplicate_files(ROOT)),'uncertainty':0.2*skipped}
    value=score(metrics); promo=verdict(value) if guard['status']=='passed' and failed==0 else 'blocked'
    report={'schema':'axiom-orchestration-report-v0.6','generated_at':now(),'version':VERSION,'summary':{'passed':passed,'failed':failed,'skipped':skipped,'global_score':value,'promotion':promo,'canon_guard':guard['status']},'metrics':metrics,'toolchains':toolchains,'results':result_dicts(results),'generated':{'templates':templates,'api':api,'hypergraph_nodes':len(graph['nodes']),'hypergraph_edges':len(graph['edges'])},'canon_guard':guard,'duplicates':find_duplicate_files(ROOT),'refactor_advice':advise(ROOT)}
    write_json(ROOT/'reports/orchestration_report.json', report)
    md=['# Axiom Auto Builder v0.6 Report','',f"Generated: {report['generated_at']}",'',f"passed: {passed}",f"failed: {failed}",f"skipped: {skipped}",f"global_score: {value}",f"promotion: {promo}",f"canon_guard: {guard['status']}",'','## Results']
    for r in results: md.append(f"- {r.name}: {r.status} ({r.reason or r.command or 'ok'})")
    (ROOT/'reports/orchestration_report.md').write_text('\n'.join(md)+'\n', encoding='utf-8')
    write_plan(ROOT, report)
    artifact_ledger()
    # GOLIATH outputs
    try:
        from goliath.report_factory import write_technical_report
        from goliath.latex_builder import render_latex
        write_technical_report(ROOT); render_latex(ROOT)
    except Exception as exc:
        report['goliath_error']=str(exc)
    # v0.6 meta-construction layer
    try:
        from core.plugin_system import discover_plugins
        from core.recipe_engine import compile_recipes
        from core.observability_engine import write_observability
        from core.proof_engine import build_proof_bundle
        from core.release_capsule import create_release_capsule
        from core.audit_engine import run_audit
        from core.meta_indexer import build_meta_index
        from core.dashboard_exporter import export_dashboard
        from core.benchmark_engine import run_benchmarks
        report['v0_6'] = {
            'plugins': discover_plugins(ROOT),
            'recipes': compile_recipes(ROOT),
            'observability': write_observability(ROOT, report),
            'proof_bundle': build_proof_bundle(ROOT),
            'audit': run_audit(ROOT),
            'meta_index': build_meta_index(ROOT),
            'dashboard': export_dashboard(ROOT, report),
            'benchmarks': run_benchmarks(ROOT),
            'release_capsule': create_release_capsule(ROOT, VERSION, report),
        }
        report['summary']['audit'] = report['v0_6']['audit']['verdict']
        report['summary']['proof_bundle'] = 'passed' if report['v0_6']['proof_bundle']['all_present'] else 'review'
        write_json(ROOT/'reports/orchestration_report.json', report)
    except Exception as exc:
        report['v0_6_error'] = str(exc)
        write_json(ROOT/'reports/orchestration_report.json', report)

    # v0.8 performance/resources bidirectional curve fitting layer
    try:
        from core.performance_curvefit_engine import run_performance_curvefit
        report['v0_8_performance_curvefit'] = run_performance_curvefit(ROOT)
        report['summary']['performance_curvefit'] = report['v0_8_performance_curvefit']['status']
        write_json(ROOT/'reports/orchestration_report.json', report)
    except Exception as exc:
        report['v0_8_performance_curvefit_error'] = str(exc)
        write_json(ROOT/'reports/orchestration_report.json', report)
    return report

def validate() -> int:
    required=['README.md','axiom.py','core/orchestrator.py','configs/project_manifest.yaml','docs/CANON.md']
    missing=[x for x in required if not (ROOT/x).exists()]
    if missing:
        print('missing:'+','.join(missing)); return 1
    print('validate:ok'); return 0

def graph() -> int:
    manifest=tiny_yaml(MANIFEST); tools=inspect_toolchains(); tasks=plan_tasks(manifest); build_project_hypergraph(manifest,tools,tasks); print('graph:ok'); return 0

def main() -> int:
    parser=argparse.ArgumentParser(description='Axiom Auto Builder v0.8')
    parser.add_argument('command', choices=['run-all','run','validate','graph','inspect','evolve','perf-fit'])
    parser.add_argument('--generations', type=int, default=1000)
    parser.add_argument('--population', type=int, default=12)
    parser.add_argument('--checkpoint-every', type=int, default=100)
    parser.add_argument('--seed', type=int, default=7)
    parser.add_argument('--max-seconds', type=float, default=None)
    args=parser.parse_args()
    if args.command in ['run-all','run']:
        report=run_all(); print(json.dumps(report['summary'], indent=2)); return 0 if report['summary']['failed']==0 else 1
    if args.command=='validate': return validate()
    if args.command=='graph': return graph()
    if args.command=='inspect': print(json.dumps(inspect_toolchains(), indent=2)); return 0
    if args.command=='evolve':
        from core.evolution_engine import run_evolution
        summary=run_evolution(ROOT, generations=args.generations, population=args.population, checkpoint_every=args.checkpoint_every, seed=args.seed, max_seconds=args.max_seconds)
        print(json.dumps({k: summary[k] for k in ['status','executed_until_generation','best_score']}, indent=2)); return 0
    if args.command=='perf-fit':
        from core.performance_curvefit_engine import run_performance_curvefit
        summary=run_performance_curvefit(ROOT)
        print(json.dumps({'status': summary['status'], 'algorithms': summary['algorithm_count'], 'best_candidate': summary.get('best_candidate')}, indent=2)); return 0
    return 1
if __name__=='__main__': raise SystemExit(main())
