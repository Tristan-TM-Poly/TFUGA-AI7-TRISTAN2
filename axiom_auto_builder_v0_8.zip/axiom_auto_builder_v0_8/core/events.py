from __future__ import annotations

from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from typing import Any

@dataclass
class Event:
    name: str
    payload: dict[str, Any]
    created_at: str

class EventBus:
    def __init__(self) -> None:
        self.events: list[Event] = []
    def emit(self, name: str, **payload: Any) -> None:
        self.events.append(Event(name, payload, datetime.now(timezone.utc).isoformat()))
    def to_dicts(self) -> list[dict[str, Any]]:
        return [asdict(e) for e in self.events]
