from __future__ import annotations

from pathlib import Path

def advise(root: Path) -> list[dict]:
    tips=[]
    for p in root.rglob("*.py"):
        if ".git" in p.parts: continue
        lines=p.read_text(encoding="utf-8", errors="ignore").splitlines()
        if len(lines)>350:
            tips.append({"file":str(p.relative_to(root)),"issue":"large python file","recommendation":"split into modules"})
    return tips
