from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any

@dataclass
class TaskSpec:
    name: str
    kind: str
    command: str | None
    requires: list[str]
    depends_on: list[str]
    optional: bool = False

class TaskRegistry:
    def __init__(self) -> None:
        self.tasks: dict[str, TaskSpec] = {}
    def add(self, task: TaskSpec) -> None:
        self.tasks[task.name] = task
    def all(self) -> list[TaskSpec]:
        return list(self.tasks.values())
    def to_json(self) -> list[dict[str, Any]]:
        return [asdict(t) for t in self.all()]
