#!/usr/bin/env python3
from __future__ import annotations
import json, math, os, random, resource, statistics, subprocess, sys, time, hashlib
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Callable, Iterable

SCHEMA = 'axiom-performance-curvefit-v0.8'


def now() -> str:
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).isoformat()


def write_json(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False), encoding='utf-8')


def ols(xs: list[list[float]], ys: list[float]) -> dict:
    # Small normal-equation solver with ridge fallback, stdlib only.
    if not xs or len(xs) != len(ys):
        return {'ok': False, 'reason': 'empty_or_mismatched'}
    m = len(xs[0])
    ata = [[0.0 for _ in range(m)] for _ in range(m)]
    aty = [0.0 for _ in range(m)]
    for row, y in zip(xs, ys):
        for i in range(m):
            aty[i] += row[i] * y
            for j in range(m):
                ata[i][j] += row[i] * row[j]
    # Ridge stabilizer for near-singular tiny data.
    for i in range(m):
        ata[i][i] += 1e-12
    # Gaussian elimination.
    a = [ata[i] + [aty[i]] for i in range(m)]
    for col in range(m):
        pivot = max(range(col, m), key=lambda r: abs(a[r][col]))
        if abs(a[pivot][col]) < 1e-18:
            return {'ok': False, 'reason': 'singular'}
        a[col], a[pivot] = a[pivot], a[col]
        div = a[col][col]
        a[col] = [v / div for v in a[col]]
        for r in range(m):
            if r == col:
                continue
            factor = a[r][col]
            a[r] = [rv - factor * cv for rv, cv in zip(a[r], a[col])]
    coef = [a[i][-1] for i in range(m)]
    pred = [sum(c * x for c, x in zip(coef, row)) for row in xs]
    mean_y = sum(ys) / len(ys)
    ss_res = sum((y - p) ** 2 for y, p in zip(ys, pred))
    ss_tot = sum((y - mean_y) ** 2 for y in ys)
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else 1.0
    rmse = math.sqrt(ss_res / max(1, len(ys)))
    return {'ok': True, 'coef': coef, 'r2': r2, 'rmse': rmse, 'predictions': pred}


def features(n: float, model: str) -> list[float]:
    ln = math.log(max(n, 2.0))
    if model == 'constant':
        return [1.0]
    if model == 'linear':
        return [1.0, n]
    if model == 'nlogn':
        return [1.0, n * ln]
    if model == 'quadratic':
        return [1.0, n, n * n]
    if model == 'mixed':
        return [1.0, n, n * ln, n * n]
    raise ValueError(model)


def fit_models(samples: list[dict], y_key: str) -> dict:
    ns = [float(s['n']) for s in samples]
    ys = [float(s[y_key]) for s in samples]
    out = {}
    for model in ['constant', 'linear', 'nlogn', 'quadratic', 'mixed']:
        if len(samples) < len(features(ns[0], model)):
            continue
        fit = ols([features(n, model) for n in ns], ys)
        if fit.get('ok'):
            fit['model'] = model
            fit['equation'] = equation_text(model, fit['coef'], y_key)
            out[model] = fit
    # Power law y = a*n^b via log transform, only positive values.
    positive = [(n, y) for n, y in zip(ns, ys) if n > 0 and y > 0]
    if len(positive) >= 2:
        lx = [[1.0, math.log(n)] for n, y in positive]
        ly = [math.log(y) for n, y in positive]
        fit = ols(lx, ly)
        if fit.get('ok'):
            loga, b = fit['coef']
            a = math.exp(loga)
            pred = [a * (n ** b) for n in ns]
            mean_y = sum(ys) / len(ys)
            ss_res = sum((y - p) ** 2 for y, p in zip(ys, pred))
            ss_tot = sum((y - mean_y) ** 2 for y in ys)
            out['power'] = {'ok': True, 'model': 'power', 'coef': [a, b], 'r2': 1.0 - ss_res / ss_tot if ss_tot > 0 else 1.0, 'rmse': math.sqrt(ss_res / len(ys)), 'predictions': pred, 'equation': f'{y_key} ≈ {a:.6g} * n^{b:.6g}'}
    if not out:
        return {'best': None, 'candidates': {}}
    best = max(out.values(), key=lambda d: (d['r2'], -d['rmse']))
    return {'best': best, 'candidates': out}


def equation_text(model: str, coef: list[float], y_key: str) -> str:
    if model == 'constant':
        return f'{y_key} ≈ {coef[0]:.6g}'
    if model == 'linear':
        return f'{y_key} ≈ {coef[0]:.6g} + {coef[1]:.6g} n'
    if model == 'nlogn':
        return f'{y_key} ≈ {coef[0]:.6g} + {coef[1]:.6g} n log(n)'
    if model == 'quadratic':
        return f'{y_key} ≈ {coef[0]:.6g} + {coef[1]:.6g} n + {coef[2]:.6g} n²'
    if model == 'mixed':
        return f'{y_key} ≈ {coef[0]:.6g} + {coef[1]:.6g} n + {coef[2]:.6g} n log(n) + {coef[3]:.6g} n²'
    return f'{y_key} ≈ model({coef})'


def predict(model_fit: dict, n: float) -> float:
    model = model_fit['model']
    coef = model_fit['coef']
    if model == 'power':
        return coef[0] * (n ** coef[1])
    return sum(c * x for c, x in zip(coef, features(n, model)))


def inverse_capacity(model_fit: dict, target_y: float, lo: float = 1.0, hi: float = 1_000_000.0) -> float:
    # Monotone-ish binary search for practical inverse demand capacity.
    target_y = max(target_y, 1e-12)
    lo = max(1.0, lo)
    hi = max(lo + 1.0, hi)
    for _ in range(80):
        mid = (lo + hi) / 2.0
        y = predict(model_fit, mid)
        if y < target_y:
            lo = mid
        else:
            hi = mid
    return (lo + hi) / 2.0


def rss_kb() -> int:
    return int(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)


def time_algorithm(fn: Callable[[int], object], n: int, repeats: int = 3) -> dict:
    times = []
    rss_before = rss_kb()
    checksum = ''
    for _ in range(repeats):
        t0 = time.perf_counter()
        value = fn(n)
        elapsed = time.perf_counter() - t0
        times.append(elapsed)
        checksum = hashlib.sha256(repr(value).encode('utf-8')).hexdigest()[:16]
    rss_after = rss_kb()
    return {'n': n, 'time_sec': statistics.median(times), 'rss_kb': max(0, rss_after - rss_before), 'repeats': repeats, 'checksum': checksum}


def alg_linear_scan(n: int) -> int:
    total = 0
    for i in range(n):
        total += (i * 31 + 7) % 97
    return total


def alg_sort(n: int) -> int:
    rng = random.Random(12345 + n)
    data = [rng.randrange(0, 10_000_000) for _ in range(n)]
    data.sort()
    return data[n // 2] if data else 0


def alg_hash_stream(n: int) -> str:
    h = hashlib.sha256()
    for i in range(n):
        h.update(f'{i}:axiom:{(i*i)%101}\n'.encode('utf-8'))
    return h.hexdigest()


def alg_json_roundtrip(n: int) -> int:
    obj = [{'i': i, 'v': (i * 17) % 101, 'tag': 'axiom'} for i in range(n)]
    text = json.dumps(obj, separators=(',', ':'))
    return len(json.loads(text))


def alg_matrix_kernel(n: int) -> float:
    # O(n^2) synthetic kernel capped by chosen sizes.
    total = 0.0
    for i in range(n):
        ai = (i + 1) / (n + 1)
        for j in range(n):
            total += ai * ((j + 3) % 17) / 17.0
    return round(total, 6)


def discover_repository_algorithms(root: Path) -> list[dict]:
    rows = []
    for path in sorted((root / 'core').glob('*.py')) + sorted((root / 'tools').glob('*.py')) + sorted((root / 'goliath').glob('*.py')):
        text = path.read_text(encoding='utf-8', errors='ignore')
        funcs = text.count('def ')
        classes = text.count('class ')
        lines = len(text.splitlines())
        imports = sum(1 for line in text.splitlines() if line.startswith('import ') or line.startswith('from '))
        complexity_proxy = funcs * 3 + classes * 5 + imports + lines / 50.0
        rows.append({'path': str(path.relative_to(root)), 'lines': lines, 'functions': funcs, 'classes': classes, 'imports': imports, 'complexity_proxy': round(complexity_proxy, 3)})
    return rows


def benchmark_pipelines(root: Path) -> list[dict]:
    commands = [
        {'name': 'cli_validate', 'cmd': [sys.executable, '-S', 'axiom.py', 'validate']},
        {'name': 'cli_inspect', 'cmd': [sys.executable, '-S', 'axiom.py', 'inspect']},
        {'name': 'tool_check_json', 'cmd': [sys.executable, '-S', 'tools/check_json.py']},
    ]
    samples = []
    for item in commands:
        t0 = time.perf_counter()
        proc = subprocess.run(item['cmd'], cwd=root, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=20)
        elapsed = time.perf_counter() - t0
        samples.append({'name': item['name'], 'n': 1, 'time_sec': elapsed, 'rss_kb': 0, 'returncode': proc.returncode, 'stdout_bytes': len(proc.stdout), 'stderr_bytes': len(proc.stderr)})
    return samples


def analyze_samples(name: str, samples: list[dict]) -> dict:
    time_fit = fit_models(samples, 'time_sec')
    rss_fit = fit_models(samples, 'rss_kb')
    best_time = time_fit.get('best')
    best_rss = rss_fit.get('best')
    inverse = {}
    if best_time:
        for target in [0.01, 0.1, 1.0, 10.0]:
            inverse[f'n_for_{target}s'] = inverse_capacity(best_time, target, 1.0, max(10.0, max(s['n'] for s in samples) * 100.0))
    demand = {}
    if best_time and best_rss:
        for n in [max(s['n'] for s in samples), max(s['n'] for s in samples) * 10]:
            demand[str(n)] = {'predicted_time_sec': predict(best_time, n), 'predicted_rss_kb': max(0.0, predict(best_rss, n))}
    return {'name': name, 'sample_count': len(samples), 'samples': samples, 'time_model': time_fit, 'resource_model': rss_fit, 'inverse_capacity': inverse, 'resource_demand_forecast': demand}


def write_markdown(root: Path, summary: dict, analyses: list[dict], repo_algorithms: list[dict], pipeline_samples: list[dict]) -> None:
    lines = [
        '# Axiom v0.8 Bidirectional Performance/Resource Curvefit Report',
        '',
        f"Generated: {summary['generated_at']}",
        '',
        '## Scientific status',
        '',
        'This report provides reproducible empirical evidence and fitted models under explicit assumptions. It does not claim absolute irrefutability; it gives auditable, repeatable, falsifiable proof protocols suitable for thesis development.',
        '',
        '## Best fitted kernels',
    ]
    for a in analyses:
        tm = a['time_model'].get('best') or {}
        rm = a['resource_model'].get('best') or {}
        lines.append(f"- **{a['name']}**: time `{tm.get('equation','unfit')}`, R²={tm.get('r2','n/a')}; resource `{rm.get('equation','unfit')}`, R²={rm.get('r2','n/a')}")
    lines += ['', '## Bidirectional principle', '', 'Forward model: estimate performance and resource demand from scale `n`.', '', '`time = f_algorithm(n)` and `resource = g_algorithm(n)`', '', 'Backward model: estimate maximum feasible scale from a target budget.', '', '`n_max = f_algorithm^{-1}(target_time)` and `resource_required = g_algorithm(n_max)`', '', '## Repository algorithm inventory']
    for row in repo_algorithms[:80]:
        lines.append(f"- `{row['path']}`: lines={row['lines']}, functions={row['functions']}, complexity_proxy={row['complexity_proxy']}")
    lines += ['', '## Pipeline timing samples']
    for s in pipeline_samples:
        lines.append(f"- `{s['name']}`: {s['time_sec']:.6f}s, returncode={s['returncode']}, stdout={s['stdout_bytes']}B, stderr={s['stderr_bytes']}B")
    (root / 'performance' / 'PERFORMANCE_REPORT.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')


def write_thesis_docs(root: Path, analyses: list[dict]) -> None:
    thesis = [
        '# Thesis Foundation: Bidirectional Curve Fitting for Self-Improving Multi-Language Pipelines',
        '',
        '## Core thesis claim',
        '',
        'For every algorithmic component or pipeline stage with measurable scale parameter `n`, define a bidirectional pair of empirical models:',
        '',
        '`T_A(n; θ_T)` for performance and `R_A(n; θ_R)` for resource demand.',
        '',
        'The forward direction predicts time/memory from workload scale. The backward direction estimates feasible workload scale from a resource/time budget.',
        '',
        '## Proof protocol, not dogma',
        '',
        'A proof is considered thesis-grade when it is reproducible, falsifiable, versioned, statistically scored, and tied to raw measurements. Absolute irrebuttability is not claimed; instead the system produces stronger evidence after every generation.',
        '',
        '## Mathematical spine',
        '',
        'Given samples `(n_i, t_i, r_i)`, estimate parameters by least squares:',
        '',
        '`θ_T* = argmin_θ Σ_i (t_i - T_A(n_i; θ))²`',
        '',
        '`θ_R* = argmin_θ Σ_i (r_i - R_A(n_i; θ))²`',
        '',
        'Then evaluate `R²`, RMSE, residuals, monotonicity and extrapolation risk. Promotion to canon requires high fit quality plus independent reruns.',
        '',
        '## Algorithms currently benchmarked',
    ]
    for a in analyses:
        thesis.append(f"- `{a['name']}` with {a['sample_count']} samples")
    (root / 'thesis' / 'THESIS_PERFORMANCE_FOUNDATION.md').write_text('\n'.join(thesis) + '\n', encoding='utf-8')
    proof = [
        '# Proof Protocol v0.8',
        '',
        '1. Freeze code version and artifact ledger.',
        '2. Run benchmarks across scale ladder.',
        '3. Fit multiple candidate models.',
        '4. Select model by R², RMSE and parsimony.',
        '5. Validate forward predictions on withheld scales.',
        '6. Validate backward predictions against budgeted runs.',
        '7. Promote only if results reproduce across machines/toolchains.',
        '8. Record failures as counterexamples, not noise to hide.',
        '',
        'This is the anti-brouillard rule: every performance claim must point to raw samples, model, residuals, environment, and version.',
    ]
    (root / 'thesis' / 'PROOF_PROTOCOL.md').write_text('\n'.join(proof) + '\n', encoding='utf-8')


def run_performance_curvefit(root: Path) -> dict:
    root = Path(root)
    random.seed(7)
    scale_map = {
        'linear_scan': [1_000, 3_000, 10_000, 30_000],
        'sort': [1_000, 3_000, 10_000, 30_000],
        'hash_stream': [1_000, 3_000, 10_000, 30_000],
        'json_roundtrip': [200, 700, 2_000, 5_000],
        'matrix_kernel': [20, 40, 80, 120],
    }
    fns = {
        'linear_scan': alg_linear_scan,
        'sort': alg_sort,
        'hash_stream': alg_hash_stream,
        'json_roundtrip': alg_json_roundtrip,
        'matrix_kernel': alg_matrix_kernel,
    }
    raw = {}
    analyses = []
    for name, fn in fns.items():
        samples = [time_algorithm(fn, n, repeats=3) for n in scale_map[name]]
        raw[name] = samples
        analyses.append(analyze_samples(name, samples))
    repo_algorithms = discover_repository_algorithms(root)
    pipeline_samples = benchmark_pipelines(root)
    summary = {
        'schema': SCHEMA,
        'status': 'passed',
        'generated_at': now(),
        'algorithm_count': len(analyses),
        'repository_algorithm_inventory_count': len(repo_algorithms),
        'pipeline_sample_count': len(pipeline_samples),
        'best_candidate': max(analyses, key=lambda a: (a['time_model'].get('best') or {}).get('r2', -999))['name'] if analyses else None,
        'claim_boundary': 'empirical, reproducible, falsifiable; not absolute or assumption-free',
    }
    write_json(root / 'performance' / 'raw_metrics.json', raw)
    write_json(root / 'performance' / 'curvefit_report.json', {'schema': SCHEMA, 'summary': summary, 'analyses': analyses})
    write_json(root / 'performance' / 'bidirectional_models.json', {'schema': SCHEMA, 'models': [{'name': a['name'], 'time_best': a['time_model'].get('best'), 'resource_best': a['resource_model'].get('best'), 'inverse_capacity': a['inverse_capacity'], 'resource_demand_forecast': a['resource_demand_forecast']} for a in analyses]})
    write_json(root / 'performance' / 'repository_algorithm_inventory.json', repo_algorithms)
    write_json(root / 'performance' / 'pipeline_metrics.json', pipeline_samples)
    write_markdown(root, summary, analyses, repo_algorithms, pipeline_samples)
    write_thesis_docs(root, analyses)
    return summary


if __name__ == '__main__':
    project_root = Path(__file__).resolve().parents[1]
    print(json.dumps(run_performance_curvefit(project_root), indent=2))
