from __future__ import annotations

from pathlib import Path


def snapshot(root: Path) -> str:
    snap = root / "generated" / "snapshots" / "last_safe"
    snap.mkdir(parents=True, exist_ok=True)
    marker = snap / "README.md"
    marker.write_text("Rollback marker. Use git or archive copy for full rollback.\n", encoding="utf-8")
    return str(snap.relative_to(root))
