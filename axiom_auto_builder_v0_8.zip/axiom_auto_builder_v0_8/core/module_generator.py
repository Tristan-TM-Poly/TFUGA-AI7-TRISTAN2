from __future__ import annotations

from pathlib import Path

class ModuleGenerator:
    def __init__(self, root: Path) -> None:
        self.root = root

    def write_templates(self) -> list[str]:
        t = self.root / "generated" / "templates"
        t.mkdir(parents=True, exist_ok=True)
        templates = {
            "python_module.py.tpl": "def run():\n    return {'node': '{{name}}', 'status': 'ok'}\n",
            "c_module.c.tpl": "#include <stdio.h>\nint main(void){ puts(\"{{name}}:ok\"); return 0; }\n",
            "cpp_module.cpp.tpl": "#include <iostream>\nint main(){ std::cout << \"{{name}}:ok\\n\"; return 0; }\n",
            "rust_module.rs.tpl": "fn main(){ println!(\"{{name}}:ok\"); }\n",
            "csharp_module.cs.tpl": "using System;\nConsole.WriteLine(\"{{name}}:ok\");\n",
            "atlas_node.yaml.tpl": "id: {{name}}\nkind: atlas-node\nstatus: seed\n",
        }
        out: list[str] = []
        for name, content in templates.items():
            p = t / name
            p.write_text(content, encoding="utf-8")
            out.append(str(p.relative_to(self.root)))
        return out

    def generate_api(self) -> str:
        out = self.root / "generated" / "modules" / "axiom_generated_api.py"
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text("def health():\n    return {'axiom':'v0.4','status':'green'}\n", encoding="utf-8")
        return str(out.relative_to(self.root))
