from __future__ import annotations

import shutil, subprocess
from dataclasses import dataclass, asdict
from pathlib import Path
from core.task_registry import TaskSpec

@dataclass
class TaskResult:
    name: str
    kind: str
    status: str
    command: str | None = None
    stdout: str = ""
    stderr: str = ""
    returncode: int | None = None
    reason: str | None = None

class ExecutionEngine:
    def __init__(self, root: Path) -> None:
        self.root = root
    def available(self, tool: str) -> bool:
        return shutil.which(tool) is not None
    def run(self, task: TaskSpec, timeout: int = 60) -> TaskResult:
        missing = [t for t in task.requires if t and not self.available(t)]
        if missing:
            return TaskResult(task.name, task.kind, "skipped" if task.optional else "failed", task.command, reason="missing toolchain: "+", ".join(missing))
        if task.command is None:
            return TaskResult(task.name, task.kind, "passed", None, reason="internal/no-op task")
        try:
            proc = subprocess.run(task.command, shell=True, cwd=str(self.root), text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout)
            return TaskResult(task.name, task.kind, "passed" if proc.returncode == 0 else "failed", task.command, proc.stdout[-6000:], proc.stderr[-6000:], proc.returncode)
        except subprocess.TimeoutExpired as exc:
            return TaskResult(task.name, task.kind, "failed", task.command, exc.stdout or "", "timeout", 124)

def result_dicts(results: list[TaskResult]) -> list[dict]:
    return [asdict(r) for r in results]
