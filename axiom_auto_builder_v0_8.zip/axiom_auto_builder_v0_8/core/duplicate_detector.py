from __future__ import annotations

import hashlib
from pathlib import Path

def find_duplicate_files(root: Path) -> list[list[str]]:
    buckets: dict[str, list[str]] = {}
    for p in root.rglob("*"):
        if p.is_file() and ".git" not in p.parts and p.stat().st_size < 2_000_000:
            h = hashlib.sha256(p.read_bytes()).hexdigest()
            buckets.setdefault(h, []).append(str(p.relative_to(root)))
    return [v for v in buckets.values() if len(v) > 1]
