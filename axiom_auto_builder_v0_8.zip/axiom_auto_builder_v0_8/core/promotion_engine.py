from __future__ import annotations

def score(metrics: dict[str, float]) -> float:
    weights = {'proof':1.0,'validation':1.0,'reuse':0.9,'fertility':0.9,'compression':0.8,'automation':0.7,'dedupe':-0.5,'uncertainty':-0.6}
    return round(sum(weights.get(k,0.0)*v for k,v in metrics.items()), 3)

def verdict(value: float) -> str:
    if value >= 3.7: return 'promoted'
    if value >= 3.0: return 'crystallizable'
    if value >= 1.0: return 'exploratory'
    return 'quarantine'
