from __future__ import annotations
import json
from pathlib import Path

def create_release_capsule(root: Path, version: str, report: dict | None = None) -> dict:
    summary=(report or {}).get('summary', {})
    capsule={
        'schema':'axiom-release-capsule-v0.6',
        'version':version,
        'verdict': summary.get('promotion','unknown'),
        'score': summary.get('global_score',0),
        'canon_guard': summary.get('canon_guard','unknown'),
        'primary_command':'python3 -S axiom.py run',
        'artifacts':['reports/orchestration_report.md','proofs/proof_bundle.json','observability/metrics_snapshot.md','audit/audit_report.md']
    }
    dst=root/'release/release_capsule.json'; dst.write_text(json.dumps(capsule, indent=2), encoding='utf-8')
    md=['# Release Capsule v0.6','',f"version: {version}",f"verdict: {capsule['verdict']}",f"score: {capsule['score']}",f"canon_guard: {capsule['canon_guard']}",'','## Artifacts',*(f"- {a}" for a in capsule['artifacts'])]
    (root/'release/RELEASE_CAPSULE.md').write_text('\n'.join(md)+'\n', encoding='utf-8')
    return capsule
