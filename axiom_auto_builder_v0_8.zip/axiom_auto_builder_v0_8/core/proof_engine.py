from __future__ import annotations
import hashlib, json
from pathlib import Path

def build_proof_bundle(root: Path) -> dict:
    files=['reports/orchestration_report.json','reports/artifact_ledger.json','generated/hypergraph/project_hypergraph.json','generated/hypergraph/task_graph.json']
    proofs=[]
    for rel in files:
        p=root/rel
        proofs.append({'path': rel, 'exists': p.exists(), 'sha256': hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None})
    out={'schema':'axiom-proof-bundle-v0.6','proofs':proofs,'all_present':all(x['exists'] for x in proofs)}
    dst=root/'proofs/proof_bundle.json'; dst.write_text(json.dumps(out, indent=2), encoding='utf-8')
    return out
