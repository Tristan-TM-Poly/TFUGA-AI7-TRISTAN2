from __future__ import annotations

def next_mutations(report: dict) -> list[dict]:
    failed = report.get('summary',{}).get('failed',0)
    skipped = report.get('summary',{}).get('skipped',0)
    out=[]
    if failed: out.append({'priority':1,'mutation':'repair failing tasks before adding features'})
    if skipped: out.append({'priority':2,'mutation':'install optional toolchains or keep optional gates explicit'})
    out.append({'priority':3,'mutation':'add dashboard and benchmark layer'})
    out.append({'priority':4,'mutation':'connect GOLIATH LaTeX factory to reports'})
    return out
