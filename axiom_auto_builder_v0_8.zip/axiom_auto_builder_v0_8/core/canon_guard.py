from __future__ import annotations

from pathlib import Path

REQUIRED = ['README.md','core/orchestrator.py','configs/project_manifest.yaml','docs/CANON.md']

def check(root: Path) -> dict:
    missing=[x for x in REQUIRED if not (root/x).exists()]
    return {'status':'passed' if not missing else 'failed','missing':missing,'protected':REQUIRED}
