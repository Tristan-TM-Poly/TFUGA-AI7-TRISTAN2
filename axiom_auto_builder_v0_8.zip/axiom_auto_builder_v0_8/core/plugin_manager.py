from __future__ import annotations

from pathlib import Path

class PluginManager:
    def __init__(self, root: Path) -> None:
        self.root = root
    def discover(self) -> list[str]:
        plugin_dir = self.root / "plugins"
        if not plugin_dir.exists():
            return []
        return sorted(p.name for p in plugin_dir.iterdir() if p.is_dir())
