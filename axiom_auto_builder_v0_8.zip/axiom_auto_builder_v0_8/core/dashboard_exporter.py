from __future__ import annotations
import json
from pathlib import Path

def export_dashboard(root: Path, report: dict | None = None) -> dict:
    summary=(report or {}).get('summary', {})
    cards=[
        {'title':'Promotion','value':summary.get('promotion','unknown')},
        {'title':'Global score','value':summary.get('global_score',0)},
        {'title':'Passed','value':summary.get('passed',0)},
        {'title':'Failed','value':summary.get('failed',0)},
        {'title':'Canon guard','value':summary.get('canon_guard','unknown')},
    ]
    out={'schema':'axiom-dashboard-v0.6','cards':cards}
    dst=root/'dashboards/dashboard.json'; dst.write_text(json.dumps(out, indent=2), encoding='utf-8')
    md=['# Axiom Dashboard v0.6','',*(f"## {c['title']}\n{c['value']}\n" for c in cards)]
    (root/'dashboards/dashboard.md').write_text('\n'.join(md), encoding='utf-8')
    return out
