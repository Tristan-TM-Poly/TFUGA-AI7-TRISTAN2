from __future__ import annotations
import json, time
from pathlib import Path

def run_benchmarks(root: Path) -> dict:
    start=time.perf_counter()
    count=sum(1 for _ in root.glob('core/*.py'))
    elapsed=time.perf_counter()-start
    out={'schema':'axiom-benchmark-v0.6','benchmarks':[{'name':'core_file_scan','items':count,'seconds':round(elapsed,6)}]}
    dst=root/'benchmarks/benchmark_report.json'; dst.write_text(json.dumps(out, indent=2), encoding='utf-8')
    return out
