from __future__ import annotations

from pathlib import Path

def render(text: str, **values: str) -> str:
    for k, v in values.items():
        text = text.replace("{{" + k + "}}", v)
    return text

def render_file(template: Path, output: Path, **values: str) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(render(template.read_text(encoding="utf-8"), **values), encoding="utf-8")
