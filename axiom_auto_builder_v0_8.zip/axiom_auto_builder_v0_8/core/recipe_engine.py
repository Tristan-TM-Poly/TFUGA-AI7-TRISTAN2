from __future__ import annotations
import json
from pathlib import Path

def compile_recipes(root: Path) -> dict:
    rows=[]
    for path in sorted((root/'recipes').glob('*.json')):
        try:
            data=json.loads(path.read_text(encoding='utf-8'))
            steps=data.get('steps', [])
            rows.append({'id': data.get('id', path.stem), 'path': str(path.relative_to(root)), 'steps': len(steps), 'status': 'compiled' if steps else 'empty'})
        except Exception as exc:
            rows.append({'id': path.stem, 'path': str(path.relative_to(root)), 'status': 'invalid', 'error': str(exc)})
    out={'schema':'axiom-recipe-compile-v0.6','recipes':rows,'count':len(rows)}
    dst=root/'generated/recipes/recipe_compile_report.json'; dst.parent.mkdir(parents=True, exist_ok=True); dst.write_text(json.dumps(out, indent=2), encoding='utf-8')
    return out
