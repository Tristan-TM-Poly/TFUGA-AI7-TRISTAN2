from __future__ import annotations

class AxiomError(Exception):
    """Base automation error."""
class ToolchainMissing(AxiomError):
    """Raised when a required optional toolchain is absent."""
class ValidationError(AxiomError):
    """Raised when a repository invariant fails."""
