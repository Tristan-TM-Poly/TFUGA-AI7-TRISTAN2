from __future__ import annotations
import json
from pathlib import Path

def discover_plugins(root: Path) -> dict:
    plugins_dir = root / 'plugins'
    rows = []
    for manifest in sorted(plugins_dir.glob('**/plugin.json')):
        try:
            data = json.loads(manifest.read_text(encoding='utf-8'))
        except Exception as exc:
            data = {'id': manifest.parent.name, 'status': 'invalid', 'error': str(exc)}
        data.setdefault('id', manifest.parent.name)
        data.setdefault('path', str(manifest.parent.relative_to(root)))
        rows.append(data)
    out = {'schema': 'axiom-plugin-index-v0.6', 'count': len(rows), 'plugins': rows}
    path = root / 'generated' / 'plugins' / 'plugin_index.json'
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(out, indent=2), encoding='utf-8')
    return out
