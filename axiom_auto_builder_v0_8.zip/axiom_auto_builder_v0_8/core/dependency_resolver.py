from __future__ import annotations

from core.task_registry import TaskSpec

def topological_sort(tasks: list[TaskSpec]) -> list[TaskSpec]:
    by = {t.name: t for t in tasks}
    seen: set[str] = set()
    temp: set[str] = set()
    out: list[TaskSpec] = []
    def visit(name: str) -> None:
        if name in seen or name not in by:
            return
        if name in temp:
            raise ValueError(f"cycle detected at {name}")
        temp.add(name)
        for dep in by[name].depends_on:
            visit(dep)
        temp.remove(name)
        seen.add(name)
        out.append(by[name])
    for t in tasks:
        visit(t.name)
    return out
