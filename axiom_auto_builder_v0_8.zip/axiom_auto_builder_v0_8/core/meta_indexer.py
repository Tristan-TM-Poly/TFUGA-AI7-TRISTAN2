from __future__ import annotations
import json
from pathlib import Path

def build_meta_index(root: Path) -> dict:
    groups={}
    for p in root.rglob('*'):
        if p.is_file() and '.git' not in p.parts and '__pycache__' not in p.parts:
            top=p.relative_to(root).parts[0]
            groups[top]=groups.get(top,0)+1
    out={'schema':'axiom-meta-index-v0.6','groups':groups,'total_files':sum(groups.values())}
    dst=root/'meta/meta_index.json'; dst.write_text(json.dumps(out, indent=2), encoding='utf-8')
    return out
