from __future__ import annotations

from pathlib import Path
from typing import Any

def tiny_yaml(path: Path) -> dict[str, Any]:
    data: dict[str, Any] = {"languages": [], "promotion_thresholds": {}, "automation_layers": []}
    current = None
    item = None
    if not path.exists():
        return data
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.rstrip()
        if not line or line.lstrip().startswith("#"):
            continue
        if not line.startswith(" ") and line.endswith(":"):
            current = line[:-1]
            item = None
            continue
        if not line.startswith(" ") and ":" in line:
            k, v = line.split(":", 1)
            data[k.strip()] = v.strip().strip('"')
            current = None
            continue
        s = line.strip()
        if current == "languages":
            if s.startswith("- id:"):
                item = {"id": s.split(":", 1)[1].strip().strip('"')}
                data["languages"].append(item)
            elif item is not None and ":" in s:
                k, v = s.split(":", 1)
                val = v.strip().strip('"')
                item[k.strip()] = None if val == "null" else val
        elif current == "promotion_thresholds" and ":" in s:
            k, v = s.split(":", 1)
            try: data["promotion_thresholds"][k.strip()] = float(v.strip())
            except ValueError: data["promotion_thresholds"][k.strip()] = v.strip().strip('"')
        elif current == "automation_layers" and s.startswith("-"):
            data["automation_layers"].append(s[1:].strip())
    return data
