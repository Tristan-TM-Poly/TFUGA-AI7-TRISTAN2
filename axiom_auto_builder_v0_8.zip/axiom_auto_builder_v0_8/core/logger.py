from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

class JsonlLogger:
    def __init__(self, path: Path) -> None:
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)
    def log(self, level: str, message: str, **fields: Any) -> None:
        row = {"time": datetime.now(timezone.utc).isoformat(), "level": level, "message": message, **fields}
        with self.path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(row, ensure_ascii=False) + "
")
        print(f"[{level}] {message}")
