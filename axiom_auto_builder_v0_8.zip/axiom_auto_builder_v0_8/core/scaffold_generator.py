from __future__ import annotations

from pathlib import Path

class ScaffoldGenerator:
    def __init__(self, root: Path) -> None:
        self.root = root
    def new_component(self, name: str) -> Path:
        base = self.root / "generated" / "components" / name
        base.mkdir(parents=True, exist_ok=True)
        (base / "README.md").write_text(f"# {name}

Generated component scaffold.
", encoding="utf-8")
        return base
