from __future__ import annotations
import json, time
from pathlib import Path

def write_observability(root: Path, report: dict | None = None) -> dict:
    summary=(report or {}).get('summary', {})
    metrics={
        'passed': summary.get('passed', 0),
        'failed': summary.get('failed', 0),
        'skipped': summary.get('skipped', 0),
        'global_score': summary.get('global_score', 0),
        'promotion': summary.get('promotion', 'unknown'),
        'timestamp_unix': int(time.time())
    }
    out={'schema':'axiom-observability-v0.6','metrics':metrics,'signals':[{'name':k,'value':v} for k,v in metrics.items()]}
    dst=root/'observability/metrics_snapshot.json'; dst.write_text(json.dumps(out, indent=2), encoding='utf-8')
    md=['# Observability Snapshot','',*(f'- {k}: {v}' for k,v in metrics.items())]
    (root/'observability/metrics_snapshot.md').write_text('\n'.join(md)+'\n', encoding='utf-8')
    return out
