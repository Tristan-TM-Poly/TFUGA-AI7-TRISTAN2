# Meta-Automation v0.6

The v0.6 loop is:

1. inspect available tools;
2. generate or refresh modules;
3. validate repository health;
4. build task and project hypergraphs;
5. calculate synergies;
6. produce GOLIATH reports;
7. compile recipes;
8. discover plugins;
9. emit observability snapshots;
10. build proof bundles;
11. run audit checks;
12. create a release capsule.

This is the seed of recursive AI-7 style construction: produce, verify, test, analyze, optimize, integrate, crystallize, document, promote.
