# Automation Loop

produce -> verify -> test -> analyze -> optimize -> reproduce -> integrate -> crystallize -> document -> promote.

Every mutation must be validated before promotion.
