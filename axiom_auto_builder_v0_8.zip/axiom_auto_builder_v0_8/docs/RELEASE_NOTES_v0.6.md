# Release Notes v0.6

v0.6 turns the builder into a stronger meta-construction platform. It adds plugin discovery, recipe compilation, observability snapshots, proof bundles, audit reports, release capsules, benchmarks, dashboard exports, and a meta-index.

Primary command:

```bash
python3 -S axiom.py run
```

Design rule: every new organ must either improve proof, reuse, automation, observability, or canon protection.
