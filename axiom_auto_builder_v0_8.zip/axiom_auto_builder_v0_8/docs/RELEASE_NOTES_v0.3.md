# Release Notes v0.3

## Max Plus Ultra additions

- Added recursive self-improvement plan generation.
- Added task graph generation with dependencies and optional toolchain policy.
- Added generated template library for Python, C, C++, Rust, C#, and Atlas nodes.
- Added repository validation without third-party dependencies.
- Added artifact checksum ledger for reproducibility.
- Added Mermaid graph export tool.
- Upgraded scoring toward proof, validation, reuse, fertility, compression, duplication, and uncertainty.
- Upgraded reports with self-improvement actions and artifact counts.

## Local validation

The v0.3 trunk was executed through the orchestrator API and produced:

- passed: 6
- failed: 0
- skipped: 3 optional toolchain-policy tasks
- promotion: promoted
- global score: 4.189

The smoke test and Mermaid graph exporter also passed.
