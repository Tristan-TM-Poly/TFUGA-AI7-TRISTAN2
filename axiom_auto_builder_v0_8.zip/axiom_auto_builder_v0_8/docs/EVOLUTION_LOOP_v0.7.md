# Evolution Loop v0.7

This layer adds a resumable multi-generation self-analysis and self-improvement loop.

The loop does not blindly rewrite the repository. It evolves a compact genome of automation parameters, evaluates candidates against repository metrics, records lineage, emits checkpoints, and prepares future promoted mutations through the canon guard.

Run a bounded thousand-generation campaign:

```bash
python3 -S axiom.py evolve --generations 1000 --population 12 --checkpoint-every 100
```

Run a fast smoke test:

```bash
python3 -S axiom.py evolve --generations 25 --population 6 --checkpoint-every 5
```

State is stored in:

- `evolution/state.json`
- `evolution/summary.json`
- `evolution/EVOLUTION_REPORT.md`
- `evolution/checkpoints/`

The intended lifecycle is:

1. evolve candidates
2. checkpoint lineage
3. select best genome
4. generate improvement plan
5. validate with canon guard
6. promote only if all gates pass
