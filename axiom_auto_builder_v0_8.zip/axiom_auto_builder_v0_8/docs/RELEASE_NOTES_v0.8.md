# Release Notes v0.8

Adds bidirectional performance/resource curve fitting for algorithms, pipelines, and the repository itself.

## New command

```bash
python3 -S axiom.py perf-fit
```

## Outputs

- `performance/raw_metrics.json`
- `performance/curvefit_report.json`
- `performance/bidirectional_models.json`
- `performance/repository_algorithm_inventory.json`
- `performance/pipeline_metrics.json`
- `performance/PERFORMANCE_REPORT.md`
- `thesis/THESIS_PERFORMANCE_FOUNDATION.md`
- `thesis/PROOF_PROTOCOL.md`

## Scientific boundary

The layer provides reproducible, falsifiable, assumption-explicit evidence. It avoids unsupported claims of absolute proof.
