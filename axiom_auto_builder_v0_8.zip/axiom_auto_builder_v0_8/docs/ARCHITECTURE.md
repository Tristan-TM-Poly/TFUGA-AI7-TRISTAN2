# Architecture v0.4

Axiom Auto Builder is split into a trunk and growing branches.

- core: orchestration, tasks, execution, promotion, canon guard.
- languages: Python, C, C++, Rust, C#, FFI plan.
- hypergraph: typed project graph and synergy rules.
- atlas: AI-7 workflow contracts.
- goliath: report factory and LaTeX preparation.
- tools: validation, graph export, quality scoring.
