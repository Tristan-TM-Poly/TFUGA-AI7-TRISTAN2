# Canon v0.4

Rule 1: protect the trunk.
Rule 2: every generated branch must be testable or explicitly optional.
Rule 3: promote only verified nodes.
Rule 4: keep one command as the stable user interface.
Rule 5: reports are part of the proof trail.
