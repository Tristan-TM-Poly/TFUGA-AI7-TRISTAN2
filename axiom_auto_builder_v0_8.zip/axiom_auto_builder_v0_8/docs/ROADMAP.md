# Roadmap

v0.5: dashboard, plugin packaging, benchmark suite, stronger GOLIATH reports.
v0.6: FFI prototype and cross-language bindings.
v1.0: stable AI-7 automation platform.
