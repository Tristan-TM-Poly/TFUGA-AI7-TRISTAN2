# Release Notes v0.7

v0.7 adds the evolution loop: a resumable engine for thousands of generations of self-analysis and self-improvement.

Highlights:

- `core/evolution_engine.py`
- `axiom.py evolve`
- candidate genomes
- mutation and selection
- scoring against repository metrics
- checkpointing
- lineage tracking
- `evolution/state.json`
- `evolution/summary.json`
- `evolution/EVOLUTION_REPORT.md`
- `scripts/evolve_1000.sh`
- `scripts/evolve_10000.sh`
- canon-safe evolution policy

The loop is intentionally canon-guarded: it evolves plans and parameters first, then promotes only through validation gates.
