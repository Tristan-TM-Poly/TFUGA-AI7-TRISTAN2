# Hypergraph Canon

Nodes are typed artifacts. Edges are typed relations. Promotion requires proof, validation, reuse, fertility, compression, and low uncertainty.
