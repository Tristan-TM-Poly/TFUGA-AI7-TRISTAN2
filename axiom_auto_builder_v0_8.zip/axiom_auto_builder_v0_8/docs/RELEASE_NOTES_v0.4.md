# Release Notes v0.4

Added top-100 expansion: modular core, task registry, execution engine, dependency resolver, self-improver, promotion engine, canon guard, multi-language scaffolds, build matrix, validators, hypergraph rules, Atlas workflows, GOLIATH report factory, CLI, scripts, tests, and documentation.
