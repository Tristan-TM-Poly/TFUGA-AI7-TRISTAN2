# Multi-language Stack

Rust -> C++ -> C -> C# -> Python -> Atlas is treated as a layered ecosystem.
The stable ABI boundary is C. Experimental higher-level branches must not contaminate the canon.
