# Max Plus Ultra Roadmap v0.3

## Wave 1: Deterministic Trunk
- keep the orchestrator dependency-free
- validate repository structure
- maintain a checksum ledger
- skip optional toolchains cleanly

## Wave 2: Recursive Construction
- generate templates for each language
- generate task graph and project hypergraph
- produce self-improvement plan from observed failures and skipped tasks

## Wave 3: AI-7 / GOLIATH Expansion
- add benchmark runner
- export hypergraph to DOT and Mermaid
- generate LaTeX technical reports
- create Atlas HTML dashboard
- add promotion scorecards per generated module

## Wave 4: Multi-scale Integration
- connect generated code modules to experimental pipelines
- attach Raman/percolation/TFUGA project nodes
- make reports cite data, code, tests, and validation artifacts
