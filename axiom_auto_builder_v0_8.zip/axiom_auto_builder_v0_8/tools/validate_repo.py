from __future__ import annotations
from pathlib import Path
import sys
root = Path(__file__).resolve().parents[1]
required = ['README.md','axiom.py','core/orchestrator.py','configs/project_manifest.yaml','docs/CANON.md']
missing=[x for x in required if not (root/x).exists()]
if missing:
    print('missing:'+','.join(missing)); sys.exit(1)
print('repo:ok')
