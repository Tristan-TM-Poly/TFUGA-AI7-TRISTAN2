from __future__ import annotations
import json, sys
from pathlib import Path
p=Path(__file__).resolve().parents[1]/'generated/hypergraph/project_hypergraph.json'
g=json.loads(p.read_text(encoding='utf-8'))
assert g.get('nodes') and g.get('edges')
print('hypergraph:ok')
