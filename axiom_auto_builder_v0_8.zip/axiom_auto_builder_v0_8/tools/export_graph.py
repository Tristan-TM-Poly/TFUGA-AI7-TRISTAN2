#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
GRAPH = ROOT / "generated" / "hypergraph" / "project_hypergraph.json"
OUT = ROOT / "generated" / "hypergraph" / "project_hypergraph.mmd"


def safe(x: str) -> str:
    return x.replace(":", "_").replace("-", "_").replace("/", "_").replace(".", "_")


def main() -> int:
    if not GRAPH.exists():
        print("missing graph; run orchestrator first")
        return 1
    graph = json.loads(GRAPH.read_text(encoding="utf-8"))
    lines = ["graph TD"]
    for node in graph.get("nodes", []):
        nid = node.get("id", "node")
        label = f"{nid}\\n{node.get('type','')}"
        lines.append(f"  {safe(nid)}[\"{label}\"]")
    for edge in graph.get("edges", []):
        source = safe(edge.get("source", "a"))
        target = safe(edge.get("target", "b"))
        etype = edge.get("type", "rel")
        lines.append(f"  {source} -- {etype} --> {target}")
    OUT.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(OUT.relative_to(ROOT))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
