from __future__ import annotations
import json
from pathlib import Path
root = Path(__file__).resolve().parents[1]
g = json.loads((root / 'generated/hypergraph/project_hypergraph.json').read_text(encoding='utf-8'))
lines = ['digraph axiom {']
for e in g.get('edges', []):
    lines.append(f"  \"{e.get('source')}\" -> \"{e.get('target')}\" [label=\"{e.get('type')}\"];")
lines.append('}')
(root / 'generated/hypergraph/project_hypergraph.dot').write_text('\n'.join(lines) + '\n', encoding='utf-8')
print('graphviz:ok')
