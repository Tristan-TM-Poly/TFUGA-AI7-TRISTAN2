from __future__ import annotations
import json
from pathlib import Path
root = Path(__file__).resolve().parents[1]
g = json.loads((root / 'generated/hypergraph/project_hypergraph.json').read_text(encoding='utf-8'))
lines = ['graph TD']
for e in g.get('edges', []):
    a = e.get('source', 'x').replace(':', '_').replace('-', '_')
    b = e.get('target', 'y').replace(':', '_').replace('-', '_')
    lines.append(f"  {a} -->|{e.get('type','rel')}| {b}")
(root / 'generated/hypergraph/project_hypergraph.mmd').write_text('\n'.join(lines) + '\n', encoding='utf-8')
print('mermaid:ok')
