from pathlib import Path
root=Path(__file__).resolve().parents[1]
print(f'markdown:files:{len(list(root.rglob("*.md")))}')
