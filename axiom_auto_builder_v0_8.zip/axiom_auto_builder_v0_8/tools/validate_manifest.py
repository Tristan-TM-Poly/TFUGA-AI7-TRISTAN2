from __future__ import annotations
from pathlib import Path
import sys
p=Path(__file__).resolve().parents[1]/'configs/project_manifest.yaml'
text=p.read_text(encoding='utf-8')
for token in ['name:','version:','languages:']:
    assert token in text, token
print('manifest:ok')
