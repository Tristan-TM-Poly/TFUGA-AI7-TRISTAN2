from pathlib import Path
root=Path(__file__).resolve().parents[1]
count=len(list(root.rglob('*.yaml')))+len(list(root.rglob('*.yml')))
print(f'yaml:present:{count}')
