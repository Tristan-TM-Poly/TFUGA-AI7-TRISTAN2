from pathlib import Path
root=Path(__file__).resolve().parents[1]
print('
'.join(str(p.relative_to(root)) for p in root.rglob('*') if p.is_file())[:4000])
