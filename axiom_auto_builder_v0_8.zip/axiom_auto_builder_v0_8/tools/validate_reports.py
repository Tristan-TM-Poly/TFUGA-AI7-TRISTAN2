from __future__ import annotations
from pathlib import Path
import sys
root=Path(__file__).resolve().parents[1]
needed=['reports/orchestration_report.json','reports/orchestration_report.md','reports/toolchain_inspection.json']
missing=[x for x in needed if not (root/x).exists()]
if missing: print('missing reports:'+','.join(missing)); sys.exit(1)
print('reports:ok')
