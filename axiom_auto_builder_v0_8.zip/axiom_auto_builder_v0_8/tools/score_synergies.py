from __future__ import annotations
import json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
g=json.loads((root/'generated/hypergraph/project_hypergraph.json').read_text(encoding='utf-8')) if (root/'generated/hypergraph/project_hypergraph.json').exists() else {'edges':[]}
score=round(len(g.get('edges',[]))/10,3)
out={'synergy_score':score,'top':['orchestrator->canon','self_improver->orchestrator','toolchain->task']}
(root/'reports/synergy_report.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(out)
