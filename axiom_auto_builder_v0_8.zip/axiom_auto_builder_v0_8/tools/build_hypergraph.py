from __future__ import annotations
import subprocess, sys
sys.exit(subprocess.call('python3 -S axiom.py graph', shell=True))
