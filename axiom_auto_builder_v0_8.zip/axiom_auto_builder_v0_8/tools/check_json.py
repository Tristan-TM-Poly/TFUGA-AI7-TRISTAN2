from pathlib import Path
import json
root=Path(__file__).resolve().parents[1]
count=0
for p in root.rglob('*.json'):
    json.loads(p.read_text(encoding='utf-8')); count+=1
print(f'json:ok:{count}')
