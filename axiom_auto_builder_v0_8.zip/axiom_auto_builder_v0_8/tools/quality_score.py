from pathlib import Path
root=Path(__file__).resolve().parents[1]
py=len(list(root.rglob('*.py'))); docs=len(list(root.rglob('*.md'))); js=len(list(root.rglob('*.json')))
print({'python_files':py,'docs':docs,'json':js,'quality_score':round((py+docs+js)/10,2)})
