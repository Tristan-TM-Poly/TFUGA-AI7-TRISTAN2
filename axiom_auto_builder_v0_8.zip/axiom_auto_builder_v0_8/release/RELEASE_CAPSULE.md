# Release Capsule v0.6

version: 0.6
verdict: promoted
score: 5.82
canon_guard: passed

## Artifacts
- reports/orchestration_report.md
- proofs/proof_bundle.json
- observability/metrics_snapshot.md
- audit/audit_report.md
