Rollback marker. Use git or archive copy for full rollback.
