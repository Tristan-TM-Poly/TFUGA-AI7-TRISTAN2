fn main(){ println!("{{name}}:ok"); }
