#include <iostream>
int main(){ std::cout << "{{name}}:ok\n"; return 0; }
