using System;
Console.WriteLine("{{name}}:ok");
