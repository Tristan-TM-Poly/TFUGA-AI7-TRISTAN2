def run():
    return {'node': '{{name}}', 'status': 'ok'}
