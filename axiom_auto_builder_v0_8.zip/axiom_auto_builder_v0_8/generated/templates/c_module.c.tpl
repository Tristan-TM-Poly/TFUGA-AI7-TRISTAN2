#include <stdio.h>
int main(void){ puts("{{name}}:ok"); return 0; }
