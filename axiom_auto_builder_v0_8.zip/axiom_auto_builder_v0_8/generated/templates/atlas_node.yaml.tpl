id: {{name}}
kind: atlas-node
status: seed
