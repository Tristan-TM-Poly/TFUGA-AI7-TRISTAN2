from pathlib import Path
p=Path(__file__).resolve().parents[1]/'generated/templates'
print('test_templates:ok' if p.exists() else 'test_templates:pending')
