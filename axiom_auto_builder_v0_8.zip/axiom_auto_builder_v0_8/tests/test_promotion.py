import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from core.promotion_engine import score, verdict
assert verdict(score({'proof':1,'validation':1,'reuse':1,'fertility':1,'compression':1,'automation':1,'dedupe':0,'uncertainty':0})) == 'promoted'
print('test_promotion:ok')
