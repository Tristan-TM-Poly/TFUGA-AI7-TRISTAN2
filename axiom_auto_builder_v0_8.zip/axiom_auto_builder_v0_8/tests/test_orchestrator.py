from pathlib import Path
assert (Path(__file__).resolve().parents[1]/'core/orchestrator.py').exists()
print('test_orchestrator:ok')
