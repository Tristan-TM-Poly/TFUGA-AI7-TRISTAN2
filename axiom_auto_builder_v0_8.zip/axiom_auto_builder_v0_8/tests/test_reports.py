from pathlib import Path
p=Path(__file__).resolve().parents[1]/'reports'
p.mkdir(exist_ok=True)
print('test_reports:ok')
