#!/usr/bin/env python3
from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def load_orchestrator():
    spec = importlib.util.spec_from_file_location("axiom_orchestrator", ROOT / "core" / "orchestrator.py")
    module = importlib.util.module_from_spec(spec)
    sys.modules["axiom_orchestrator"] = module
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


def main() -> int:
    orch = load_orchestrator()
    orch.ensure_dirs()
    manifest = orch.tiny_yaml_manifest()
    tools = orch.inspect_toolchains()
    tasks = orch.generate_task_graph(manifest)
    orch.generate_hypergraph(manifest, tools, tasks)
    orch.generate_modules()
    validation = orch.validate_repository()
    assert all(r.status == "passed" for r in validation), validation
    graph = ROOT / "generated" / "hypergraph" / "project_hypergraph.json"
    task_graph = ROOT / "generated" / "hypergraph" / "task_graph.json"
    api = ROOT / "generated" / "modules" / "axiom_generated_api.py"
    assert graph.exists(), "project graph missing"
    assert task_graph.exists(), "task graph missing"
    assert api.exists(), "generated api missing"
    payload = json.loads(graph.read_text(encoding="utf-8"))
    assert payload["nodes"], "graph has no nodes"
    print("smoke:ok")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
