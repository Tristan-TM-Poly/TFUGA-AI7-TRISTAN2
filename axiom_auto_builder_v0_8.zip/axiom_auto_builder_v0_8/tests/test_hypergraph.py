import json
from pathlib import Path
p=Path(__file__).resolve().parents[1]/'generated/hypergraph/project_hypergraph.json'
if p.exists(): assert json.loads(p.read_text()).get('nodes') is not None
print('test_hypergraph:ok')
