import shutil
assert shutil.which('python3')
print('test_toolchains:ok')
