# Axiom v0.8 Bidirectional Performance/Resource Curvefit Report

Generated: 2026-04-28T03:50:41.502897+00:00

## Scientific status

This report provides reproducible empirical evidence and fitted models under explicit assumptions. It does not claim absolute irrefutability; it gives auditable, repeatable, falsifiable proof protocols suitable for thesis development.

## Best fitted kernels
- **linear_scan**: time `time_sec ≈ -6.77925e-05 + 2.65431e-07 n + -1.68478e-08 n log(n) + 3.67761e-14 n²`, R²=1.0; resource `rss_kb ≈ 0`, R²=1.0
- **sort**: time `time_sec ≈ -0.00160374 + 1.10819e-05 n + -1.29911e-06 n log(n) + 1.76177e-10 n²`, R²=1.0; resource `rss_kb ≈ -31.4949 + 0.201219 n + -0.0250416 n log(n) + 3.25724e-06 n²`, R²=1.0
- **hash_stream**: time `time_sec ≈ -0.00188305 + 1.23203e-05 n + -1.48171e-06 n log(n) + 1.94217e-10 n²`, R²=1.0; resource `rss_kb ≈ 0`, R²=1.0
- **json_roundtrip**: time `time_sec ≈ 9.88389e-05 + 1.32089e-06 n + -3.11656e-08 n log(n) + 9.86956e-11 n²`, R²=1.0; resource `rss_kb ≈ -53.0525 + 1.30461 n + -0.200858 n log(n) + 0.00012431 n²`, R²=1.0
- **matrix_kernel**: time `time_sec ≈ 0.000257326 + -4.77618e-05 n + 1.24805e-05 n log(n) + -3.94978e-08 n²`, R²=1.0; resource `rss_kb ≈ 0`, R²=1.0

## Bidirectional principle

Forward model: estimate performance and resource demand from scale `n`.

`time = f_algorithm(n)` and `resource = g_algorithm(n)`

Backward model: estimate maximum feasible scale from a target budget.

`n_max = f_algorithm^{-1}(target_time)` and `resource_required = g_algorithm(n_max)`

## Repository algorithm inventory
- `core/audit_engine.py`: lines=17, functions=1, complexity_proxy=6.34
- `core/benchmark_engine.py`: lines=11, functions=1, complexity_proxy=6.22
- `core/canon_guard.py`: lines=9, functions=1, complexity_proxy=5.18
- `core/config_loader.py`: lines=40, functions=1, complexity_proxy=6.8
- `core/context.py`: lines=23, functions=3, complexity_proxy=18.46
- `core/dashboard_exporter.py`: lines=18, functions=1, complexity_proxy=6.36
- `core/dependency_resolver.py`: lines=23, functions=2, complexity_proxy=8.46
- `core/duplicate_detector.py`: lines=12, functions=1, complexity_proxy=6.24
- `core/errors.py`: lines=8, functions=0, complexity_proxy=16.16
- `core/events.py`: lines=19, functions=3, complexity_proxy=23.38
- `core/evolution_engine.py`: lines=249, functions=13, complexity_proxy=57.98
- `core/execution_engine.py`: lines=37, functions=4, complexity_proxy=27.74
- `core/logger.py`: lines=17, functions=2, complexity_proxy=16.34
- `core/meta_indexer.py`: lines=13, functions=1, complexity_proxy=6.26
- `core/module_generator.py`: lines=31, functions=5, complexity_proxy=22.62
- `core/mutation_planner.py`: lines=11, functions=1, complexity_proxy=4.22
- `core/observability_engine.py`: lines=19, functions=1, complexity_proxy=6.38
- `core/orchestrator.py`: lines=194, functions=11, complexity_proxy=53.88
- `core/performance_curvefit_engine.py`: lines=363, functions=22, complexity_proxy=83.26
- `core/plugin_manager.py`: lines=12, functions=2, complexity_proxy=13.24
- `core/plugin_system.py`: lines=20, functions=1, complexity_proxy=6.4
- `core/promotion_engine.py`: lines=11, functions=2, complexity_proxy=7.22
- `core/proof_engine.py`: lines=13, functions=1, complexity_proxy=6.26
- `core/recipe_engine.py`: lines=16, functions=1, complexity_proxy=6.32
- `core/refactor_advisor.py`: lines=12, functions=1, complexity_proxy=5.24
- `core/release_capsule.py`: lines=19, functions=1, complexity_proxy=6.38
- `core/rollback_manager.py`: lines=11, functions=1, complexity_proxy=5.22
- `core/scaffold_generator.py`: lines=15, functions=2, complexity_proxy=13.3
- `core/self_improver.py`: lines=12, functions=1, complexity_proxy=7.24
- `core/state_store.py`: lines=14, functions=3, complexity_proxy=18.28
- `core/task_registry.py`: lines=23, functions=4, complexity_proxy=25.46
- `core/template_engine.py`: lines=12, functions=2, complexity_proxy=8.24
- `tools/build_hypergraph.py`: lines=3, functions=0, complexity_proxy=2.06
- `tools/check_json.py`: lines=7, functions=0, complexity_proxy=2.14
- `tools/check_markdown_links.py`: lines=3, functions=0, complexity_proxy=1.06
- `tools/check_paths.py`: lines=4, functions=0, complexity_proxy=1.08
- `tools/check_yaml.py`: lines=4, functions=0, complexity_proxy=1.08
- `tools/export_graph.py`: lines=37, functions=2, complexity_proxy=9.74
- `tools/export_graphviz.py`: lines=11, functions=0, complexity_proxy=3.22
- `tools/export_mermaid.py`: lines=12, functions=0, complexity_proxy=3.24
- `tools/quality_score.py`: lines=4, functions=0, complexity_proxy=1.08
- `tools/score_synergies.py`: lines=9, functions=0, complexity_proxy=3.18
- `tools/validate_hypergraph.py`: lines=7, functions=0, complexity_proxy=3.14
- `tools/validate_manifest.py`: lines=8, functions=0, complexity_proxy=3.16
- `tools/validate_repo.py`: lines=9, functions=0, complexity_proxy=3.18
- `tools/validate_reports.py`: lines=8, functions=0, complexity_proxy=3.16
- `goliath/latex_builder.py`: lines=10, functions=1, complexity_proxy=5.2
- `goliath/report_factory.py`: lines=12, functions=1, complexity_proxy=5.24

## Pipeline timing samples
- `cli_validate`: 0.508353s, returncode=0, stdout=12B, stderr=0B
- `cli_inspect`: 0.509402s, returncode=0, stdout=1011B, stderr=0B
- `tool_check_json`: 0.287119s, returncode=0, stdout=11B, stderr=0B
