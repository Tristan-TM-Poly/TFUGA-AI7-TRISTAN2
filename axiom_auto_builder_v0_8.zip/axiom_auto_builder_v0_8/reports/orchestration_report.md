# Axiom Auto Builder v0.6 Report

- passed: 14
- failed: 0
- skipped: 0
- global_score: 5.82
- promotion: promoted
- canon_guard: passed
- audit: passed
- proof_bundle: passed
