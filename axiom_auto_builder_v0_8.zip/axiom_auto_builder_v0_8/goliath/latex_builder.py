from __future__ import annotations
from pathlib import Path

def render_latex(root: Path) -> Path:
    tpl = root / 'goliath' / 'templates' / 'technical_report.tex.j2'
    out = root / 'reports' / 'technical_report.tex'
    out.write_text(tpl.read_text(encoding='utf-8').replace('{{title}}','Axiom Technical Report'), encoding='utf-8')
    return out
if __name__ == '__main__':
    print(render_latex(Path(__file__).resolve().parents[1]))
