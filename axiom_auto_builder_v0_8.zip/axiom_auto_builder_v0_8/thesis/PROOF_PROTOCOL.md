# Proof Protocol v0.8

1. Freeze code version and artifact ledger.
2. Run benchmarks across scale ladder.
3. Fit multiple candidate models.
4. Select model by R², RMSE and parsimony.
5. Validate forward predictions on withheld scales.
6. Validate backward predictions against budgeted runs.
7. Promote only if results reproduce across machines/toolchains.
8. Record failures as counterexamples, not noise to hide.

This is the anti-brouillard rule: every performance claim must point to raw samples, model, residuals, environment, and version.
