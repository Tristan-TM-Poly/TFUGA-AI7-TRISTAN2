# Thesis Foundation: Bidirectional Curve Fitting for Self-Improving Multi-Language Pipelines

## Core thesis claim

For every algorithmic component or pipeline stage with measurable scale parameter `n`, define a bidirectional pair of empirical models:

`T_A(n; θ_T)` for performance and `R_A(n; θ_R)` for resource demand.

The forward direction predicts time/memory from workload scale. The backward direction estimates feasible workload scale from a resource/time budget.

## Proof protocol, not dogma

A proof is considered thesis-grade when it is reproducible, falsifiable, versioned, statistically scored, and tied to raw measurements. Absolute irrebuttability is not claimed; instead the system produces stronger evidence after every generation.

## Mathematical spine

Given samples `(n_i, t_i, r_i)`, estimate parameters by least squares:

`θ_T* = argmin_θ Σ_i (t_i - T_A(n_i; θ))²`

`θ_R* = argmin_θ Σ_i (r_i - R_A(n_i; θ))²`

Then evaluate `R²`, RMSE, residuals, monotonicity and extrapolation risk. Promotion to canon requires high fit quality plus independent reruns.

## Algorithms currently benchmarked
- `linear_scan` with 4 samples
- `sort` with 4 samples
- `hash_stream` with 4 samples
- `json_roundtrip` with 4 samples
- `matrix_kernel` with 4 samples
