# Axiom Auto Builder v0.6

A recursive multi-language automation forge for building, validating, scoring, documenting, and promoting software/theory modules through an AI-7 style loop.

## Run

```bash
python3 -S axiom.py run
```

## Full optional toolchain mode

```bash
AXIOM_FULL_BUILD=1 python3 -S axiom.py run
```

## v0.6 organs

- plugin discovery
- recipe compiler
- observability snapshots
- proof bundle
- audit report
- release capsule
- dashboard export
- meta-index
- benchmark report
- GOLIATH technical report

The canon rule is simple: generate boldly, promote carefully, preserve the trunk.

## v0.7 Evolution Loop

Adds a resumable thousand-generation self-analysis and self-improvement engine with genomes, scoring, checkpoints, lineage, reports, and canon-safe promotion gates.

Run:

```bash
python3 -S axiom.py evolve --generations 1000 --population 12 --checkpoint-every 100
```

## v0.8 Performance Curvefit Layer

Run bidirectional performance/resource fitting for repository algorithms and pipelines:

```bash
python3 -S axiom.py perf-fit
```

This generates reports in `performance/` and thesis-ready notes in `thesis/`.
