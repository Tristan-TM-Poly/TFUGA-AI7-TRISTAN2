# Axiom Auto Builder v0.4 Report

Generated: 2026-04-28T11:03:20.115804+00:00

passed: 13
failed: 0
skipped: 0
global_score: 5.34
promotion: promoted
canon_guard: passed

## Results
- generate:templates: passed (internal/no-op task)
- generate:modules: passed (internal/no-op task)
- canon:guard: passed (python3 -S -c "from pathlib import Path; from core.canon_guard import check; import json; r=check(Path('.')); print(json.dumps(r)); raise SystemExit(0 if r['status']=='passed' else 1)")
- python:test: passed (python3 -S languages/python/test_axiom_module.py)
- c:build: passed (gcc languages/c/axiom_core.c languages/c/test_axiom_core.c -o generated/bin/axiom_c)
- c:test: passed (./generated/bin/axiom_c)
- cpp:policy: passed (internal/no-op task)
- rust:policy: passed (internal/no-op task)
- csharp:policy: passed (internal/no-op task)
- validate:repo: passed (python3 -S tools/validate_repo.py)
- validate:manifest: passed (python3 -S tools/validate_manifest.py)
- graph:export: passed (python3 -S tools/export_mermaid.py && python3 -S tools/export_graphviz.py)
- score:synergies: passed (python3 -S tools/score_synergies.py)
