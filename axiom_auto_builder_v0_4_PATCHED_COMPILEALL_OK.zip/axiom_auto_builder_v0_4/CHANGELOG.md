# Changelog

## v0.4
- Added top-100 expansion plan implementation.
- Added modular core components.
- Added CLI, validators, hypergraph rules, build matrix, Atlas workflows, GOLIATH report factory.
- Added tests, scripts, docs, and promotion/canon guard logic.
