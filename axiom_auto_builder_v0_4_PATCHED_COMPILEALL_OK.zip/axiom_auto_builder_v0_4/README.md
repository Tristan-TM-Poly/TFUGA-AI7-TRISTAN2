# Axiom Auto Builder v0.4

Multi-scale, multi-language automation-of-automation nucleus.

## One command

```bash
python3 -S axiom.py run
```

## Full optional toolchains

```bash
AXIOM_FULL_BUILD=1 python3 -S axiom.py run
```

## What it does

1. Inspect toolchains.
2. Generate templates and modules.
3. Build and test available language layers.
4. Validate the repository and manifest.
5. Build the project hypergraph.
6. Export Mermaid and Graphviz graphs.
7. Score synergies and promotion.
8. Produce reports and a self-improvement plan.
9. Create an artifact ledger.
10. Prepare GOLIATH Markdown and LaTeX reports.
