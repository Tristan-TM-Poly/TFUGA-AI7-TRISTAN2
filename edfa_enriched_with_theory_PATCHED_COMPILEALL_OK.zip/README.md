# EDFA Design Kit - V4

Starter project Python OOP pour concevoir, analyser et documenter un amplificateur a fibre dopee a l'erbium (EDFA) a partir :
- d'une specsheet/projet PDF
- d'un article de reference sur les sections efficaces (Barnes 1991)
- d'equations symboliques `sympy`
- de solveurs numeriques `numpy`/`scipy`
- d'un workflow de rapport qui produit CSV + PNG + TEX + PDF.

## Ce que cette V4 ajoute
- ingestion PDF et extraction automatique de contraintes de la specsheet
- spectres `sigma_a(lambda)` et `sigma_e(lambda)` tabules avec interpolation lisse
- solveur EDFA avec iteration ASE avant/arriere auto-coherente
- optimisation multi-objectifs (longueur, pompe, densite relative d'erbium)
- notebook de calibration / identification
- export automatique d'un mini rapport en **Markdown**, **LaTeX** et **PDF**
- structure de code prete pour etendre vers des modeles plus riches

## Installation

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e .[full]
```

## CLI

```bash
edfa-kit ingest-pdfs --assignment docs/pdfs/Devoir1-H2023.pdf --barnes docs/pdfs/Barnes-1991-Er\ cross\ section.pdf
edfa-kit optimize --fiber ge_al_si --pump-max 0.30 --outdir artifacts/examples/optimize_run
edfa-kit make-report --fiber ge_al_si --pump-max 0.30 --outdir artifacts/examples/report_run_v4
```

## Hypotheses de modelisation
- Modele quasi-stationnaire a deux niveaux pour le sous-systeme Er3+.
- Pompe co-propageante 980 nm, emission stimulee de pompe negligee par defaut.
- Propagation signal par canal + ASE avant/arriere sur une grille spectrale.
- Les spectres Barnes fournis ici sont **des tabulations manuelles approximatives** servant de base de travail, pas une digitalisation metrologique certifiee.
- La figure de bruit utilise une approximation de preampli optique coherente avec un facteur d'emission spontanee local moyen.

## Structure
- `src/edfa_design_kit/domain.py` : modeles OOP
- `src/edfa_design_kit/repository.py` : chargement des donnees / specsheet / fibres
- `src/edfa_design_kit/pdf_ingest.py` : extraction PDF
- `src/edfa_design_kit/spectral.py` : interpolation des sections efficaces
- `src/edfa_design_kit/symbolic.py` : equations symboliques
- `src/edfa_design_kit/solver.py` : solveur EDFA + ASE
- `src/edfa_design_kit/optimizer.py` : recherche multi-objectifs
- `src/edfa_design_kit/calibration.py` : identification de parametres
- `src/edfa_design_kit/reporting.py` : production des rapports
- `notebooks/01_calibration_barnes.ipynb` : notebook de depart

## Notes de validation
Le projet est volontairement un **starter kit R&D** : il execute les flux principaux, produit des artefacts utiles, et fournit des points d'extension propres. Pour un usage publication/industrie, il faudrait ensuite :
- mieux calibrer les distributions radiales et les facteurs de recouvrement,
- utiliser des courbes experimentales digitalisees finement,
- raffiner le modele ASE et la definition exacte de NF selon la chaine de detection retenue,
- valider sur des donnees experimentales completes.


## Script verifie ici

Le chemin de generation de rapport verifie dans cet environnement est :

```bash
PYTHONPATH=src python scripts/generate_sample_report.py
```


## Generated theory knowledge

This project was enriched with auto-generated theory knowledge extracted from ChatGPT JSON corpora.

Generated assets:
- `docs/generated_theory/analysis_report.md`
- `data/generated_theory/analysis_report.json`
- `src/chatgpt_theory_knowledge/`
