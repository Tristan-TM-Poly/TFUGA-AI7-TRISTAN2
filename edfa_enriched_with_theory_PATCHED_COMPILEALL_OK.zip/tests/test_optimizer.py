from edfa_design_kit.optimizer import optimize_design


def test_optimizer_returns_candidates():
    ranked, pareto = optimize_design(n_pump=2, n_length=2, n_density=2)
    assert len(ranked) > 0
    assert len(pareto) > 0
