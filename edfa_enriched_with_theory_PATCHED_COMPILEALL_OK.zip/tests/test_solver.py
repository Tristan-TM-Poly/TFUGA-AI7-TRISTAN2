from edfa_design_kit.domain import EDFAConfig, PumpLaser, SignalChannel
from edfa_design_kit.repository import load_fiber_catalog
from edfa_design_kit.solver import EDFASolver
from edfa_design_kit.spectral import CrossSectionSpectrum


def test_solver_runs_and_gains():
    fiber = load_fiber_catalog()['ge_al_si']
    solver = EDFASolver(CrossSectionSpectrum.from_repository('ge_al_si'), n_steps=180, ase_iterations=4)
    cfg = EDFAConfig(fiber=fiber, pump=PumpLaser(power_w=0.20), length_m=5.8, channels=[SignalChannel(1550.0, 1e-6)])
    res = solver.solve(cfg)
    assert res.gain_db_by_channel[1550.0] > 15.0
    assert res.output_power_by_channel_w[1550.0] > 0
