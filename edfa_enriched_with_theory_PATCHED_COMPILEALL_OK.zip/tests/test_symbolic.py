from edfa_design_kit.symbolic import stationary_inversion_expr, noise_figure_expr


def test_symbolic_expressions_exist():
    assert stationary_inversion_expr().lhs is not None
    assert noise_figure_expr().rhs is not None
