from edfa_design_kit.repository import load_assignment_spec


def test_specsheet_values():
    spec = load_assignment_spec()
    assert spec.wavelength_min_nm == 1530.0
    assert spec.wavelength_max_nm == 1550.0
    assert spec.low_signal_gain_db == 40.0
