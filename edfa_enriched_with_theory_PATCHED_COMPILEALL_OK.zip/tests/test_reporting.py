from edfa_design_kit import reporting


def test_reporting_module_imports():
    assert hasattr(reporting, 'make_report')
