import numpy as np
from edfa_design_kit.spectral import CrossSectionSpectrum, channel_grid


def test_channel_grid_and_interpolation():
    w = channel_grid(1530.0, 1550.0, 50.0)
    assert len(w) > 20
    spec = CrossSectionSpectrum.from_repository('ge_al_si')
    vals = spec.sigma_e(np.array([1530.0, 1540.0, 1550.0]))
    assert np.all(vals > 0)
