import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import json
from dataclasses import asdict
from pathlib import Path
from matplotlib.backends.backend_pdf import PdfPages

from edfa_design_kit.repository import load_assignment_spec, load_fiber_catalog
from edfa_design_kit.spectral import CrossSectionSpectrum, channel_grid
from edfa_design_kit.solver import EDFASolver
from edfa_design_kit.domain import EDFAConfig, PumpLaser, SignalChannel
from edfa_design_kit.optimizer import optimize_design, write_candidates_csv
from edfa_design_kit.costing import default_bom, bom_total_cad


def main(outdir: str = 'artifacts/examples/report_run_v4_sample') -> None:
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    def save(fig, path):
        fig.savefig(path, dpi=160, bbox_inches='tight')
        plt.close(fig)

    spec = load_assignment_spec()
    fiber = load_fiber_catalog()['ge_al_si']
    spectrum = CrossSectionSpectrum.from_repository('ge_al_si')
    solver = EDFASolver(spectrum=spectrum, n_steps=120, ase_iterations=3)
    full = channel_grid(spec.wavelength_min_nm, spec.wavelength_max_nm, spec.channel_spacing_ghz)
    stride = max(len(full)//6, 1)
    lambdas = full[::stride]

    lengths = np.linspace(1.0, 9.0, 8)
    gains, nfs = [], []
    for L in lengths:
        cfg = EDFAConfig(fiber=fiber, pump=PumpLaser(power_w=0.30), length_m=float(L), channels=[SignalChannel(float(w), spec.low_signal_input_w) for w in lambdas])
        r = solver.solve(cfg)
        gains.append(min(r.gain_db_by_channel.values()))
        nfs.append(max(r.nf_db_by_channel.values()))

    pump_scan = np.linspace(0.04, 0.30, 6)
    input_levels = [spec.low_signal_input_w, 10e-6, 100e-6, spec.strong_signal_input_w]
    gain_curves, nf_curves = {}, {}
    for pin in input_levels:
        gl, nf = [], []
        for pp in pump_scan:
            cfg = EDFAConfig(fiber=fiber, pump=PumpLaser(power_w=float(pp)), length_m=5.8, channels=[SignalChannel(1550.0, pin)])
            r = solver.solve(cfg)
            gl.append(float(r.gain_db_by_channel[1550.0]))
            nf.append(float(r.nf_db_by_channel[1550.0]))
        gain_curves[pin] = gl
        nf_curves[pin] = nf

    ranked, pareto = optimize_design(fiber_key='ge_al_si', pump_max_w=0.30, n_pump=2, n_length=2, n_density=2)
    top = ranked[0]
    fiber_data = asdict(fiber)
    fiber_data['erbium_density_m3'] = fiber.erbium_density_m3 * top.density_scale
    best_fiber = type(fiber)(**fiber_data)
    best_cfg = EDFAConfig(fiber=best_fiber, pump=PumpLaser(power_w=top.pump_w), length_m=top.length_m, channels=[SignalChannel(float(w), spec.low_signal_input_w) for w in lambdas])
    best_res = solver.solve(best_cfg)
    strong_cfg = EDFAConfig(fiber=best_fiber, pump=PumpLaser(power_w=top.pump_w), length_m=top.length_m, channels=[SignalChannel(1550.0, spec.strong_signal_input_w)])
    strong_res = solver.solve(strong_cfg)

    fig = plt.figure(figsize=(8,4.6)); ax = fig.add_subplot(111); ax.plot(spectrum.wavelength_nm, spectrum.sigma_a_m2*1e25, label='sigma_a'); ax.plot(spectrum.wavelength_nm, spectrum.sigma_e_m2*1e25, label='sigma_e'); ax.set_xlabel('Wavelength (nm)'); ax.set_ylabel('Cross section (x1e-25 m^2)'); ax.set_title(f'Barnes-style spectrum - {fiber.display_name}'); ax.grid(True, alpha=0.25); ax.legend(); save(fig, outdir/'spectra.png')
    fig = plt.figure(figsize=(8,4.6)); ax = fig.add_subplot(111); ax.plot(lengths, gains); ax.axhline(spec.low_signal_gain_db, linestyle='--'); ax.set_xlabel('Fiber length (m)'); ax.set_ylabel('Min gain across sampled band (dB)'); ax.set_title('Gain vs fiber length at max pump'); ax.grid(True, alpha=0.25); save(fig, outdir/'gain_vs_length.png')
    fig = plt.figure(figsize=(8,4.6)); ax = fig.add_subplot(111); ax.plot(lengths, nfs); ax.axhline(spec.max_noise_figure_db, linestyle='--'); ax.set_xlabel('Fiber length (m)'); ax.set_ylabel('Worst-case NF across sampled band (dB)'); ax.set_title('Noise figure vs fiber length at max pump'); ax.grid(True, alpha=0.25); save(fig, outdir/'nf_vs_length.png')
    fig = plt.figure(figsize=(8,4.6)); ax = fig.add_subplot(111); [ax.plot(pump_scan, gl, label=f'Pin={pin*1e6:.0f} uW') for pin,gl in gain_curves.items()]; ax.axhline(spec.low_signal_gain_db, linestyle='--'); ax.set_xlabel('Pump power (W)'); ax.set_ylabel('Gain at 1550 nm (dB)'); ax.set_title('Gain vs pump power'); ax.grid(True, alpha=0.25); ax.legend(); save(fig, outdir/'gain_vs_pump.png')
    fig = plt.figure(figsize=(8,4.6)); ax = fig.add_subplot(111); [ax.plot(pump_scan, nf, label=f'Pin={pin*1e6:.0f} uW') for pin,nf in nf_curves.items()]; ax.axhline(spec.max_noise_figure_db, linestyle='--'); ax.set_xlabel('Pump power (W)'); ax.set_ylabel('NF at 1550 nm (dB)'); ax.set_title('Noise figure vs pump power'); ax.grid(True, alpha=0.25); ax.legend(); save(fig, outdir/'nf_vs_pump.png')
    fig = plt.figure(figsize=(8,4.6)); ax = fig.add_subplot(111); ax.scatter([c.length_m for c in ranked], [c.low_signal_gain_db for c in ranked], s=22, alpha=0.75); ax.scatter([c.length_m for c in pareto], [c.low_signal_gain_db for c in pareto], s=42); ax.set_xlabel('Fiber length (m)'); ax.set_ylabel('Min gain across sampled band (dB)'); ax.set_title('Pareto / best design candidates'); ax.grid(True, alpha=0.25); save(fig, outdir/'pareto.png')
    fig = plt.figure(figsize=(8,4.6)); ax = fig.add_subplot(111); center_idx = len(best_res.wavelengths_nm)//2; ax.plot(best_res.z_m, np.array(best_res.ase_forward_w)[:,center_idx]*1e3, label='ASE+'); ax.plot(best_res.z_m, np.array(best_res.ase_backward_w)[:,center_idx]*1e3, label='ASE-'); ax.set_xlabel('z (m)'); ax.set_ylabel('ASE power around center channel (mW)'); ax.set_title('ASE evolution for selected low-signal design'); ax.grid(True, alpha=0.25); ax.legend(); save(fig, outdir/'ase_evolution.png')

    write_candidates_csv(ranked, outdir/'optimization_candidates.csv')
    summary = {
        'fiber_key': 'ge_al_si',
        'selected_candidate': {'pump_w': top.pump_w, 'length_m': top.length_m, 'density_scale': top.density_scale, 'low_signal_gain_db': top.low_signal_gain_db, 'worst_nf_db': top.worst_nf_db, 'strong_signal_output_w': top.strong_signal_output_w, 'score': top.score},
        'mean_gain_db': best_res.mean_gain_db,
        'worst_nf_db': best_res.worst_nf_db,
        'strong_output_w': strong_res.output_power_by_channel_w[1550.0],
    }
    (outdir/'best_design.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
    plots = ['spectra.png','gain_vs_length.png','nf_vs_length.png','gain_vs_pump.png','nf_vs_pump.png','pareto.png','ase_evolution.png']
    bom_total = bom_total_cad(default_bom())
    strong_out_mw = strong_res.output_power_by_channel_w[1550.0]*1e3
    md = '\n'.join([
        '# EDFA report summary', '', '## Selected design', f'- Fiber: {fiber.display_name}', f'- Pump power: {top.pump_w:.3f} W', f'- Fiber length: {top.length_m:.3f} m', f'- Relative erbium density scale: {top.density_scale:.3f}', f'- Minimum low-signal gain across sampled band: {top.low_signal_gain_db:.2f} dB', f'- Worst-case noise figure across sampled band: {top.worst_nf_db:.2f} dB', f'- Output power for 1 mW at 1550 nm: {strong_out_mw:.2f} mW', '', '## Assignment targets', f'- Gain target: {spec.low_signal_gain_db:.1f} dB', f'- NF limit: {spec.max_noise_figure_db:.1f} dB', f'- Output target at 1 mW: {spec.strong_signal_output_min_w*1e3:.1f} to {spec.strong_signal_output_max_w*1e3:.1f} mW', '', f'- Estimated BOM total: {bom_total:.2f} CAD', '', '## Plots', *[f'- {p}' for p in plots], '' ])
    (outdir/'report_summary.md').write_text(md, encoding='utf-8')
    (outdir/'report_summary.tex').write_text('\\documentclass{article}\\begin{document}EDFA summary\\end{document}\n', encoding='utf-8')
    with PdfPages(outdir/'report_summary.pdf') as pdf:
        f = plt.figure(figsize=(8.27,11.69)); ax = f.add_subplot(111); ax.axis('off'); ax.text(0.06,0.95,'\n\n'.join(['EDFA Design Kit - V4 report', f'Fiber: {fiber.display_name}', f'Pump: {top.pump_w:.3f} W', f'Length: {top.length_m:.3f} m', f'Density scale: {top.density_scale:.3f}', f'Min band gain: {top.low_signal_gain_db:.2f} dB', f'Worst NF: {top.worst_nf_db:.2f} dB', f'Strong output @1550 nm, 1 mW input: {strong_out_mw:.2f} mW', f'Estimated BOM total: {bom_total:.2f} CAD']), va='top', fontsize=13); pdf.savefig(f, bbox_inches='tight'); plt.close(f)

if __name__ == '__main__':
    main()
