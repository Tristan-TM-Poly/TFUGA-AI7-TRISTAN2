# EDFA report summary

## Selected design
- Fiber: GeO2-Al2O3-SiO2
- Pump power: 0.300 W
- Fiber length: 5.250 m
- Relative erbium density scale: 0.700
- Minimum low-signal gain across band: 30.12 dB
- Worst-case noise figure across band: 3.43 dB
- Output power for 1 mW at 1550 nm: 68.96 mW

## Interpretation
This is a starter-model answer, not a final certified design. The selected point is the best compromise found by the grid-search objective between gain, NF and strong-signal output constraints.

## BOM estimate
| Item | Qty | Unit cost (CAD) | Subtotal (CAD) |
|---|---:|---:|---:|
| Er-doped gain fiber spool | 1 | 180.00 | 180.00 |
| 980 nm pump laser diode module | 1 | 240.00 | 240.00 |
| 980/1550 WDM coupler | 1 | 85.00 | 85.00 |
| Optical isolator | 2 | 65.00 | 130.00 |
| Bandpass/gain-flattening filter | 1 | 110.00 | 110.00 |
| Connectorization and assembly | 1 | 90.00 | 90.00 |

| **Total** |  |  | **835.00** |

## Plots produced

- x.png
