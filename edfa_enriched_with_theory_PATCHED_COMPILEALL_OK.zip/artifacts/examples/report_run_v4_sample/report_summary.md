# EDFA report summary

## Selected design
- Fiber: GeO2-Al2O3-SiO2
- Pump power: 0.300 W
- Fiber length: 1.500 m
- Relative erbium density scale: 1.300
- Minimum low-signal gain across sampled band: 18.23 dB
- Worst-case noise figure across sampled band: 3.11 dB
- Output power for 1 mW at 1550 nm: 25.17 mW

## Assignment targets
- Gain target: 40.0 dB
- NF limit: 3.2 dB
- Output target at 1 mW: 30.0 to 50.0 mW

- Estimated BOM total: 835.00 CAD

## Plots
- spectra.png
- gain_vs_length.png
- nf_vs_length.png
- gain_vs_pump.png
- nf_vs_pump.png
- pareto.png
- ase_evolution.png
