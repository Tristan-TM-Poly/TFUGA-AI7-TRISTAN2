from math import pi

C0 = 299_792_458.0
H = 6.626_070_15e-34
Q_E = 1.602_176_634e-19
K_B = 1.380_649e-23
PI = pi
