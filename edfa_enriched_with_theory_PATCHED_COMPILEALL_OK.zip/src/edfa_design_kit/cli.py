from __future__ import annotations

import argparse
import json
from pathlib import Path

from .optimizer import optimize_design, write_candidates_csv
from .pdf_ingest import copy_pdfs_into_project, extract_pdf_text, parse_assignment_constraints
from .reporting import make_report


def main() -> None:
    parser = argparse.ArgumentParser(prog="edfa-kit")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_ingest = sub.add_parser("ingest-pdfs")
    p_ingest.add_argument("--assignment", required=True)
    p_ingest.add_argument("--barnes", required=True)
    p_ingest.add_argument("--destination", default="docs/pdfs")

    p_opt = sub.add_parser("optimize")
    p_opt.add_argument("--fiber", default="ge_al_si")
    p_opt.add_argument("--pump-max", type=float, default=0.30)
    p_opt.add_argument("--outdir", default="artifacts/examples/optimize_run")

    p_rep = sub.add_parser("make-report")
    p_rep.add_argument("--fiber", default="ge_al_si")
    p_rep.add_argument("--pump-max", type=float, default=0.30)
    p_rep.add_argument("--outdir", default="artifacts/examples/report_run_v4")

    args = parser.parse_args()

    if args.cmd == "ingest-pdfs":
        copied = copy_pdfs_into_project([args.assignment, args.barnes], args.destination)
        text = extract_pdf_text(args.assignment)
        constraints = parse_assignment_constraints(text)
        print(json.dumps({"copied": [str(p) for p in copied], "constraints": constraints}, indent=2))
    elif args.cmd == "optimize":
        ranked, pareto = optimize_design(fiber_key=args.fiber, pump_max_w=args.pump_max)
        outdir = Path(args.outdir)
        outdir.mkdir(parents=True, exist_ok=True)
        write_candidates_csv(ranked[:250], outdir / "optimization_candidates.csv")
        summary = {
            "best": ranked[0].__dict__,
            "n_candidates": len(ranked),
            "n_pareto": len(pareto),
        }
        (outdir / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
        print(json.dumps(summary, indent=2))
    elif args.cmd == "make-report":
        path = make_report(fiber_key=args.fiber, pump_max_w=args.pump_max, outdir=args.outdir)
        print(str(path))


if __name__ == "__main__":
    main()
