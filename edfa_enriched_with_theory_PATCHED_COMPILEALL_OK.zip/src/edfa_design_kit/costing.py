from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class BOMItem:
    name: str
    qty: int
    unit_cost_cad: float

    @property
    def subtotal_cad(self) -> float:
        return self.qty * self.unit_cost_cad


def default_bom() -> list[BOMItem]:
    return [
        BOMItem("Er-doped gain fiber spool", 1, 180.0),
        BOMItem("980 nm pump laser diode module", 1, 240.0),
        BOMItem("980/1550 WDM coupler", 1, 85.0),
        BOMItem("Optical isolator", 2, 65.0),
        BOMItem("Bandpass/gain-flattening filter", 1, 110.0),
        BOMItem("Connectorization and assembly", 1, 90.0),
    ]


def bom_total_cad(items: list[BOMItem]) -> float:
    return sum(item.subtotal_cad for item in items)
