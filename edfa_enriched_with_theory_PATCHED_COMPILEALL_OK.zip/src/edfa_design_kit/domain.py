from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(slots=True)
class AssignmentSpec:
    wavelength_min_nm: float
    wavelength_max_nm: float
    channel_spacing_ghz: float
    low_signal_input_w: float
    max_noise_figure_db: float
    low_signal_gain_db: float
    strong_signal_input_w: float
    strong_signal_output_min_w: float
    strong_signal_output_max_w: float


@dataclass(slots=True)
class FiberModel:
    key: str
    display_name: str
    host_glass: str
    erbium_density_m3: float
    lifetime_s: float
    core_radius_m: float
    mode_radius_signal_m: float
    mode_radius_pump_m: float
    overlap_signal: float
    overlap_pump: float
    background_loss_signal_db_per_m: float
    background_loss_pump_db_per_m: float
    pump_absorption_cross_section_m2: float
    pump_emission_cross_section_m2: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def signal_effective_area_m2(self) -> float:
        from math import pi
        return pi * self.mode_radius_signal_m**2

    @property
    def pump_effective_area_m2(self) -> float:
        from math import pi
        return pi * self.mode_radius_pump_m**2


@dataclass(slots=True)
class PumpLaser:
    wavelength_nm: float = 980.0
    power_w: float = 0.18


@dataclass(slots=True)
class SignalChannel:
    wavelength_nm: float
    power_w: float
    label: str = "signal"


@dataclass(slots=True)
class DetectorModel:
    responsivity_a_per_w: float = 0.8
    electrical_bandwidth_hz: float = 50e9


@dataclass(slots=True)
class EDFAConfig:
    fiber: FiberModel
    pump: PumpLaser
    length_m: float
    channels: list[SignalChannel]
    detector: DetectorModel = field(default_factory=DetectorModel)
    ase_bandwidth_hz: float = 12.5e9
    signal_loss_extra_db: float = 0.0
    pump_loss_extra_db: float = 0.0


@dataclass(slots=True)
class SimulationResult:
    z_m: list[float]
    pump_w: list[float]
    inversion_fraction: list[float]
    wavelengths_nm: list[float]
    signal_profiles_w: list[list[float]]
    ase_forward_w: list[list[float]]
    ase_backward_w: list[list[float]]
    gain_db_by_channel: dict[float, float]
    nf_db_by_channel: dict[float, float]
    output_power_by_channel_w: dict[float, float]
    notes: list[str] = field(default_factory=list)

    @property
    def mean_gain_db(self) -> float:
        return sum(self.gain_db_by_channel.values()) / max(len(self.gain_db_by_channel), 1)

    @property
    def worst_nf_db(self) -> float:
        return max(self.nf_db_by_channel.values()) if self.nf_db_by_channel else float("nan")
