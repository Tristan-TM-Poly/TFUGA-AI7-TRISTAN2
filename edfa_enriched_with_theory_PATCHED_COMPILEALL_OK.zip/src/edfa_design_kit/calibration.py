from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.optimize import least_squares

from .repository import load_fiber_catalog
from .spectral import CrossSectionSpectrum


@dataclass(slots=True)
class CalibrationResult:
    sigma_a_scale: float
    sigma_e_scale: float
    overlap_signal_scale: float
    residual_norm: float


def calibrate_cross_sections(
    fiber_key: str,
    wavelengths_nm: np.ndarray,
    measured_sigma_a_m2: np.ndarray,
    measured_sigma_e_m2: np.ndarray,
) -> CalibrationResult:
    spectrum = CrossSectionSpectrum.from_repository(fiber_key)
    base_a = spectrum.sigma_a(wavelengths_nm)
    base_e = spectrum.sigma_e(wavelengths_nm)

    def residuals(x: np.ndarray) -> np.ndarray:
        sa, se, ov = x
        return np.hstack([
            sa * ov * base_a - measured_sigma_a_m2,
            se * ov * base_e - measured_sigma_e_m2,
        ])

    res = least_squares(residuals, x0=np.array([1.0, 1.0, 1.0]), bounds=(0.25, 4.0))
    return CalibrationResult(float(res.x[0]), float(res.x[1]), float(res.x[2]), float(np.linalg.norm(res.fun)))
