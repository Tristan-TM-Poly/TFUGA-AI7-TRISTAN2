from __future__ import annotations

from dataclasses import asdict

from pathlib import Path

import json
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from jinja2 import Environment, PackageLoader, select_autoescape
from matplotlib.backends.backend_pdf import PdfPages

from .costing import bom_total_cad, default_bom
from .domain import EDFAConfig, PumpLaser, SignalChannel
from .optimizer import optimize_design, write_candidates_csv
from .repository import load_assignment_spec, load_fiber_catalog
from .solver import EDFASolver
from .spectral import CrossSectionSpectrum, channel_grid


def _save_plot(fig, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=180, bbox_inches="tight")
    plt.close(fig)


def make_report(fiber_key: str = "ge_al_si", pump_max_w: float = 0.30, outdir: str | Path = "artifacts/examples/report_run_v4") -> Path:
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    spec = load_assignment_spec()
    fibers = load_fiber_catalog()
    fiber = fibers[fiber_key]
    spectrum = CrossSectionSpectrum.from_repository(fiber_key)
    solver = EDFASolver(spectrum=spectrum, n_steps=140, ase_iterations=3)
    full_lambdas = channel_grid(spec.wavelength_min_nm, spec.wavelength_max_nm, spec.channel_spacing_ghz)
    stride = max(len(full_lambdas) // 6, 1)
    lambdas = full_lambdas[::stride]

    lengths = np.linspace(1.0, 9.0, 10)
    gains_vs_length = []
    nf_vs_length = []
    for L in lengths:
        cfg = EDFAConfig(
            fiber=fiber,
            pump=PumpLaser(power_w=pump_max_w),
            length_m=float(L),
            channels=[SignalChannel(float(w), spec.low_signal_input_w, f"ch{i}") for i, w in enumerate(lambdas)],
        )
        res = solver.solve(cfg)
        gains_vs_length.append(min(res.gain_db_by_channel.values()))
        nf_vs_length.append(max(res.nf_db_by_channel.values()))

    pump_scan = np.linspace(0.04, pump_max_w, 6)
    input_levels = [spec.low_signal_input_w, 10e-6, 100e-6, spec.strong_signal_input_w]
    gain_curves = {}
    nf_curves = {}
    for pin in input_levels:
        glist, nflist = [], []
        for pp in pump_scan:
            cfg = EDFAConfig(
                fiber=fiber,
                pump=PumpLaser(power_w=float(pp)),
                length_m=5.8,
                channels=[SignalChannel(1550.0, pin, f"{pin:.1e} W")],
            )
            res = solver.solve(cfg)
            glist.append(res.gain_db_by_channel[1550.0])
            nflist.append(res.nf_db_by_channel[1550.0])
        gain_curves[pin] = glist
        nf_curves[pin] = nflist

    ranked, pareto = optimize_design(fiber_key=fiber_key, pump_max_w=pump_max_w, n_pump=2, n_length=3, n_density=2)
    top = ranked[0]
    fiber_data = asdict(fiber)
    fiber_data["erbium_density_m3"] = fiber.erbium_density_m3 * top.density_scale
    best_fiber = type(fiber)(**fiber_data)
    best_cfg = EDFAConfig(
        fiber=best_fiber,
        pump=PumpLaser(power_w=top.pump_w),
        length_m=top.length_m,
        channels=[SignalChannel(float(w), spec.low_signal_input_w, f"ch{i}") for i, w in enumerate(lambdas)],
    )
    best_res = solver.solve(best_cfg)

    strong_cfg = EDFAConfig(
        fiber=best_fiber,
        pump=PumpLaser(power_w=top.pump_w),
        length_m=top.length_m,
        channels=[SignalChannel(1550.0, spec.strong_signal_input_w, "strong")],
    )
    strong_res = solver.solve(strong_cfg)

    spectra_fig = plt.figure(figsize=(8, 4.6))
    ax = spectra_fig.add_subplot(111)
    ax.plot(spectrum.wavelength_nm, spectrum.sigma_a_m2 * 1e25, label="sigma_a")
    ax.plot(spectrum.wavelength_nm, spectrum.sigma_e_m2 * 1e25, label="sigma_e")
    ax.set_xlabel("Wavelength (nm)")
    ax.set_ylabel("Cross section (x1e-25 m^2)")
    ax.set_title(f"Barnes-style spectrum - {fiber.display_name}")
    ax.grid(True, alpha=0.25)
    ax.legend()
    _save_plot(spectra_fig, outdir / "spectra.png")

    fig = plt.figure(figsize=(8, 4.6))
    ax = fig.add_subplot(111)
    ax.plot(lengths, gains_vs_length)
    ax.axhline(spec.low_signal_gain_db, linestyle="--")
    ax.set_xlabel("Fiber length (m)")
    ax.set_ylabel("Minimum low-signal gain across band (dB)")
    ax.set_title("Gain vs fiber length at max pump")
    ax.grid(True, alpha=0.25)
    _save_plot(fig, outdir / "gain_vs_length.png")

    fig = plt.figure(figsize=(8, 4.6))
    ax = fig.add_subplot(111)
    ax.plot(lengths, nf_vs_length)
    ax.axhline(spec.max_noise_figure_db, linestyle="--")
    ax.set_xlabel("Fiber length (m)")
    ax.set_ylabel("Worst-case NF across band (dB)")
    ax.set_title("Noise figure vs fiber length at max pump")
    ax.grid(True, alpha=0.25)
    _save_plot(fig, outdir / "nf_vs_length.png")

    fig = plt.figure(figsize=(8, 4.6))
    ax = fig.add_subplot(111)
    for pin, glist in gain_curves.items():
        ax.plot(pump_scan, glist, label=f"Pin={pin*1e6:.0f} uW")
    ax.axhline(spec.low_signal_gain_db, linestyle="--")
    ax.set_xlabel("Pump power (W)")
    ax.set_ylabel("Gain at 1550 nm (dB)")
    ax.set_title("Gain vs pump power")
    ax.grid(True, alpha=0.25)
    ax.legend()
    _save_plot(fig, outdir / "gain_vs_pump.png")

    fig = plt.figure(figsize=(8, 4.6))
    ax = fig.add_subplot(111)
    for pin, nflist in nf_curves.items():
        ax.plot(pump_scan, nflist, label=f"Pin={pin*1e6:.0f} uW")
    ax.axhline(spec.max_noise_figure_db, linestyle="--")
    ax.set_xlabel("Pump power (W)")
    ax.set_ylabel("NF at 1550 nm (dB)")
    ax.set_title("Noise figure vs pump power")
    ax.grid(True, alpha=0.25)
    ax.legend()
    _save_plot(fig, outdir / "nf_vs_pump.png")

    fig = plt.figure(figsize=(8, 4.6))
    ax = fig.add_subplot(111)
    ax.scatter([c.length_m for c in ranked[:150]], [c.low_signal_gain_db for c in ranked[:150]], s=16, alpha=0.7)
    ax.scatter([c.length_m for c in pareto], [c.low_signal_gain_db for c in pareto], s=36)
    ax.set_xlabel("Fiber length (m)")
    ax.set_ylabel("Min gain across band (dB)")
    ax.set_title("Pareto / best design candidates")
    ax.grid(True, alpha=0.25)
    _save_plot(fig, outdir / "pareto.png")

    fig = plt.figure(figsize=(8, 4.6))
    ax = fig.add_subplot(111)
    ax.plot(best_res.z_m, np.array(best_res.ase_forward_w)[:, len(best_res.wavelengths_nm)//2] * 1e3, label="ASE+")
    ax.plot(best_res.z_m, np.array(best_res.ase_backward_w)[:, len(best_res.wavelengths_nm)//2] * 1e3, label="ASE-")
    ax.set_xlabel("z (m)")
    ax.set_ylabel("ASE power around center channel (mW)")
    ax.set_title("ASE evolution for best low-signal design")
    ax.grid(True, alpha=0.25)
    ax.legend()
    _save_plot(fig, outdir / "ase_evolution.png")

    write_candidates_csv(ranked[:250], outdir / "optimization_candidates.csv")
    with (outdir / "best_design.json").open("w", encoding="utf-8") as f:
        json.dump({
            "fiber_key": fiber_key,
            "selected_candidate": {"pump_w": top.pump_w, "length_m": top.length_m, "density_scale": top.density_scale, "low_signal_gain_db": top.low_signal_gain_db, "worst_nf_db": top.worst_nf_db, "strong_signal_output_w": top.strong_signal_output_w, "score": top.score},
            "mean_gain_db": best_res.mean_gain_db,
            "worst_nf_db": best_res.worst_nf_db,
            "strong_output_w": strong_res.output_power_by_channel_w[1550.0],
        }, f, indent=2)

    bom = default_bom()
    env = Environment(loader=PackageLoader("edfa_design_kit", "templates"), autoescape=select_autoescape())
    md_template = env.get_template("report_summary.md.j2")
    tex_template = env.get_template("report_summary.tex.j2")
    context = {
        "fiber": fiber,
        "top": top,
        "best_res": best_res,
        "strong_out_mw": strong_res.output_power_by_channel_w[1550.0] * 1e3,
        "bom": bom,
        "bom_total": bom_total_cad(bom),
        "spec": spec,
        "plots": [
            "spectra.png", "gain_vs_length.png", "nf_vs_length.png", "gain_vs_pump.png", "nf_vs_pump.png", "pareto.png", "ase_evolution.png"
        ],
    }
    (outdir / "report_summary.md").write_text(md_template.render(**context), encoding="utf-8")
    (outdir / "report_summary.tex").write_text(tex_template.render(**context), encoding="utf-8")

    with PdfPages(outdir / "report_summary.pdf") as pdf:
        title = plt.figure(figsize=(8.27, 11.69))
        ax = title.add_subplot(111)
        ax.axis("off")
        lines = [
            "EDFA Design Kit - V4 report",
            f"Fiber: {fiber.display_name}",
            f"Pump: {top.pump_w:.3f} W",
            f"Length: {top.length_m:.3f} m",
            f"Density scale: {top.density_scale:.3f}",
            f"Min band gain: {top.low_signal_gain_db:.2f} dB",
            f"Worst NF: {top.worst_nf_db:.2f} dB",
            f"Strong-signal output @1550 nm for 1 mW input: {strong_res.output_power_by_channel_w[1550.0]*1e3:.2f} mW",
            f"Estimated BOM total: {bom_total_cad(bom):.2f} CAD",
        ]
        PLACEHOLDER
        pdf.savefig(title, bbox_inches="tight")
        plt.close(title)
        for name in [
            "spectra.png", "gain_vs_length.png", "nf_vs_length.png", "gain_vs_pump.png", "nf_vs_pump.png", "pareto.png", "ase_evolution.png"
        ]:
            img = plt.imread(outdir / name)
            fig = plt.figure(figsize=(8.27, 11.69))
            ax = fig.add_subplot(111)
            ax.imshow(img)
            ax.axis("off")
            ax.set_title(name.replace("_", " ").replace(".png", ""))
            pdf.savefig(fig, bbox_inches="tight")
            plt.close(fig)

    return outdir
