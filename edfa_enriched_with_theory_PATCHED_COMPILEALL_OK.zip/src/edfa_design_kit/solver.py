from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

import numpy as np

from .constants import C0, H, PI
from .domain import EDFAConfig, SimulationResult, SignalChannel
from .spectral import CrossSectionSpectrum


@dataclass(slots=True)
class EDFASolver:
    spectrum: CrossSectionSpectrum
    n_steps: int = 300
    ase_iterations: int = 6

    @staticmethod
    def _db_per_m_to_neper(db_per_m: float) -> float:
        return db_per_m / 4.343

    def _local_inversion_fraction(
        self,
        fiber,
        pump_w: float,
        signal_powers_w: np.ndarray,
        ase_forward_w: np.ndarray,
        ase_backward_w: np.ndarray,
        wavelengths_nm: np.ndarray,
    ) -> float:
        lam_m = wavelengths_nm * 1e-9
        nu_s = C0 / lam_m
        sigma_a = self.spectrum.sigma_a(wavelengths_nm)
        sigma_e = self.spectrum.sigma_e(wavelengths_nm)

        Wpa = fiber.overlap_pump * fiber.pump_absorption_cross_section_m2 * max(pump_w, 0.0) / (H * (C0 / 980e-9) * fiber.pump_effective_area_m2)
        Wpe = fiber.overlap_pump * fiber.pump_emission_cross_section_m2 * max(pump_w, 0.0) / (H * (C0 / 980e-9) * fiber.pump_effective_area_m2)
        combined = np.maximum(signal_powers_w + ase_forward_w + ase_backward_w, 0.0)
        Wsa = np.sum(fiber.overlap_signal * sigma_a * combined / (H * nu_s * fiber.signal_effective_area_m2))
        Wse = np.sum(fiber.overlap_signal * sigma_e * combined / (H * nu_s * fiber.signal_effective_area_m2))
        frac = (Wpa + Wsa) / max(Wpa + Wpe + Wsa + Wse + 1.0 / fiber.lifetime_s, 1e-30)
        return float(np.clip(frac, 1e-9, 0.999999))

    def solve(self, config: EDFAConfig) -> SimulationResult:
        z = np.linspace(0.0, config.length_m, self.n_steps)
        dz = z[1] - z[0]
        wavelengths = np.array([ch.wavelength_nm for ch in config.channels], dtype=float)
        signal_inputs = np.array([ch.power_w for ch in config.channels], dtype=float)
        n_ch = len(config.channels)

        signal_profiles = np.zeros((self.n_steps, n_ch), dtype=float)
        ase_plus = np.zeros((self.n_steps, n_ch), dtype=float)
        ase_minus = np.zeros((self.n_steps, n_ch), dtype=float)
        pump = np.zeros(self.n_steps, dtype=float)
        inversion = np.zeros(self.n_steps, dtype=float)

        sigma_a = self.spectrum.sigma_a(wavelengths)
        sigma_e = self.spectrum.sigma_e(wavelengths)
        alpha_s = self._db_per_m_to_neper(config.fiber.background_loss_signal_db_per_m + config.signal_loss_extra_db)
        alpha_p = self._db_per_m_to_neper(config.fiber.background_loss_pump_db_per_m + config.pump_loss_extra_db)
        ase_bw = float(config.ase_bandwidth_hz)
        nu = C0 / (wavelengths * 1e-9)

        for _ in range(self.ase_iterations):
            pump[0] = config.pump.power_w
            signal_profiles[0, :] = signal_inputs
            for i in range(self.n_steps - 1):
                inversion[i] = self._local_inversion_fraction(
                    config.fiber,
                    pump[i],
                    signal_profiles[i, :],
                    ase_plus[i, :],
                    ase_minus[i, :],
                    wavelengths,
                )
                N2 = inversion[i] * config.fiber.erbium_density_m3
                N1 = config.fiber.erbium_density_m3 - N2
                g_s = config.fiber.overlap_signal * (sigma_e * N2 - sigma_a * N1) - alpha_s
                g_p = config.fiber.overlap_pump * (
                    config.fiber.pump_emission_cross_section_m2 * N2 - config.fiber.pump_absorption_cross_section_m2 * N1
                ) - alpha_p
                spont = 2.0 * config.fiber.overlap_signal * sigma_e * N2 * H * nu * ase_bw
                pump[i + 1] = max(pump[i] + dz * g_p * pump[i], 1e-18)
                signal_profiles[i + 1, :] = np.maximum(signal_profiles[i, :] + dz * g_s * signal_profiles[i, :], 1e-18)
                ase_plus[i + 1, :] = np.maximum(ase_plus[i, :] + dz * (g_s * ase_plus[i, :] + spont), 0.0)

            inversion[-1] = self._local_inversion_fraction(
                config.fiber, pump[-1], signal_profiles[-1, :], ase_plus[-1, :], ase_minus[-1, :], wavelengths
            )
            for i in range(self.n_steps - 1, 0, -1):
                N2 = inversion[i] * config.fiber.erbium_density_m3
                N1 = config.fiber.erbium_density_m3 - N2
                g_s = config.fiber.overlap_signal * (sigma_e * N2 - sigma_a * N1) - alpha_s
                spont = 2.0 * config.fiber.overlap_signal * sigma_e * N2 * H * nu * ase_bw
                ase_minus[i - 1, :] = np.maximum(ase_minus[i, :] + dz * (g_s * ase_minus[i, :] + spont), 0.0)

        gains_db = {}
        nf_db = {}
        outputs = {}
        for idx, ch in enumerate(config.channels):
            p_in = max(ch.power_w, 1e-18)
            p_out = float(signal_profiles[-1, idx])
            G = max(p_out / p_in, 1e-12)
            outputs[ch.wavelength_nm] = p_out
            gains_db[ch.wavelength_nm] = 10 * np.log10(G)
            N2_mean = max(np.mean(inversion), 1e-6) * config.fiber.erbium_density_m3
            N1_mean = config.fiber.erbium_density_m3 - N2_mean
            denom = max(config.fiber.overlap_signal * (sigma_e[idx] * N2_mean - sigma_a[idx] * N1_mean), 1e-30)
            n_sp = max(config.fiber.overlap_signal * sigma_e[idx] * N2_mean / denom, 1.0)
            F = 2 * n_sp * (1 - 1 / max(G, 1.0 + 1e-12)) + 1 / max(G, 1.0 + 1e-12)
            nf_db[ch.wavelength_nm] = 10 * np.log10(max(F, 1.0))

        notes = [
            "Simplified two-level model with co-propagating 980 nm pump.",
            "ASE forward/backward solved by iterative forward/backward sweeps.",
            "Noise figure uses spontaneous emission factor approximation.",
        ]
        return SimulationResult(
            z_m=z.tolist(),
            pump_w=pump.tolist(),
            inversion_fraction=inversion.tolist(),
            wavelengths_nm=wavelengths.tolist(),
            signal_profiles_w=signal_profiles.tolist(),
            ase_forward_w=ase_plus.tolist(),
            ase_backward_w=ase_minus.tolist(),
            gain_db_by_channel=gains_db,
            nf_db_by_channel=nf_db,
            output_power_by_channel_w=outputs,
            notes=notes,
        )
