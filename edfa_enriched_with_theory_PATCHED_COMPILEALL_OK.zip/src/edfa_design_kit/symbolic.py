from __future__ import annotations

import sympy as sp


def symbols():
    z = sp.symbols("z", positive=True)
    sigma_a, sigma_e, sigma_ap, sigma_ep = sp.symbols("sigma_a sigma_e sigma_ap sigma_ep", positive=True)
    N1, N2, Nt = sp.symbols("N1 N2 Nt", positive=True)
    Pp, Ps, Pase_p, Pase_m = sp.symbols("P_p P_s P_ASEp P_ASEm", positive=True)
    tau = sp.symbols("tau", positive=True)
    Gam_p, Gam_s = sp.symbols("Gamma_p Gamma_s", positive=True)
    Aeff_p, Aeff_s = sp.symbols("Aeff_p Aeff_s", positive=True)
    h, nu_p, nu_s, dnu = sp.symbols("h nu_p nu_s dnu", positive=True)
    alpha_p, alpha_s = sp.symbols("alpha_p alpha_s", nonnegative=True)
    return locals()


def stationary_inversion_expr():
    s = symbols()
    Wpa = s["Gam_p"] * s["sigma_ap"] * s["Pp"] / (s["h"] * s["nu_p"] * s["Aeff_p"])
    Wpe = s["Gam_p"] * s["sigma_ep"] * s["Pp"] / (s["h"] * s["nu_p"] * s["Aeff_p"])
    Wsa = s["Gam_s"] * s["sigma_a"] * s["Ps"] / (s["h"] * s["nu_s"] * s["Aeff_s"])
    Wse = s["Gam_s"] * s["sigma_e"] * s["Ps"] / (s["h"] * s["nu_s"] * s["Aeff_s"])
    expr = sp.simplify(s["Nt"] * (Wpa + Wsa) / (Wpa + Wpe + Wsa + Wse + 1 / s["tau"]))
    return sp.Eq(s["N2"], expr)


def local_gain_expr():
    s = symbols()
    return sp.Eq(sp.Symbol("g_s"), s["Gam_s"] * (s["sigma_e"] * s["N2"] - s["sigma_a"] * s["N1"]) - s["alpha_s"])


def pump_ode_expr():
    s = symbols()
    rhs = -(s["Gam_p"] * (s["sigma_ap"] * s["N1"] - s["sigma_ep"] * s["N2"]) + s["alpha_p"]) * s["Pp"]
    return sp.Eq(sp.diff(s["Pp"], s["z"]), sp.simplify(rhs))


def signal_ode_expr():
    s = symbols()
    rhs = (s["Gam_s"] * (s["sigma_e"] * s["N2"] - s["sigma_a"] * s["N1"]) - s["alpha_s"]) * s["Ps"]
    return sp.Eq(sp.diff(s["Ps"], s["z"]), sp.simplify(rhs))


def ase_forward_ode_expr():
    s = symbols()
    g = s["Gam_s"] * (s["sigma_e"] * s["N2"] - s["sigma_a"] * s["N1"]) - s["alpha_s"]
    source = 2 * s["Gam_s"] * s["sigma_e"] * s["N2"] * s["h"] * s["nu_s"] * s["dnu"]
    return sp.Eq(sp.diff(s["Pase_p"], s["z"]), sp.simplify(g * s["Pase_p"] + source))


def ase_backward_ode_expr():
    s = symbols()
    g = s["Gam_s"] * (s["sigma_e"] * s["N2"] - s["sigma_a"] * s["N1"]) - s["alpha_s"]
    source = 2 * s["Gam_s"] * s["sigma_e"] * s["N2"] * s["h"] * s["nu_s"] * s["dnu"]
    return sp.Eq(sp.diff(s["Pase_m"], s["z"]), sp.simplify(-g * s["Pase_m"] - source))


def shot_noise_expr():
    q, I, B = sp.symbols("q I B", positive=True)
    return sp.Eq(sp.Symbol("S_i"), 2 * q * I * B)


def noise_figure_expr():
    G, nsp = sp.symbols("G n_sp", positive=True)
    F = sp.simplify(2 * nsp * (1 - 1 / G) + 1 / G)
    return sp.Eq(sp.Symbol("F"), F)
