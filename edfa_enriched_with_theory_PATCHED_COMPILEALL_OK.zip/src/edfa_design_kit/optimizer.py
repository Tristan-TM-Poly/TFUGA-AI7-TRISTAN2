from __future__ import annotations

from dataclasses import asdict, dataclass
from pathlib import Path

import csv
import numpy as np

from .domain import AssignmentSpec, EDFAConfig, PumpLaser, SignalChannel
from .repository import load_assignment_spec, load_fiber_catalog
from .solver import EDFASolver
from .spectral import CrossSectionSpectrum, channel_grid


@dataclass(slots=True)
class Candidate:
    pump_w: float
    length_m: float
    density_scale: float
    low_signal_gain_db: float
    worst_nf_db: float
    strong_signal_output_w: float
    score: float


def _dominates(a: Candidate, b: Candidate) -> bool:
    va = np.array([-a.low_signal_gain_db, a.worst_nf_db, abs(a.strong_signal_output_w - 0.04)])
    vb = np.array([-b.low_signal_gain_db, b.worst_nf_db, abs(b.strong_signal_output_w - 0.04)])
    return np.all(va <= vb) and np.any(va < vb)


def pareto_front(candidates: list[Candidate]) -> list[Candidate]:
    front = []
    for c in candidates:
        if any(_dominates(other, c) for other in candidates if other is not c):
            continue
        front.append(c)
    return sorted(front, key=lambda x: x.score)


def optimize_design(
    fiber_key: str = "ge_al_si",
    pump_min_w: float = 0.05,
    pump_max_w: float = 0.30,
    lengths_m: tuple[float, float] = (1.5, 9.0),
    density_scales: tuple[float, float] = (0.7, 1.3),
    n_pump: int = 10,
    n_length: int = 12,
    n_density: int = 7,
) -> tuple[list[Candidate], list[Candidate]]:
    spec = load_assignment_spec()
    fibers = load_fiber_catalog()
    base = fibers[fiber_key]
    spectrum = CrossSectionSpectrum.from_repository(fiber_key)
    solver = EDFASolver(spectrum=spectrum, n_steps=120, ase_iterations=3)
    full_lambdas = channel_grid(spec.wavelength_min_nm, spec.wavelength_max_nm, spec.channel_spacing_ghz)
    stride = max(len(full_lambdas) // 6, 1)
    lambdas = full_lambdas[::stride]

    candidates: list[Candidate] = []
    for pump_w in np.linspace(pump_min_w, pump_max_w, n_pump):
        for length_m in np.linspace(*lengths_m, n_length):
            for density_scale in np.linspace(*density_scales, n_density):
                base_data = asdict(base)
                base_data["erbium_density_m3"] = base.erbium_density_m3 * density_scale
                fiber = type(base)(**base_data)
                low_channels = [SignalChannel(float(l), spec.low_signal_input_w, f"ch{i}") for i, l in enumerate(lambdas)]
                low_cfg = EDFAConfig(fiber=fiber, pump=PumpLaser(power_w=float(pump_w)), length_m=float(length_m), channels=low_channels)
                low_res = solver.solve(low_cfg)
                low_gain = min(low_res.gain_db_by_channel.values())
                worst_nf = max(low_res.nf_db_by_channel.values())

                strong_cfg = EDFAConfig(
                    fiber=fiber,
                    pump=PumpLaser(power_w=float(pump_w)),
                    length_m=float(length_m),
                    channels=[SignalChannel(spec.wavelength_max_nm, spec.strong_signal_input_w, "strong")],
                )
                strong_res = solver.solve(strong_cfg)
                strong_out = strong_res.output_power_by_channel_w[spec.wavelength_max_nm]

                penalties = [
                    max(spec.low_signal_gain_db - low_gain, 0.0),
                    max(worst_nf - spec.max_noise_figure_db, 0.0),
                    max(spec.strong_signal_output_min_w - strong_out, 0.0) / 1e-3,
                    max(strong_out - spec.strong_signal_output_max_w, 0.0) / 1e-3,
                ]
                score = float(np.sum(np.square(penalties)))
                candidates.append(Candidate(float(pump_w), float(length_m), float(density_scale), float(low_gain), float(worst_nf), float(strong_out), score))

    return sorted(candidates, key=lambda x: x.score), pareto_front(candidates)


def write_candidates_csv(candidates: list[Candidate], path: str | Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["pump_w", "length_m", "density_scale", "low_signal_gain_db", "worst_nf_db", "strong_signal_output_w", "score"])
        for c in candidates:
            writer.writerow([c.pump_w, c.length_m, c.density_scale, c.low_signal_gain_db, c.worst_nf_db, c.strong_signal_output_w, c.score])
    return path
