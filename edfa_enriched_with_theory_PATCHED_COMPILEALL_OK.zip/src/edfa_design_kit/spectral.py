from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.interpolate import PchipInterpolator

from .constants import C0
from .repository import load_spectrum_table


@dataclass(slots=True)
class CrossSectionSpectrum:
    wavelength_nm: np.ndarray
    sigma_a_m2: np.ndarray
    sigma_e_m2: np.ndarray

    @classmethod
    def from_repository(cls, fiber_key: str) -> "CrossSectionSpectrum":
        table = load_spectrum_table(fiber_key)
        lam = np.array([row["wavelength_nm"] for row in table], dtype=float)
        sigma_a = np.array([row["sigma_a_m2"] for row in table], dtype=float)
        sigma_e = np.array([row["sigma_e_m2"] for row in table], dtype=float)
        return cls(lam, sigma_a, sigma_e)

    def interpolators(self) -> tuple[PchipInterpolator, PchipInterpolator]:
        return (
            PchipInterpolator(self.wavelength_nm, self.sigma_a_m2, extrapolate=True),
            PchipInterpolator(self.wavelength_nm, self.sigma_e_m2, extrapolate=True),
        )

    def sigma_a(self, wavelength_nm: np.ndarray | float) -> np.ndarray:
        ia, _ = self.interpolators()
        return np.clip(np.asarray(ia(wavelength_nm), dtype=float), 0.0, None)

    def sigma_e(self, wavelength_nm: np.ndarray | float) -> np.ndarray:
        _, ie = self.interpolators()
        return np.clip(np.asarray(ie(wavelength_nm), dtype=float), 0.0, None)


def channel_grid(start_nm: float, stop_nm: float, spacing_ghz: float) -> np.ndarray:
    freqs = []
    lam = start_nm
    while lam <= stop_nm + 1e-12:
        freqs.append(C0 / (lam * 1e-9))
        delta_f = spacing_ghz * 1e9
        lam = (C0 / (freqs[-1] - delta_f)) * 1e9
    wavelengths = np.array([C0 / f * 1e9 for f in freqs])
    wavelengths = wavelengths[(wavelengths >= start_nm - 1e-9) & (wavelengths <= stop_nm + 1e-9)]
    return np.sort(wavelengths)
