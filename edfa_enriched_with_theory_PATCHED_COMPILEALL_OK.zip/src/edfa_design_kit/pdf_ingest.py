from __future__ import annotations

import re
import shutil
from pathlib import Path

from pypdf import PdfReader


def extract_pdf_text(path: str | Path) -> str:
    reader = PdfReader(str(path))
    return "\n".join((page.extract_text() or "") for page in reader.pages)


def copy_pdfs_into_project(pdf_paths: list[str | Path], destination_dir: str | Path) -> list[Path]:
    destination = Path(destination_dir)
    destination.mkdir(parents=True, exist_ok=True)
    copied: list[Path] = []
    for pdf in pdf_paths:
        src = Path(pdf)
        dst = destination / src.name
        shutil.copy2(src, dst)
        copied.append(dst)
    return copied


def parse_assignment_constraints(text: str) -> dict[str, float]:
    patterns = {
        "wavelength_min_nm": r"op[ée]rer de\s*(\d+)\s*[àa-]\s*(\d+)\s*nm",
        "channel_spacing_ghz": r"Bande passante.*?:\s*(\d+)\s*GHz",
        "low_signal_input_w": r"Puissance d’entr[ée]e minimale\s*:\s*1\s*[µu]W",
        "max_noise_figure_db": r"Figure de bruit\s*:\s*<?\s*([0-9.]+)\s*dB",
        "low_signal_gain_db": r"Gain [àa] faible signal\s*:\s*([0-9.]+)\s*dB",
    }
    out: dict[str, float] = {}
    m = re.search(patterns["wavelength_min_nm"], text, re.IGNORECASE)
    if m:
        out["wavelength_min_nm"] = float(m.group(1))
        out["wavelength_max_nm"] = float(m.group(2))
    for k in ["channel_spacing_ghz", "max_noise_figure_db", "low_signal_gain_db"]:
        m = re.search(patterns[k], text, re.IGNORECASE)
        if m:
            out[k] = float(m.group(1))
    if re.search(patterns["low_signal_input_w"], text, re.IGNORECASE):
        out["low_signal_input_w"] = 1e-6
    if "30 mW" in text:
        out["strong_signal_output_min_w"] = 30e-3
    if "50 mW" in text:
        out["strong_signal_output_max_w"] = 50e-3
    if re.search(r"entr[ée]e [àa] 1 mW", text, re.IGNORECASE):
        out["strong_signal_input_w"] = 1e-3
    return out
