from __future__ import annotations

import csv
import json
from importlib import resources
from pathlib import Path

from .domain import AssignmentSpec, FiberModel


def _data_path(name: str) -> Path:
    return Path(resources.files("edfa_design_kit").joinpath("data", name))


def load_assignment_spec() -> AssignmentSpec:
    with _data_path("assignment_spec.json").open("r", encoding="utf-8") as f:
        data = json.load(f)
    return AssignmentSpec(**data)


def load_fiber_catalog() -> dict[str, FiberModel]:
    with _data_path("barnes_fibers.json").open("r", encoding="utf-8") as f:
        raw = json.load(f)
    return {k: FiberModel(**v) for k, v in raw.items()}


def load_spectrum_table(fiber_key: str) -> list[dict[str, float]]:
    path = _data_path(f"spectra/{fiber_key}.csv")
    with path.open("r", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    parsed = []
    for row in rows:
        parsed.append({
            "wavelength_nm": float(row["wavelength_nm"]),
            "sigma_a_m2": float(row["sigma_a_m2"]),
            "sigma_e_m2": float(row["sigma_e_m2"]),
        })
    return parsed
