from dataclasses import dataclass, field

@dataclass
class CanonicalConcept:
    label: str
    kind: str
    score: float
    evidence: list[str] = field(default_factory=list)
    sources: list[str] = field(default_factory=list)

@dataclass
class CanonicalEquation:
    expression: str
    score: float
    source: str
    context: str
