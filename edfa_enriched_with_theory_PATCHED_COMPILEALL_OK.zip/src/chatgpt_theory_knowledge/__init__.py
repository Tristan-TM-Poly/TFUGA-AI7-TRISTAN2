"""Auto-generated theory knowledge package."""
