# Inventaire automatique des ZIP TFUGA nouveaux

## TFUGA_MEGA_OMNIBUS_FINAL_PLUS_ULTRA_HYPER_BEST(1).zip
- Taille ZIP: 1719305 bytes; fichiers: 78; dossiers: 0; non compressé: 2340681 bytes; ratio: 1.36x
- Extensions: {'.json': 39, '.md': 14, '.zip': 13, '.jsonl': 7, '.csv': 2, '.py': 2, '.sh': 1}
- Racines: {'96_execution_bus_hyperbest': 25, '97_operational_runtime_governance': 17, 'artifacts': 13, '98_meta_generation_autogouvernee': 8, '95_sovereign_cockpit_and_meta_synergy': 6, '99_tristan_canonical_theory': 4, 'reports': 3, 'OMNIBUS_MANIFEST.json': 1, 'README.md': 1}
- Plus gros fichiers:
  - artifacts/TFUGA_AI7_TRISTAN2_META_ORCHESTRATION_STATION_V16_HYPER_BEST.zip (385980 bytes)
  - artifacts/TFUGA_AI7_TRISTAN2_META_ORCHESTRATION_STATION_V15_FULL_BUILD.zip (364220 bytes)
  - artifacts/TFUGA_AI7_TRISTAN2_META_ORCHESTRATION_STATION_V14_SUPER_COMMAND.zip (333943 bytes)
  - artifacts/TFUGA_AI7_TRISTAN2_META_ORCHESTRATION_STATION_V13_MAX_PLUS_ULTRA.zip (323679 bytes)
  - artifacts/TFUGA_AI7_TRISTAN2_META_ORCHESTRATION_STATION_V12_TOP100.zip (254579 bytes)
  - artifacts/TFUGA_MASTER_ZIP_FINAL.zip (141510 bytes)
  - artifacts/TFUGA_AI7_TRISTAN2_META_ORCHESTRATION_STATION_V11.zip (100331 bytes)
  - artifacts/TFUGA_AI7_TRISTAN2_FINAL_ALL_IN_ONE.zip (73356 bytes)
- Documents lus: 95_sovereign_cockpit_and_meta_synergy/README.md, 95_sovereign_cockpit_and_meta_synergy/bounded_wave_templates.json, 95_sovereign_cockpit_and_meta_synergy/bridge_object_registry.json, 95_sovereign_cockpit_and_meta_synergy/fertile_compression_rules.json, 95_sovereign_cockpit_and_meta_synergy/meta_synergy_registry.json, 95_sovereign_cockpit_and_meta_synergy/shortest_path_to_canon.json, 96_execution_bus_hyperbest/README.md, 96_execution_bus_hyperbest/adapters/drive_control_row_mapping.json, 96_execution_bus_hyperbest/adapters/github_issue_pr_mapping.json, 96_execution_bus_hyperbest/adapters/runtime_receipt_mapping.json

## TFUGA_THEOREM_COMPUTE_READY_RUST_X10000_MAX.zip
- Taille ZIP: 6756 bytes; fichiers: 16; dossiers: 0; non compressé: 11987 bytes; ratio: 1.77x
- Extensions: {'.rs': 11, '.md': 3, '.json': 1, '.toml': 1}
- Racines: {'src': 7, 'tests': 3, 'Cargo.toml': 1, 'README.md': 1, 'benches': 1, 'docs': 1, 'examples': 1, 'report.json': 1}
- Plus gros fichiers:
  - src/t5k.rs (2925 bytes)
  - src/t9.rs (1633 bytes)
  - src/bin/tfuga_cli.rs (1343 bytes)
  - src/t8.rs (1231 bytes)
  - tests/t5k_tests.rs (777 bytes)
  - src/sparse_tensor.rs (697 bytes)
  - docs/RUST_X10000_UPGRADE_NOTES.md (521 bytes)
  - README.md (504 bytes)
- Documents lus: README.md, report.json, docs/RUST_X10000_UPGRADE_NOTES.md, benches/BENCH_NOTES.md

## TFUGA_V26_TOTAL_AUTOMATION_AMPLIFIER_MAX.zip
- Taille ZIP: 5804876 bytes; fichiers: 13; dossiers: 10; non compressé: 5806727 bytes; ratio: 1.0x
- Extensions: {'.json': 9, '.md': 2, '.zip': 2}
- Racines: {'artifacts': 2, '00_automation_amplifier_core': 1, '01_route_compiler': 1, '02_route_templates': 1, '03_adapter_playbooks': 1, '04_decision_automation': 1, '05_review_receipt_rollback_paths': 1, '06_surface_propagation_templates': 1, '07_pilot_execution_templates': 1, '08_machine_to_human_automation_views': 1, '09_next_amplified_actions': 1, 'README.md': 1}
- Plus gros fichiers:
  - artifacts/TFUGA_V25_LIVE_CONTROL_GRAPH_MAX.zip (3865375 bytes)
  - artifacts/TFUGA_V24_REAL_RECEIPT_ATLAS_MAX.zip (1935746 bytes)
  - 01_route_compiler/route_compiler.json (856 bytes)
  - 02_route_templates/route_templates.json (840 bytes)
  - 03_adapter_playbooks/adapter_playbooks.json (760 bytes)
  - README.md (504 bytes)
  - 00_automation_amplifier_core/automation_amplifier_core.json (493 bytes)
  - 06_surface_propagation_templates/surface_propagation_templates.json (487 bytes)
- Documents lus: README.md, 00_automation_amplifier_core/automation_amplifier_core.json, 01_route_compiler/route_compiler.json, 02_route_templates/route_templates.json, 03_adapter_playbooks/adapter_playbooks.json, 04_decision_automation/decision_automation.json, 05_review_receipt_rollback_paths/review_receipt_rollback_paths.json, 06_surface_propagation_templates/surface_propagation_templates.json, 07_pilot_execution_templates/pilot_execution_templates.json, 08_machine_to_human_automation_views/machine_to_human_automation_views.json

## axiom_auto_builder_v0_4.zip
- Taille ZIP: 148160 bytes; fichiers: 139; dossiers: 0; non compressé: 116470 bytes; ratio: 0.79x
- Extensions: {'.py': 55, '.md': 20, '.json': 18, '.yaml': 7, '.j2': 6, '.sh': 6, '.tpl': 6, '.c': 3, '.cpp': 3, '.cs': 2, '.csproj': 2, '.rs': 2, '[no_ext]': 2, '.dot': 1, '.full': 1, '.h': 1, '.hpp': 1, '.mmd': 1, '.toml': 1, '.txt': 1}
- Racines: {'axiom_auto_builder_v0_4': 139}
- Plus gros fichiers:
  - axiom_auto_builder_v0_4/reports/artifact_ledger.json (25089 bytes)
  - axiom_auto_builder_v0_4/generated/bin/axiom_c (16024 bytes)
  - axiom_auto_builder_v0_4/core/orchestrator.py (9779 bytes)
  - axiom_auto_builder_v0_4/generated/hypergraph/project_hypergraph.json (9200 bytes)
  - axiom_auto_builder_v0_4/reports/orchestration_report.json (5863 bytes)
  - axiom_auto_builder_v0_4/generated/hypergraph/task_graph.json (4179 bytes)
  - axiom_auto_builder_v0_4/generated/hypergraph/project_hypergraph.dot (2138 bytes)
  - axiom_auto_builder_v0_4/generated/hypergraph/project_hypergraph.mmd (1648 bytes)
- Documents lus: axiom_auto_builder_v0_4/configs/hypergraph_schema.json, axiom_auto_builder_v0_4/configs/project_manifest.yaml, axiom_auto_builder_v0_4/configs/defaults.yaml.json, axiom_auto_builder_v0_4/configs/defaults.yaml, axiom_auto_builder_v0_4/configs/local.example.yaml, axiom_auto_builder_v0_4/atlas/atlas_plan.yaml, axiom_auto_builder_v0_4/atlas/atlas_runtime.yaml, axiom_auto_builder_v0_4/atlas/agents.yaml, axiom_auto_builder_v0_4/atlas/workflows.yaml, axiom_auto_builder_v0_4/atlas/prompts/architect.md

## axiom_auto_builder_v0_8.zip
- Taille ZIP: 119376 bytes; fichiers: 190; dossiers: 0; non compressé: 313227 bytes; ratio: 2.62x
- Extensions: {'.py': 66, '.json': 42, '.md': 32, '.sh': 9, '.yaml': 7, '.j2': 6, '.tpl': 6, '.c': 3, '.cpp': 3, '.cs': 2, '.csproj': 2, '.rs': 2, '[no_ext]': 2, '.dot': 1, '.full': 1, '.h': 1, '.hpp': 1, '.mmd': 1, '.pyc': 1, '.toml': 1, '.txt': 1}
- Racines: {'axiom_auto_builder_v0_8': 190}
- Plus gros fichiers:
  - axiom_auto_builder_v0_8/evolution/state.json (86454 bytes)
  - axiom_auto_builder_v0_8/performance/curvefit_report.json (40449 bytes)
  - axiom_auto_builder_v0_8/core/performance_curvefit_engine.py (16190 bytes)
  - axiom_auto_builder_v0_8/generated/bin/axiom_c (16024 bytes)
  - axiom_auto_builder_v0_8/core/__pycache__/evolution_engine.cpython-313.pyc (15012 bytes)
  - axiom_auto_builder_v0_8/core/orchestrator.py (12977 bytes)
  - axiom_auto_builder_v0_8/core/evolution_engine.py (9664 bytes)
  - axiom_auto_builder_v0_8/generated/hypergraph/project_hypergraph.json (9017 bytes)
- Documents lus: axiom_auto_builder_v0_8/CHANGELOG.md, axiom_auto_builder_v0_8/README.md, axiom_auto_builder_v0_8/atlas/agents.yaml, axiom_auto_builder_v0_8/atlas/atlas_plan.yaml, axiom_auto_builder_v0_8/atlas/atlas_runtime.yaml, axiom_auto_builder_v0_8/atlas/prompts/architect.md, axiom_auto_builder_v0_8/atlas/prompts/refactorer.md, axiom_auto_builder_v0_8/atlas/prompts/reporter.md, axiom_auto_builder_v0_8/atlas/prompts/verifier.md, axiom_auto_builder_v0_8/atlas/workflows.yaml

## fsptmi_fractal_sponge_lab_v0_1.zip
- Taille ZIP: 40439 bytes; fichiers: 27; dossiers: 8; non compressé: 144591 bytes; ratio: 3.58x
- Extensions: {'.py': 9, '.pyc': 7, '.md': 5, '.json': 4, '.csv': 1, '.sh': 1}
- Racines: {'fsptmi_fractal_sponge_lab_v0_1': 27}
- Plus gros fichiers:
  - fsptmi_fractal_sponge_lab_v0_1/reports/fsptmi_summary.json (53599 bytes)
  - fsptmi_fractal_sponge_lab_v0_1/generated/design_candidates.json (41171 bytes)
  - fsptmi_fractal_sponge_lab_v0_1/reports/fsptmi_summary.csv (6740 bytes)
  - fsptmi_fractal_sponge_lab_v0_1/fsptmi/__pycache__/reporting.cpython-313.pyc (5707 bytes)
  - fsptmi_fractal_sponge_lab_v0_1/reports/FSPTMI_REPORT.md (5623 bytes)
  - fsptmi_fractal_sponge_lab_v0_1/fsptmi/__pycache__/fractals.cpython-313.pyc (5500 bytes)
  - fsptmi_fractal_sponge_lab_v0_1/fsptmi/__pycache__/physics_scores.cpython-313.pyc (3724 bytes)
  - fsptmi_fractal_sponge_lab_v0_1/fsptmi/__pycache__/evaluator.cpython-313.pyc (3459 bytes)
- Documents lus: fsptmi_fractal_sponge_lab_v0_1/README.md, fsptmi_fractal_sponge_lab_v0_1/configs/default_config.json, fsptmi_fractal_sponge_lab_v0_1/reports/fsptmi_summary.json, fsptmi_fractal_sponge_lab_v0_1/reports/FSPTMI_REPORT.md, fsptmi_fractal_sponge_lab_v0_1/reports/artifact_ledger.json, fsptmi_fractal_sponge_lab_v0_1/reports/VALIDATION.md, fsptmi_fractal_sponge_lab_v0_1/docs/CANON_FSPTMI.md, fsptmi_fractal_sponge_lab_v0_1/docs/MODELS_AND_EQUATIONS.md, fsptmi_fractal_sponge_lab_v0_1/generated/design_candidates.json

## tfuga_top1000_synergy_matrix_v1.zip
- Taille ZIP: 463271 bytes; fichiers: 6; dossiers: 0; non compressé: 10774102 bytes; ratio: 23.26x
- Extensions: {'.md': 3, '.csv': 2, '.json': 1}
- Racines: {'tfuga_top1000_synergy_matrix': 6}
- Plus gros fichiers:
  - tfuga_top1000_synergy_matrix/tfuga_top1000_synergy_matrix.json (5424722 bytes)
  - tfuga_top1000_synergy_matrix/tfuga_top1000_synergy_matrix_flat.csv (4939721 bytes)
  - tfuga_top1000_synergy_matrix/tfuga_top1000_summary.csv (320043 bytes)
  - tfuga_top1000_synergy_matrix/TFUGA_TOP1000_SYNERGY_REPORT.md (85303 bytes)
  - tfuga_top1000_synergy_matrix/THESIS_TOP1000_RESEARCH_MAP.md (3779 bytes)
  - tfuga_top1000_synergy_matrix/README.md (534 bytes)
- Documents lus: tfuga_top1000_synergy_matrix/TFUGA_TOP1000_SYNERGY_REPORT.md, tfuga_top1000_synergy_matrix/THESIS_TOP1000_RESEARCH_MAP.md, tfuga_top1000_synergy_matrix/README.md

## top1000_tfuga_synergy_engine.zip
- Taille ZIP: 118901 bytes; fichiers: 5; dossiers: 0; non compressé: 3411379 bytes; ratio: 28.69x
- Extensions: {'.json': 2, '.md': 2, '.csv': 1}
- Racines: {'README.md': 1, 'schema_top1000_abcd.json': 1, 'top1000_tfuga_10x_synergies.csv': 1, 'top1000_tfuga_10x_synergies.json': 1, 'top1000_tfuga_matrix_readable.md': 1}
- Plus gros fichiers:
  - top1000_tfuga_10x_synergies.json (1334436 bytes)
  - top1000_tfuga_matrix_readable.md (1092831 bytes)
  - top1000_tfuga_10x_synergies.csv (982604 bytes)
  - schema_top1000_abcd.json (842 bytes)
  - README.md (666 bytes)
- Documents lus: schema_top1000_abcd.json, README.md
