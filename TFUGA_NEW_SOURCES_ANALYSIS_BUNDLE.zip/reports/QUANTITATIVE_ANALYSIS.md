# Analyse quantitative des nouveaux artefacts TFUGA

## top1000_engine
```json
{
  "rows": 1000,
  "columns": [
    "id",
    "domain",
    "type",
    "item",
    "primary_layer",
    "maturity",
    "power_score_initial",
    "priority",
    "synergy_1",
    "synergy_2",
    "synergy_3",
    "synergy_4",
    "synergy_5",
    "synergy_6",
    "synergy_7",
    "synergy_8",
    "synergy_9",
    "synergy_10"
  ],
  "numeric_stats": {
    "id": {
      "min": 1.0,
      "max": 1000.0,
      "mean": 500.5,
      "median": 500.5
    },
    "power_score_initial": {
      "min": 70.04,
      "max": 98.99,
      "mean": 84.317,
      "median": 84.25999999999999
    }
  },
  "score_cols": [
    "power_score_initial"
  ],
  "top_by_power_score_initial": [
    {
      "id": "627",
      "domain": "Simulation, optimisation et jumeaux numériques",
      "type": "système",
      "item": "Moteur d’optimisation Simulation, optimisation et jumeaux numériques #21",
      "primary_layer": "D-future",
      "maturity": "simulation",
      "power_score_initial": "98.99",
      "priority": "P3"
    },
    {
      "id": "235",
      "domain": "Espace, autonomie et civilisation régénérative",
      "type": "application",
      "item": "Prototype conceptuel Espace, autonomie et civilisation régénérative #8",
      "primary_layer": "D-future",
      "maturity": "hypothèse structurée",
      "power_score_initial": "98.95",
      "priority": "P3"
    },
    {
      "id": "862",
      "domain": "Nanofabrication et CPUF",
      "type": "application",
      "item": "Pont canonique Nanofabrication et CPUF #29",
      "primary_layer": "C-generative",
      "maturity": "prototype",
      "power_score_initial": "98.94",
      "priority": "P2"
    },
    {
      "id": "470",
      "domain": "Recyclage et industrie régénérative",
      "type": "application",
      "item": "Application régénérative Recyclage et industrie régénérative #16",
      "primary_layer": "C-generative",
      "maturity": "modèle",
      "power_score_initial": "98.9",
      "priority": "P2"
    },
    {
      "id": "78",
      "domain": "Matériaux fractaux",
      "type": "application",
      "item": "Invariant opérationnel Matériaux fractaux #3",
      "primary_layer": "C-generative",
      "maturity": "rêve contrôlé",
      "power_score_initial": "98.86",
      "priority": "P2"
    },
    {
      "id": "705",
      "domain": "DK_SPINE et dynamiques spectrales",
      "type": "théorie",
      "item": "Prototype conceptuel DK_SPINE et dynamiques spectrales #24",
      "primary_layer": "B-meta",
      "maturity": "simulation",
      "power_score_initial": "98.85",
      "priority": "P1"
    },
    {
      "id": "313",
      "domain": "Circuits LC fractaux",
      "type": "système",
      "item": "Générateur fertile Circuits LC fractaux #11",
      "primary_layer": "B-meta",
      "maturity": "hypothèse structurée",
      "power_score_initial": "98.81",
      "priority": "P1"
    },
    {
      "id": "940",
      "domain": "Documents vivants et SourceHub",
      "type": "système",
      "item": "Application régénérative Documents vivants et SourceHub #32",
      "primary_layer": "A-local",
      "maturity": "prototype",
      "power_score_initial": "98.8",
      "priority": "P0"
    },
    {
      "id": "548",
      "domain": "Graphes, hypergraphes et tenseurs",
      "type": "théorie",
      "item": "Invariant opérationnel Graphes, hypergraphes et tenseurs #19",
      "primary_layer": "A-local",
      "maturity": "modèle",
      "power_score_initial": "98.76",
      "priority": "P0"
    },
    {
      "id": "156",
      "domain": "Preuves, invariants et validation",
      "type": "théorie",
      "item": "Architecture multi-échelle Preuves, invariants et validation #6",
      "primary_layer": "A-local",
      "maturity": "rêve contrôlé",
      "power_score_initial": "98.72",
      "priority": "P0"
    }
  ]
}
```

## top1000_matrix_summary
```json
{
  "rows": 1000,
  "columns": [
    "rank",
    "id",
    "domain",
    "mother_idea",
    "status",
    "maturity",
    "bridge_object",
    "primary_application",
    "power",
    "canonical_next_action"
  ],
  "numeric_stats": {
    "rank": {
      "min": 1.0,
      "max": 1000.0,
      "mean": 500.5,
      "median": 500.5
    },
    "power": {
      "min": 0.00238,
      "max": 0.57975,
      "mean": 0.05527427,
      "median": 0.038995
    }
  },
  "score_cols": [
    "power"
  ],
  "top_by_power": [
    {
      "rank": "52",
      "id": "THEORY-052",
      "domain": "Noyau théorique TFUGA",
      "mother_idea": "Yggdrasil hypergraphe canonique - variante 06",
      "status": "modèle",
      "maturity": "S2",
      "bridge_object": "hypergraphe tensoriel",
      "primary_application": "Atlas of Power",
      "power": "0.57975",
      "canonical_next_action": "Créer fiche canonique THEORY-052, formaliser variables/types, définir 1 test de falsification, relier à hypergraphe tensoriel et produire un micro-prototype pour Atlas of Power."
    },
    {
      "rank": "413",
      "id": "AI7-013",
      "domain": "IA, orchestrateurs et documents",
      "mother_idea": "Atlas observabilité TFUGA - variante 02",
      "status": "simulation",
      "maturity": "S3",
      "bridge_object": "preuve fertile",
      "primary_application": "traitement de l'eau",
      "power": "0.55043",
      "canonical_next_action": "Créer fiche canonique AI7-013, formaliser variables/types, définir 1 test de falsification, relier à preuve fertile et produire un micro-prototype pour traitement de l'eau."
    },
    {
      "rank": "138",
      "id": "MATH-038",
      "domain": "Mathématiques, opérateurs et preuves",
      "mother_idea": "Preuves parallèles modulaires - variante 04",
      "status": "simulation",
      "maturity": "S3",
      "bridge_object": "AI-7",
      "primary_application": "centrale AI-7",
      "power": "0.49431",
      "canonical_next_action": "Créer fiche canonique MATH-038, formaliser variables/types, définir 1 test de falsification, relier à AI-7 et produire un micro-prototype pour centrale AI-7."
    },
    {
      "rank": "774",
      "id": "SPACE-074",
      "domain": "Synergies ultimes et espace",
      "mother_idea": "Pilot system cavity-vacuum - variante 08",
      "status": "prototype",
      "maturity": "S4",
      "bridge_object": "validation théorie-code-expérience",
      "primary_application": "thèse",
      "power": "0.42882",
      "canonical_next_action": "Créer fiche canonique SPACE-074, formaliser variables/types, définir 1 test de falsification, relier à validation théorie-code-expérience et produire un micro-prototype pour thèse."
    },
    {
      "rank": "284",
      "id": "PHYS-084",
      "domain": "Circuits, énergie et systèmes physiques",
      "mother_idea": "TC-nPCI-kE - variante 09",
      "status": "prototype",
      "maturity": "S4",
      "bridge_object": "runtime de promotion",
      "primary_application": "portail web",
      "power": "0.42746",
      "canonical_next_action": "Créer fiche canonique PHYS-084, formaliser variables/types, définir 1 test de falsification, relier à runtime de promotion et produire un micro-prototype pour portail web."
    },
    {
      "rank": "499",
      "id": "AI7-099",
      "domain": "IA, orchestrateurs et documents",
      "mother_idea": "Scorecards KPI - variante 10",
      "status": "prototype",
      "maturity": "S4",
      "bridge_object": "contre-exemple",
      "primary_application": "réseau énergétique mycélien",
      "power": "0.42084",
      "canonical_next_action": "Créer fiche canonique AI7-099, formaliser variables/types, définir 1 test de falsification, relier à contre-exemple et produire un micro-prototype pour réseau énergétique mycélien."
    },
    {
      "rank": "267",
      "id": "PHYS-067",
      "domain": "Circuits, énergie et systèmes physiques",
      "mother_idea": "AI-Bots énergie - variante 07",
      "status": "modèle",
      "maturity": "S2",
      "bridge_object": "Atlas d'observabilité",
      "primary_application": "circuits LC fractaux",
      "power": "0.38978",
      "canonical_next_action": "Créer fiche canonique PHYS-067, formaliser variables/types, définir 1 test de falsification, relier à Atlas d'observabilité et produire un micro-prototype pour circuits LC fractaux."
    },
    {
      "rank": "181",
      "id": "MATH-081",
      "domain": "Mathématiques, opérateurs et preuves",
      "mother_idea": "FFWT transformée fractale-wavelet - variante 09",
      "status": "hypothèse",
      "maturity": "S1",
      "bridge_object": "SourceHub",
      "primary_application": "jeu éducatif",
      "power": "0.37762",
      "canonical_next_action": "Créer fiche canonique MATH-081, formaliser variables/types, définir 1 test de falsification, relier à SourceHub et produire un micro-prototype pour jeu éducatif."
    },
    {
      "rank": "327",
      "id": "MATERIAL-027",
      "domain": "Matériaux, eau, climat et industrie",
      "mother_idea": "Production industrielle distribuée - variante 03",
      "status": "modèle",
      "maturity": "S2",
      "bridge_object": "Atlas d'observabilité",
      "primary_application": "CPUF",
      "power": "0.36778",
      "canonical_next_action": "Créer fiche canonique MATERIAL-027, formaliser variables/types, définir 1 test de falsification, relier à Atlas d'observabilité et produire un micro-prototype pour CPUF."
    },
    {
      "rank": "198",
      "id": "MATH-098",
      "domain": "Mathématiques, opérateurs et preuves",
      "mother_idea": "Preuves parallèles modulaires - variante 10",
      "status": "simulation",
      "maturity": "S3",
      "bridge_object": "AI-7",
      "primary_application": "thèse",
      "power": "0.36631",
      "canonical_next_action": "Créer fiche canonique MATH-098, formaliser variables/types, définir 1 test de falsification, relier à AI-7 et produire un micro-prototype pour thèse."
    }
  ]
}
```

## top1000_matrix_flat
```json
{
  "rows": 10000,
  "columns": [
    "rank",
    "id",
    "domain",
    "mother_idea",
    "status",
    "maturity",
    "bridge_object",
    "primary_application",
    "power",
    "synergy_slot",
    "synergy_level",
    "synergy_name",
    "synergy"
  ],
  "first_rows": [
    {
      "rank": "1",
      "id": "THEORY-001",
      "domain": "Noyau théorique TFUGA",
      "mother_idea": "TFUGA méta-théorie unificatrice - variante 01",
      "status": "hypothèse",
      "maturity": "S1",
      "bridge_object": "SourceHub",
      "primary_application": "jeu éducatif",
      "power": "0.01804",
      "synergy_slot": "1",
      "synergy_level": "A1",
      "synergy_name": "Synergie locale",
      "synergy": "Synergie locale: fusionner avec un bloc voisin pour produire un résultat testable immédiat en couplant 'TFUGA méta-théorie unificatrice - variante 01' avec DK_SPINE et FFWT; sortie attendue: module vérifiable pour subvention CRSNG/Alliance, avec score Power, test de réfutation et chemin court vers le canon."
    },
    {
      "rank": "1",
      "id": "THEORY-001",
      "domain": "Noyau théorique TFUGA",
      "mother_idea": "TFUGA méta-théorie unificatrice - variante 01",
      "status": "hypothèse",
      "maturity": "S1",
      "bridge_object": "SourceHub",
      "primary_application": "jeu éducatif",
      "power": "0.01804",
      "synergy_slot": "2",
      "synergy_level": "A2",
      "synergy_name": "Synergie multiplicative",
      "synergy": "Synergie multiplicative: coupler deux mécanismes de sorte que le gain commun dépasse la somme des gains séparés en couplant 'TFUGA méta-théorie unificatrice - variante 01' avec hypergraphe tensoriel et SourceHub; sortie attendue: module vérifiable pour AT-SC-14, avec score Power, test de réfutation et chemin court vers le canon."
    },
    {
      "rank": "1",
      "id": "THEORY-001",
      "domain": "Noyau théorique TFUGA",
      "mother_idea": "TFUGA méta-théorie unificatrice - variante 01",
      "status": "hypothèse",
      "maturity": "S1",
      "bridge_object": "SourceHub",
      "primary_application": "jeu éducatif",
      "power": "0.01804",
      "synergy_slot": "3",
      "synergy_level": "B1",
      "synergy_name": "Méta-synergie",
      "synergy": "Méta-synergie: relier plusieurs synergies en pont mycélien entre branches de Yggdrasil en couplant 'TFUGA méta-théorie unificatrice - variante 01' avec SourceHub et anti-bullshit engine; sortie attendue: module vérifiable pour prototype spatial, avec score Power, test de réfutation et chemin court vers le canon."
    },
    {
      "rank": "1",
      "id": "THEORY-001",
      "domain": "Noyau théorique TFUGA",
      "mother_idea": "TFUGA méta-théorie unificatrice - variante 01",
      "status": "hypothèse",
      "maturity": "S1",
      "bridge_object": "SourceHub",
      "primary_application": "jeu éducatif",
      "power": "0.01804",
      "synergy_slot": "4",
      "synergy_level": "B2",
      "synergy_name": "Compression fertile",
      "synergy": "Compression fertile: réduire la complexité canonique tout en augmentant le nombre de conséquences utiles en couplant 'TFUGA méta-théorie unificatrice - variante 01' avec jumeau numérique et moteur de cristallisation; sortie attendue: module vérifiable pour SourceHub, avec score Power, test de réfutation et chemin court vers le canon."
    },
    {
      "rank": "1",
      "id": "THEORY-001",
      "domain": "Noyau théorique TFUGA",
      "mother_idea": "TFUGA méta-théorie unificatrice - variante 01",
      "status": "hypothèse",
      "maturity": "S1",
      "bridge_object": "SourceHub",
      "primary_application": "jeu éducatif",
      "power": "0.01804",
      "synergy_slot": "5",
      "synergy_level": "C1",
      "synergy_name": "Générateur de familles",
      "synergy": "Générateur de familles: transformer l'idée en moteur qui produit variantes, prototypes, preuves ou simulations en couplant 'TFUGA méta-théorie unificatrice - variante 01' avec contre-exemple et FFWT; sortie attendue: module vérifiable pour réseau énergétique mycélien, avec score Power, test de réfutation et chemin court vers le canon."
    }
  ]
}
```

## fsptmi
```json
{
  "rows": 36,
  "columns": [
    "rank",
    "id",
    "geometry",
    "dimension",
    "generation",
    "power",
    "risk",
    "status",
    "recommended_use",
    "tpv",
    "pv",
    "laser",
    "battery",
    "thermal_transport",
    "ionic_transport",
    "manufacturability",
    "stability",
    "fractal_dimension",
    "porosity",
    "surface_to_volume_proxy"
  ],
  "power_stats": {
    "min": 0.47017,
    "max": 0.693295,
    "mean": 0.5826929444444445,
    "median": 0.5828504999999999
  },
  "risk_stats": {
    "min": 0.161859,
    "max": 0.439971,
    "mean": 0.2781837777777778,
    "median": 0.2513435
  },
  "fractal_dimension_stats": {
    "min": 1.7712,
    "max": 3.8928,
    "mean": 2.788091666666667,
    "median": 2.7489999999999997
  },
  "porosity_stats": {
    "min": 0.037,
    "max": 0.7919,
    "mean": 0.3381527777777778,
    "median": 0.2977
  },
  "surface_to_volume_proxy_stats": {
    "min": 3.0,
    "max": 27.0,
    "mean": 13.0,
    "median": 9.0
  },
  "top10": [
    {
      "name": "",
      "power": "0.693295",
      "risk": "0.205140",
      "status": "promote_candidate",
      "recommended_use": "high-stability structural scaffold",
      "fractal_dimension": "2.7268",
      "porosity": "0.4513",
      "surface_to_volume_proxy": "9.0000"
    },
    {
      "name": "",
      "power": "0.685200",
      "risk": "0.243808",
      "status": "promote_candidate",
      "recommended_use": "high-stability structural scaffold",
      "fractal_dimension": "2.7268",
      "porosity": "0.5936",
      "surface_to_volume_proxy": "27.0000"
    },
    {
      "name": "",
      "power": "0.659004",
      "risk": "0.284674",
      "status": "promote_candidate",
      "recommended_use": "membrane / ion transport scaffold",
      "fractal_dimension": "2.6801",
      "porosity": "0.5048",
      "surface_to_volume_proxy": "9.0000"
    },
    {
      "name": "",
      "power": "0.641354",
      "risk": "0.161859",
      "status": "promote_candidate",
      "recommended_use": "fabrication reference geometry",
      "fractal_dimension": "2.7268",
      "porosity": "0.2593",
      "surface_to_volume_proxy": "3.0000"
    },
    {
      "name": "",
      "power": "0.635536",
      "risk": "0.319384",
      "status": "promote_candidate",
      "recommended_use": "fractal photonic laser cavity or directional emitter",
      "fractal_dimension": "2.6801",
      "porosity": "0.6515",
      "surface_to_volume_proxy": "27.0000"
    },
    {
      "name": "",
      "power": "0.624490",
      "risk": "0.178821",
      "status": "promote_candidate",
      "recommended_use": "high-stability structural scaffold",
      "fractal_dimension": "3.5237",
      "porosity": "0.4074",
      "surface_to_volume_proxy": "3.0000"
    },
    {
      "name": "",
      "power": "0.618113",
      "risk": "0.245939",
      "status": "promote_candidate",
      "recommended_use": "high-stability structural scaffold",
      "fractal_dimension": "1.8928",
      "porosity": "0.2977",
      "surface_to_volume_proxy": "27.0000"
    },
    {
      "name": "",
      "power": "0.614600",
      "risk": "0.243808",
      "status": "promote_candidate",
      "recommended_use": "high-stability structural scaffold",
      "fractal_dimension": "1.8928",
      "porosity": "0.2977",
      "surface_to_volume_proxy": "27.0000"
    },
    {
      "name": "",
      "power": "0.612761",
      "risk": "0.245833",
      "status": "promote_candidate",
      "recommended_use": "fabrication reference geometry",
      "fractal_dimension": "2.6801",
      "porosity": "0.2963",
      "surface_to_volume_proxy": "3.0000"
    },
    {
      "name": "",
      "power": "0.612544",
      "risk": "0.219888",
      "status": "promote_candidate",
      "recommended_use": "high-stability structural scaffold",
      "fractal_dimension": "3.5237",
      "porosity": "0.6488",
      "surface_to_volume_proxy": "9.0000"
    }
  ]
}
```

## v26_nested_zips
```json
[
  {
    "zip": "artifacts/TFUGA_V24_REAL_RECEIPT_ATLAS_MAX.zip",
    "file_count": 13,
    "uncompressed_bytes": 1950873,
    "largest": [
      [
        1940113,
        "artifacts/TFUGA_V23_TOTAL_AUTOMATION_CONTROL_MAX.zip"
      ],
      [
        6967,
        "artifacts/TFUGA_V22_ATLAS_TOTAL_HYPER_BEST.zip"
      ],
      [
        571,
        "01_receipt_registry/receipt_registry.json"
      ],
      [
        481,
        "05_machine_to_human_views/machine_to_human_receipt_views.json"
      ],
      [
        382,
        "09_next_receipt_actions/next_receipt_actions.md"
      ]
    ]
  },
  {
    "zip": "artifacts/TFUGA_V25_LIVE_CONTROL_GRAPH_MAX.zip",
    "file_count": 13,
    "uncompressed_bytes": 3880536,
    "largest": [
      [
        1940113,
        "artifacts/TFUGA_V23_TOTAL_AUTOMATION_CONTROL_MAX.zip"
      ],
      [
        1935746,
        "artifacts/TFUGA_V24_REAL_RECEIPT_ATLAS_MAX.zip"
      ],
      [
        896,
        "02_graph_edges/graph_edges.json"
      ],
      [
        798,
        "01_graph_nodes/graph_nodes.json"
      ],
      [
        445,
        "00_live_control_core/live_control_core.json"
      ]
    ]
  }
]
```

## mega_nested_zips
```json
[
  {
    "zip": "artifacts/TFUGA_AI7_TRISTAN2_FINAL_ALL_IN_ONE.zip",
    "file_count": 104,
    "uncompressed_bytes": 113271,
    "largest": [
      [
        19419,
        "reports/TFUGA_sovereign_intake_report_with_theories_and_projects.md"
      ],
      [
        3947,
        "96_execution_bus_hyperbest/scripts/runtime_governance_simulator.py"
      ],
      [
        3491,
        "98_meta_generation_autogouvernee/sovereign_meta_generator_manifest.json"
      ],
      [
        3462,
        "99_tristan_canonical_theory/tristan_applied_branches.json"
      ],
      [
        3212,
        "tfuga_final_zip/scripts/run_all_fractal_loops.py"
      ]
    ]
  },
  {
    "zip": "artifacts/TFUGA_AI7_TRISTAN2_META_ORCHESTRATION_STATION_V11.zip",
    "file_count": 136,
    "uncompressed_bytes": 164213,
    "largest": [
      [
        19419,
        "reports/TFUGA_sovereign_intake_report_with_theories_and_projects.md"
      ],
      [
        10697,
        "tfuga_final_zip/station/output/station_state.json"
      ],
      [
        6205,
        "tfuga_final_zip/station/core/__pycache__/orchestrator.cpython-313.pyc"
      ],
      [
        4416,
        "tfuga_final_zip/station/core/orchestrator.py"
      ],
      [
        4032,
        "tfuga_final_zip/station/core/__pycache__/models.cpython-313.pyc"
      ]
    ]
  },
  {
    "zip": "artifacts/TFUGA_AI7_TRISTAN2_META_ORCHESTRATION_STATION_V12_TOP100.zip",
    "file_count": 340,
    "uncompressed_bytes": 432822,
    "largest": [
      [
        69368,
        "tfuga_final_zip/meta_generation/top100_modules/TOP100_MODULE_REGISTRY.json"
      ],
      [
        19419,
        "reports/TFUGA_sovereign_intake_report_with_theories_and_projects.md"
      ],
      [
        12610,
        "tfuga_final_zip/station/output/station_state.json"
      ],
      [
        7522,
        "tfuga_final_zip/station/core/__pycache__/orchestrator.cpython-313.pyc"
      ],
      [
        5491,
        "tfuga_final_zip/meta_generation/top100_modules/TOP100_MODULE_REGISTRY.md"
      ]
    ]
  },
  {
    "zip": "artifacts/TFUGA_AI7_TRISTAN2_META_ORCHESTRATION_STATION_V13_MAX_PLUS_ULTRA.zip",
    "file_count": 392,
    "uncompressed_bytes": 531834,
    "largest": [
      [
        69368,
        "TFUGA_AI7_TRISTAN2_META_ORCHESTRATION_STATION_V13_MAX/meta_generation/top100_modules/TOP100_MODULE_REGISTRY.json"
      ],
      [
        19419,
        "reports/TFUGA_sovereign_intake_report_with_theories_and_projects.md"
      ],
      [
        16430,
        "TFUGA_AI7_TRISTAN2_META_ORCHESTRATION_STATION_V13_MAX/station/output/station_state.json"
      ],
      [
        13731,
        "TFUGA_AI7_TRISTAN2_META_ORCHESTRATION_STATION_V13_MAX/meta_generation/top20_active/TOP20_ACTIVE_REGISTRY.json"
      ],
      [
        8134,
        "TFUGA_AI7_TRISTAN2_META_ORCHESTRATION_STATION_V13_MAX/station/campaigns/top20_campaigns.json"
      ]
    ]
  },
  {
    "zip": "artifacts/TFUGA_AI7_TRISTAN2_META_ORCHESTRATION_STATION_V14_SUPER_COMMAND.zip",
    "file_count": 405,
    "uncompressed_bytes": 554985,
    "largest": [
      [
        69368,
        "TFUGA_AI7_TRISTAN2_META_ORCHESTRATION_STATION_V13_MAX/meta_generation/top100_modules/TOP100_MODULE_REGISTRY.json"
      ],
      [
        19419,
        "reports/TFUGA_sovereign_intake_report_with_theories_and_projects.md"
      ],
      [
        13731,
        "TFUGA_AI7_TRISTAN2_META_ORCHESTRATION_STATION_V13_MAX/meta_generation/top20_active/TOP20_ACTIVE_REGISTRY.json"
      ],
      [
        13195,
        "TFUGA_AI7_TRISTAN2_META_ORCHESTRATION_STATION_V13_MAX/station/output/station_state.json"
      ],
      [
        9344,
        "TFUGA_AI7_TRISTAN2_META_ORCHESTRATION_STATION_V13_MAX/meta_generation/top10_near_promotable/TOP10_NEAR_PROMOTABLE_REGISTRY.json"
      ]
    ]
  },
  {
    "zip": "artifacts/TFUGA_AI7_TRISTAN2_META_ORCHESTRATION_STATION_V15_FULL_BUILD.zip",
    "file_count": 433,
    "uncompressed_bytes": 592391,
    "largest": [
      [
        69368,
        "TFUGA_AI7_TRISTAN2_META_ORCHESTRATION_STATION_V15_FULL_BUILD/meta_generation/top100_modules/TOP100_MODULE_REGISTRY.json"
      ],
      [
        19419,
        "reports/TFUGA_sovereign_intake_report_with_theories_and_projects.md"
      ],
      [
        14034,
        "TFUGA_AI7_TRISTAN2_META_ORCHESTRATION_STATION_V15_FULL_BUILD/station/output/station_state.json"
      ],
      [
        13731,
        "TFUGA_AI7_TRISTAN2_META_ORCHESTRATION_STATION_V15_FULL_BUILD/meta_generation/top20_active/TOP20_ACTIVE_REGISTRY.json"
      ],
      [
        9344,
        "TFUGA_AI7_TRISTAN2_META_ORCHESTRATION_STATION_V15_FULL_BUILD/meta_generation/top10_near_promotable/TOP10_NEAR_PROMOTABLE_REGISTRY.json"
      ]
    ]
  },
  {
    "zip": "artifacts/TFUGA_AI7_TRISTAN2_META_ORCHESTRATION_STATION_V16_HYPER_BEST.zip",
    "file_count": 461,
    "uncompressed_bytes": 622309,
    "largest": [
      [
        69368,
        "TFUGA_AI7_TRISTAN2_META_ORCHESTRATION_STATION_V15_FULL_BUILD/meta_generation/top100_modules/TOP100_MODULE_REGISTRY.json"
      ],
      [
        19419,
        "reports/TFUGA_sovereign_intake_report_with_theories_and_projects.md"
      ],
      [
        14034,
        "TFUGA_AI7_TRISTAN2_META_ORCHESTRATION_STATION_V15_FULL_BUILD/station/output/station_state.json"
      ],
      [
        13731,
        "TFUGA_AI7_TRISTAN2_META_ORCHESTRATION_STATION_V15_FULL_BUILD/meta_generation/top20_active/TOP20_ACTIVE_REGISTRY.json"
      ],
      [
        9344,
        "TFUGA_AI7_TRISTAN2_META_ORCHESTRATION_STATION_V15_FULL_BUILD/meta_generation/top10_near_promotable/TOP10_NEAR_PROMOTABLE_REGISTRY.json"
      ]
    ]
  },
  {
    "zip": "artifacts/TFUGA_MASTER_ZIP_FINAL.zip",
    "file_count": 69,
    "uncompressed_bytes": 193392,
    "largest": [
      [
        28854,
        "artifacts/TFUGA_V18_MASTER_FUSION_STATION_MAX.zip"
      ],
      [
        28315,
        "artifacts/TFUGA_V19_EXECUTION_CORE_MAX.zip"
      ],
      [
        28296,
        "ar
...TRUNCATED...
```
