# TFUGA / AI-7 Top-1000 Synergy Matrix

Contenu:
- `tfuga_top1000_synergy_matrix.json`: version structurée complète.
- `tfuga_top1000_synergy_matrix_flat.csv`: 10 000 synergies en format tabulaire.
- `tfuga_top1000_summary.csv`: résumé des 1000 entrées.
- `TFUGA_TOP1000_SYNERGY_REPORT.md`: rapport lisible avec les premières entrées détaillées et le top par score.
- `THESIS_TOP1000_RESEARCH_MAP.md`: carte de thèse dérivée.

Commande utile:
```bash
python3 -m json.tool tfuga_top1000_synergy_matrix.json > /dev/null
```
