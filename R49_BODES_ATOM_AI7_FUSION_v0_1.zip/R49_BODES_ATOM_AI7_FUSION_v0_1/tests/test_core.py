import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from r49_ai7.r49 import ordered_trajectory_count, compressed_profile_count, standard_profiles, repeat_gain, delta_repeat
from r49_ai7.power import PowerFactors, gate_passes
from r49_ai7.multiscale import useful_fractality, link_useful, MaterialCard
from r49_ai7.bodes import packet_gain_db


def test_counts():
    assert ordered_trajectory_count() == 7 ** 49
    assert compressed_profile_count() == 28989675
    assert all(p.total() == 49 for p in standard_profiles().values())


def test_repeat_gain_and_gate():
    rg = repeat_gain([(1, 1.2), (2, 3)])
    assert rg == 1.8
    pf = PowerFactors(fertility=2, verifiability=2, repeat_gain=rg, complexity=1, noise=1, speculation=1, risk=1)
    assert pf.score() > 1
    assert gate_passes(pf.score(), dct=True, safety=True, repeat_gain=rg)
    assert delta_repeat(1, 2) > 0


def test_material_and_fractality():
    card = MaterialCard("demo", "role", 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1)
    assert card.score() == 1
    assert useful_fractality(0.5, 0.1, 0.1)
    assert link_useful(0.2, 0.2, 0.2, 0.2, 0.1, 0.1)


def test_bodes_packet_gain_is_finite():
    g = packet_gain_db(2e6, [2e6, 18e6, 162e6])
    assert -80 < g < 80
