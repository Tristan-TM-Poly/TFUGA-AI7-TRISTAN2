from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Dict

@dataclass(frozen=True)
class MaterialCard:
    name: str
    role: str
    performance: float
    durability: float
    safety: float
    repairability: float
    recyclability: float
    availability: float
    cost: float
    toxicity: float
    criticality: float
    thermal_risk: float
    manufacturing_complexity: float

    def score(self) -> float:
        numerator = self.performance * self.durability * self.safety * self.repairability * self.recyclability * self.availability
        denominator = self.cost * self.toxicity * self.criticality * self.thermal_risk * self.manufacturing_complexity
        if denominator <= 0:
            raise ValueError("Material denominator must be positive")
        return numerator / denominator

    def to_dict(self) -> Dict[str, object]:
        d = asdict(self)
        d["material_score"] = self.score()
        return d


def useful_fractality(delta_performance: float, delta_complexity: float, delta_risk: float, lambda_complexity: float = 1.0, mu_risk: float = 1.0) -> bool:
    return delta_performance - lambda_complexity * delta_complexity - mu_risk * delta_risk > 0


def link_useful(delta_resilience: float, delta_efficiency: float, delta_repairability: float, delta_observability: float, delta_complexity: float, delta_risk: float, lambda_complexity: float = 1.0, mu_risk: float = 1.0) -> bool:
    left = delta_resilience + delta_efficiency + delta_repairability + delta_observability
    right = lambda_complexity * delta_complexity + mu_risk * delta_risk
    return left > right
