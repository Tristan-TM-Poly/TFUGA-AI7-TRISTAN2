from __future__ import annotations
from dataclasses import dataclass
from typing import Iterable, List
import math

@dataclass(frozen=True)
class PacketMetric:
    name: str
    center_hz: float
    width_hz: float
    gain_db: float
    group_delay_s: float
    distortion_proxy: float


def branch_response(freq_hz: float, center_hz: float, q: float, gain_linear: float) -> complex:
    if freq_hz <= 0 or center_hz <= 0 or q <= 0:
        raise ValueError("freq_hz, center_hz and q must be positive")
    x = freq_hz / center_hz
    denom = complex(1.0, q * (x - 1.0 / x))
    return gain_linear / denom


def network_response(freq_hz: float, centers_hz: Iterable[float], q: float = 18.0, gain_db: float = 24.0) -> complex:
    gain_linear = 10 ** (gain_db / 20.0)
    branches = [branch_response(freq_hz, c, q, gain_linear) for c in centers_hz]
    return sum(branches) / max(1, len(branches))


def packet_gain_db(center_hz: float, centers_hz: Iterable[float], q: float = 18.0, gain_db: float = 24.0) -> float:
    h = network_response(center_hz, centers_hz, q=q, gain_db=gain_db)
    return 20.0 * math.log10(abs(h))


def coherence_ratio(packets: List[PacketMetric]) -> float:
    diag = sum(abs(p.gain_db) + 1e-9 for p in packets)
    off = 0.0
    for i, p in enumerate(packets):
        for j, q in enumerate(packets):
            if i != j:
                separation = abs(math.log(p.center_hz / q.center_hz))
                off += math.exp(-separation * 4.0)
    return off / diag
