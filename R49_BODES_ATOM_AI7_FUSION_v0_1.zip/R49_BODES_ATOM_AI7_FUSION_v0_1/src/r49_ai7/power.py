from __future__ import annotations
from dataclasses import dataclass

@dataclass(frozen=True)
class PowerFactors:
    fertility: float = 1.0
    verifiability: float = 1.0
    reuse: float = 1.0
    impact: float = 1.0
    compression: float = 1.0
    stability: float = 1.0
    repeat_gain: float = 1.0
    complexity: float = 1.0
    noise: float = 1.0
    speculation: float = 1.0
    risk: float = 1.0

    def score(self) -> float:
        numerator = self.fertility * self.verifiability * self.reuse * self.impact * self.compression * self.stability * self.repeat_gain
        denominator = self.complexity * self.noise * self.speculation * self.risk
        if denominator <= 0:
            raise ValueError("Power denominator must be positive")
        return numerator / denominator


def gate_passes(score: float, dct: bool, safety: bool, repeat_gain: float, threshold: float = 1.0) -> bool:
    return score > threshold and bool(dct) and bool(safety) and repeat_gain > 1.0
