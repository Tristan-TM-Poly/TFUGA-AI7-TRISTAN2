from __future__ import annotations
from dataclasses import dataclass, asdict
from math import comb, prod, log
from typing import Dict, List, Sequence

STATES = ("1", "I", "T", "S", "A", "H", "R")
CYCLES = ("spark", "formalization", "toy_model", "simulation", "prototype", "system_integration", "canon_reproduction")

@dataclass(frozen=True)
class Profile49:
    neutral: int
    ideas: int
    theories: int
    systems: int
    applications: int
    hypergraphs: int
    repeats: int

    def total(self) -> int:
        return sum(asdict(self).values())

    def validate(self) -> None:
        if self.total() != 49:
            raise ValueError(f"Profile must sum to 49, got {self.total()}")
        if min(asdict(self).values()) < 0:
            raise ValueError("Profile counts must be non-negative")

    def vector(self) -> List[int]:
        self.validate()
        return [self.neutral, self.ideas, self.theories, self.systems, self.applications, self.hypergraphs, self.repeats]


def ordered_trajectory_count() -> int:
    return 7 ** 49


def compressed_profile_count() -> int:
    return comb(55, 6)


def standard_profiles() -> Dict[str, Profile49]:
    return {
        "AI7Plant": Profile49(3, 5, 7, 10, 8, 8, 8),
        "TFUGATheory": Profile49(4, 8, 14, 4, 3, 9, 7),
        "RLC_kT_HFM": Profile49(3, 6, 9, 9, 6, 8, 8),
        "WaterRecycling": Profile49(3, 5, 6, 8, 12, 7, 8),
        "CodeOrchestrator": Profile49(2, 4, 5, 9, 6, 6, 17),
        "BodesTristan": Profile49(3, 5, 10, 8, 8, 7, 8),
        "AtomToAI7": Profile49(4, 5, 8, 9, 7, 8, 8),
    }


def repeat_gain(power_before_after: Sequence[tuple[float, float]], floor: float = 1.0) -> float:
    gains = []
    for before, after in power_before_after:
        if before <= 0 or after <= 0:
            raise ValueError("Power values must be positive")
        gains.append(max(floor, after / before))
    return prod(gains) if gains else 1.0


def delta_repeat(before: float, after: float) -> float:
    if before <= 0 or after <= 0:
        raise ValueError("Power values must be positive")
    return log(after / before)


def make_square_matrix() -> List[List[str]]:
    return [[f"C{ci+1}:{state}" for state in STATES] for ci in range(7)]


def profile_balance_score(profile: Profile49) -> float:
    v = profile.vector()
    active = v[1:]
    mean = sum(active) / len(active)
    dispersion = sum((x - mean) ** 2 for x in active) / len(active)
    system_weight = (profile.systems + profile.applications + profile.hypergraphs + profile.repeats) / 49
    return system_weight / (1.0 + dispersion / 10.0)
