from __future__ import annotations
import csv, json
from pathlib import Path
from .r49 import ordered_trajectory_count, compressed_profile_count, standard_profiles, profile_balance_score, repeat_gain, make_square_matrix
from .power import PowerFactors, gate_passes
from .bodes import PacketMetric, coherence_ratio
from .multiscale import MaterialCard, useful_fractality, link_useful


def build_outputs(out_dir: Path) -> dict:
    out_dir.mkdir(parents=True, exist_ok=True)
    profiles = standard_profiles()
    repeat = repeat_gain([(1.0, 1.12), (1.2, 1.32), (1.3, 1.47)])
    power = PowerFactors(fertility=1.35, verifiability=1.25, reuse=1.30, impact=1.45, compression=1.15, stability=1.18, repeat_gain=repeat, complexity=1.55, noise=1.10, speculation=1.22, risk=1.18).score()
    packets = [
        PacketMetric("P1", 2e6, 80e3, 18.430, 6.177e-6, 2.402),
        PacketMetric("P2", 18e6, 800e3, 18.553, 0.599e-6, 2.258),
        PacketMetric("P3", 162e6, 9e6, 18.199, 59.0e-9, 2.598),
        PacketMetric("P4", 486e6, 18e6, 19.701, 21.1e-9, 1.256),
    ]
    materials = [
        MaterialCard("Copper", "conductor", 1.25, 1.10, 1.15, 1.20, 1.15, 1.05, 1.10, 1.02, 1.08, 1.12, 1.05),
        MaterialCard("Ferrite", "magnetic_core", 1.10, 1.05, 1.12, 1.00, 0.95, 0.98, 1.15, 1.05, 1.08, 1.18, 1.15),
        MaterialCard("TFLN", "electro_optic", 1.45, 1.05, 1.02, 0.82, 0.80, 0.75, 1.80, 1.02, 1.25, 1.05, 1.65),
    ]
    summary = {
        "generator": "ITSAHR49/R49 + Bodes-Tristan + Atom-to-AI7 fusion",
        "ordered_trajectories": ordered_trajectory_count(),
        "compressed_profiles": compressed_profile_count(),
        "compression_ratio": ordered_trajectory_count() / compressed_profile_count(),
        "repeat_gain_demo": repeat,
        "power49_demo": power,
        "gate_demo": gate_passes(power, dct=True, safety=True, repeat_gain=repeat, threshold=1.0),
        "coherence_ratio_demo": coherence_ratio(packets),
        "useful_fractality_demo": useful_fractality(0.32, 0.11, 0.07),
        "useful_link_demo": link_useful(0.20, 0.08, 0.10, 0.15, 0.18, 0.06),
        "profile_balance": {name: profile_balance_score(p) for name, p in profiles.items()},
        "profiles": {name: p.vector() for name, p in profiles.items()},
        "square_matrix": make_square_matrix(),
        "materials": [m.to_dict() for m in materials],
    }
    (out_dir / "fusion_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    with (out_dir / "profiles.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["name", "n_1", "n_I", "n_T", "n_S", "n_A", "n_H", "n_R", "balance_score"])
        for name, p in profiles.items():
            writer.writerow([name, *p.vector(), profile_balance_score(p)])
    with (out_dir / "packet_metrics.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["packet", "center_hz", "width_hz", "gain_db", "group_delay_s", "distortion_proxy"])
        for p in packets:
            writer.writerow([p.name, p.center_hz, p.width_hz, p.gain_db, p.group_delay_s, p.distortion_proxy])
    return summary
