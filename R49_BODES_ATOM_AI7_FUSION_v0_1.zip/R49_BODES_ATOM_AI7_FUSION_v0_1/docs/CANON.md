# CANON v0.1

Équation centrale :

```text
R49(X) = CanonGate o SafetyGate o DCTGate o Score49 o prod_{c=1}^7(1_c + I_c + T_c + S_c + A_c + H_c + R_c)(X)
```

Score :

```text
Power49 = Fertility * Verifiability * Reuse * Impact * Compression * Stability * RepeatGain
          / (Complexity * Noise * UntestedSpeculation * Risk)
```

Règle de survie :

```text
Survive(w) iff Power49(w) > theta and DCT(w)=1 and Safety(w)=1 and RepeatGain(w)>1
```

Statuts :

- R49 : CrystalGarden L5.
- Bodes-Tristan : branche cristallisable forte, pas canon physique stable.
- Atom-to-AI7 : tronc stable pour atome -> matériau -> composant ; cristallisable pour module -> centrale.
