from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from r49_ai7.generate_outputs import build_outputs

if __name__ == "__main__":
    summary = build_outputs(ROOT / "outputs")
    print("R49 fusion demo complete")
    print(f"ordered={summary['ordered_trajectories']}")
    print(f"profiles={summary['compressed_profiles']}")
    print(f"repeat_gain={summary['repeat_gain_demo']:.6f}")
    print(f"power49={summary['power49_demo']:.6f}")
    print(f"gate={summary['gate_demo']}")
