# R49 Bodes-Tristan Atom-to-AI7 Fusion v0.1

Livrable AI-7 qui fusionne trois cristaux :

1. `R49 = (1+I+T+S+A+H+R)^(7^2)` comme générateur carré de maturation.
2. Bodes-Tristan comme lecture paquet d'ondes + cohérence matricielle + réseau résonant fractal.
3. Atom-to-AI7 comme descente atome -> matériau -> composant -> circuit -> module -> centrale AI-7.

## Lancer

```bash
python scripts/run_demo.py
pytest -q
```

## Sorties

- `outputs/fusion_summary.json`
- `outputs/profiles.csv`
- `outputs/packet_metrics.csv`

## Statut

CrystalGarden L5. Candidat CoreCanon après trois démonstrateurs DCT complets : AI7Plant, RLC-kT-HFM, Water/Recycling.
