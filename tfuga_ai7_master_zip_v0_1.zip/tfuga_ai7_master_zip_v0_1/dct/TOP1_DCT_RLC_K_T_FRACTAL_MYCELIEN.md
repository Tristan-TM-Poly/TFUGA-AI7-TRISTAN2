# DCT — Circuit RLC-k-T fractal-mycélien toy model

## Objectif

Créer un modèle discret, sûr et basse puissance d'un réseau RLC fractal-mycélien inspiré d'un solénoïde récursif : un solénoïde qui suit un solénoïde qui suit un solénoïde, jusqu'à n niveaux, avec ponts R/L/C/M, k-phasage et résonances multiples.

## Document

Le système est représenté comme un hypergraphe électromagnétique :

- noeuds : niveaux solénoïdaux
- hyperarêtes : couplages R, L, C, M
- matrices : R, L, C, M
- générateur : T_RLC ou DK_SPINE local
- observables : modes propres, fréquences de résonance, impédance, stabilité

## Calcul/Code

Le module `src/tfuga_ai7/rlc_fractal.py` génère :

- matrice R
- matrice L
- matrice C
- matrice M
- couplage magnétique inter-échelles
- fréquences de résonance approximatives
- matrice d'impédance Z(jw)

## Test

Exécuter :

```bash
python examples/rlc_toy_demo.py
python tests/test_rlc.py
```

## Hypothèses

- Modèle discret simplifié.
- Usage simulation seulement.
- Pas de construction haute puissance.
- Couplages faibles, contrôlés et pédagogiques.

## Safety gates

- LowPowerOnly.
- SimulationOnly by default.
- NoDirectedHarm.
- NoDangerousScaling.
- HardwareReviewBeforeBuild.
- DCTsafe.

## Critères de succès

- Les matrices ont dimensions cohérentes.
- Les résonances calculées sont positives.
- L'impédance complexe est calculable.
- Le modèle produit un résumé JSON et un scan CSV.
- Le projet reste orienté filtrage, mesure, pédagogie et qualité de puissance.
