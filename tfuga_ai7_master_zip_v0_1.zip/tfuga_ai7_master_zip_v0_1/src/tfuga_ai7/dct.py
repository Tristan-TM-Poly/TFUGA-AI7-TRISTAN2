from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Dict, Any

@dataclass
class DCTCard:
    title: str
    objective: str
    document: str
    calculation_or_code: str
    test: str
    assumptions: List[str] = field(default_factory=list)
    risks: List[str] = field(default_factory=list)
    safety_gates: List[str] = field(default_factory=list)
    success_criteria: List[str] = field(default_factory=list)
    next_action: str = ""

    def is_minimally_complete(self) -> bool:
        return all([
            bool(self.title.strip()),
            bool(self.objective.strip()),
            bool(self.document.strip()),
            bool(self.calculation_or_code.strip()),
            bool(self.test.strip()),
            len(self.success_criteria) > 0,
        ])

    def to_markdown(self) -> str:
        def bullets(items):
            return "\n".join(f"- {x}" for x in items) if items else "- TBD"
        return f"""# DCT — {self.title}

## Objectif
{self.objective}

## Document
{self.document}

## Calcul/Code
{self.calculation_or_code}

## Test
{self.test}

## Hypothèses
{bullets(self.assumptions)}

## Risques
{bullets(self.risks)}

## Safety gates
{bullets(self.safety_gates)}

## Critères de succès
{bullets(self.success_criteria)}

## Prochaine action
{self.next_action or "TBD"}
"""
