from __future__ import annotations
from dataclasses import dataclass, asdict
from itertools import product
from typing import Iterable, Dict, Any, List

D10 = [
    "Noyau théorique TFUGA",
    "Mathématiques et opérateurs",
    "Circuits et électromagnétisme",
    "Énergie et centrales AI-7",
    "Matériaux, eau, climat et industrie",
    "IA, documents et orchestration",
    "Simulation, code et expérimentation",
    "Cognition, langage et preuve",
    "Civilisations, écologie et forêts",
    "Mission humanitaire, espace et montée d'échelle",
]

R10 = [
    "Hypergraphe", "Générateur", "Fractal", "Mycélium", "Action",
    "Cohérence", "DCT", "Safety/Commons", "Canon", "Prototype"
]

F10 = [
    "Formaliser", "Générer", "Relier", "Mesurer", "Vérifier",
    "Optimiser", "Protéger", "Réparer", "Compresser", "Transmettre"
]

A10 = [
    "Écrire une fiche canonique",
    "Définir le générateur T_X",
    "Construire un toy model U3",
    "Écrire les équations minimales",
    "Coder une simulation ou calcul",
    "Chercher un contre-exemple",
    "Calculer PowerScore et SurvivalScore",
    "Produire un DCT",
    "Relier à Yggdrasil et aux ledgers",
    "Décider : promouvoir, tester, fusionner, archiver ou rejeter",
]

@dataclass(frozen=True)
class Crystal:
    id: str
    domain: str
    root: str
    function: str
    action: str
    status: str = "WildGarden"
    risk_class: str = "unknown"

    @property
    def name(self) -> str:
        return f"{self.domain} / {self.root} / {self.function} / {self.action}"

    def to_dict(self) -> Dict[str, Any]:
        data = asdict(self)
        data["name"] = self.name
        return data

def generate_crystals() -> List[Crystal]:
    crystals: List[Crystal] = []
    for i, (d, r, f, a) in enumerate(product(D10, R10, F10, A10), start=1):
        crystals.append(Crystal(id=f"C{i:05d}", domain=d, root=r, function=f, action=a))
    return crystals

def safe_positive(x: float, eps: float = 1e-9) -> float:
    return max(float(x), eps)

def power_score(
    fertility: float,
    verifiability: float,
    reuse: float,
    impact: float,
    compression: float,
    stability: float,
    complexity: float,
    noise: float,
    untested_speculation: float,
    risk: float,
) -> float:
    """Multiplicative TFUGA/AI-7 Power score.

    Higher is better. Inputs should be positive normalized scores.
    """
    numerator = (
        safe_positive(fertility) * safe_positive(verifiability) *
        safe_positive(reuse) * safe_positive(impact) *
        safe_positive(compression) * safe_positive(stability)
    )
    denominator = (
        safe_positive(complexity) * safe_positive(noise) *
        safe_positive(untested_speculation) * safe_positive(risk)
    )
    return numerator / denominator

def survival_score(
    compression: float,
    fertility: float,
    verification: float,
    transfer: float,
    prototype: float,
    impact: float,
    ambiguity: float,
    duplication: float,
    speculation: float,
    notation_load: float,
    risk: float,
) -> float:
    numerator = (
        safe_positive(compression) * safe_positive(fertility) *
        safe_positive(verification) * safe_positive(transfer) *
        safe_positive(prototype) * safe_positive(impact)
    )
    denominator = 1.0 + ambiguity + duplication + speculation + notation_load + risk
    return numerator / safe_positive(denominator)
