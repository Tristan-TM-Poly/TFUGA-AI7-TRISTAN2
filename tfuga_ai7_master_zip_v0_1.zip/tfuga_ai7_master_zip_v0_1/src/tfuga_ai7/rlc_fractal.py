from __future__ import annotations
import numpy as np
from dataclasses import dataclass
from typing import Dict, Any, Tuple

@dataclass
class RLCNetwork:
    levels: int
    R: np.ndarray
    L: np.ndarray
    C: np.ndarray
    M: np.ndarray
    coupling: np.ndarray
    metadata: Dict[str, Any]

def build_recursive_rlc_network(
    levels: int = 4,
    base_R: float = 1.0,
    base_L: float = 1e-3,
    base_C: float = 1e-6,
    scale_L: float = 0.55,
    scale_C: float = 0.70,
    bridge_R: float = 10.0,
    magnetic_coupling: float = 0.08,
) -> RLCNetwork:
    """Build a safe mathematical toy model of a recursive solenoid-like RLC network.

    This is NOT a build guide for hardware. It produces matrices for simulation,
    low-power education, filtering, signatures, and DCT-safe analysis.
    """
    if levels < 1:
        raise ValueError("levels must be >= 1")
    n = levels
    R = np.diag([base_R * (1.0 + 0.15*i) for i in range(n)])
    L_diag = np.array([base_L * (scale_L ** i) for i in range(n)])
    C_diag = np.array([base_C * (scale_C ** i) for i in range(n)])
    L = np.diag(L_diag)
    C = np.diag(C_diag)
    M = np.zeros((n, n), dtype=float)
    coupling = np.zeros((n, n), dtype=float)

    for i in range(n):
        for j in range(i + 1, n):
            distance = j - i
            k_ij = magnetic_coupling / (distance ** 1.35)
            M[i, j] = M[j, i] = k_ij * np.sqrt(L_diag[i] * L_diag[j])
            coupling[i, j] = coupling[j, i] = k_ij

    # Resistive bridges as off-diagonal conductance-like influence encoded in R metadata,
    # not directly inserted into diagonal R for this simple modal model.
    metadata = {
        "bridge_R": bridge_R,
        "description": "Recursive solenoid-inspired RLC toy model with mutual inductive couplings.",
        "safety": "Simulation-only, low-power conceptual model.",
    }
    return RLCNetwork(levels=n, R=R, L=L, C=C, M=M, coupling=coupling, metadata=metadata)

def effective_inductance_matrix(network: RLCNetwork) -> np.ndarray:
    return network.L + network.M

def resonant_frequencies(network: RLCNetwork) -> np.ndarray:
    """Return approximate modal resonance frequencies in Hz.

    Solves generalized eigenproblem inv(L_eff) inv(C) shape simplified:
    omega^2 eigenvalues of inv(L_eff) @ inv(C) for diagonal capacitance.
    """
    L_eff = effective_inductance_matrix(network)
    C = network.C
    inv_L = np.linalg.pinv(L_eff)
    inv_C = np.linalg.pinv(C)
    A = inv_L @ inv_C
    eigvals = np.linalg.eigvals(A)
    eigvals = np.real(eigvals)
    eigvals = eigvals[eigvals > 0]
    omega = np.sqrt(np.sort(eigvals))
    return omega / (2 * np.pi)

def impedance_matrix(network: RLCNetwork, freq_hz: float) -> np.ndarray:
    """Complex impedance matrix Z(jw) = R + jw L_eff + 1/(jw) C^{-1}."""
    if freq_hz <= 0:
        raise ValueError("freq_hz must be positive")
    w = 2 * np.pi * freq_hz
    j = 1j
    L_eff = effective_inductance_matrix(network)
    inv_C = np.linalg.pinv(network.C)
    return network.R + j * w * L_eff + (1 / (j * w)) * inv_C

def modal_summary(network: RLCNetwork) -> Dict[str, Any]:
    freqs = resonant_frequencies(network)
    return {
        "levels": network.levels,
        "min_frequency_hz": float(np.min(freqs)) if len(freqs) else None,
        "max_frequency_hz": float(np.max(freqs)) if len(freqs) else None,
        "frequencies_hz": [float(x) for x in freqs],
        "mean_coupling": float(np.mean(network.coupling)),
        "max_coupling": float(np.max(network.coupling)),
    }
