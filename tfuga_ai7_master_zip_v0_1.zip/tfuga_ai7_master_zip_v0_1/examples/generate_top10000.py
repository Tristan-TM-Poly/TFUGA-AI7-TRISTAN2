from pathlib import Path
import csv, json
from tfuga_ai7.core import generate_crystals

out = Path("outputs")
out.mkdir(exist_ok=True)

crystals = generate_crystals()

with (out / "top10000_index.csv").open("w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=["id", "name", "domain", "root", "function", "action", "status", "risk_class"])
    writer.writeheader()
    for c in crystals:
        writer.writerow(c.to_dict())

with (out / "top10000_index.jsonl").open("w", encoding="utf-8") as f:
    for c in crystals:
        f.write(json.dumps(c.to_dict(), ensure_ascii=False) + "\n")

print(f"Generated {len(crystals)} crystals in outputs/")
