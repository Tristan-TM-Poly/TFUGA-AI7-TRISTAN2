from pathlib import Path
import json
import numpy as np
from tfuga_ai7.rlc_fractal import build_recursive_rlc_network, modal_summary, impedance_matrix

out = Path("outputs")
out.mkdir(exist_ok=True)

net = build_recursive_rlc_network(levels=5)
summary = modal_summary(net)

with (out / "rlc_fractal_summary.json").open("w", encoding="utf-8") as f:
    json.dump(summary, f, indent=2)

# Save impedance magnitude at a few frequencies
freqs = np.geomspace(100, 200000, 50)
rows = []
for f_hz in freqs:
    Z = impedance_matrix(net, float(f_hz))
    rows.append({"freq_hz": float(f_hz), "impedance_fro_norm": float(np.linalg.norm(Z))})

with (out / "rlc_impedance_scan.csv").open("w", encoding="utf-8") as f:
    f.write("freq_hz,impedance_fro_norm\n")
    for row in rows:
        f.write(f"{row['freq_hz']},{row['impedance_fro_norm']}\n")

print("RLC toy model summary:")
print(json.dumps(summary, indent=2))
