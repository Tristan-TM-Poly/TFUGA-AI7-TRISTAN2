# SAFETY — Bornes d'usage

Ce master ZIP est conçu pour des usages pacifiques, éducatifs, scientifiques, énergétiques sûrs, écologiques et humanitaires.

## Règles du projet

- Pas de conception d'arme, ciblage, dommage ou amplification dangereuse.
- Prototypes électriques en basse puissance seulement avant revue experte.
- Les circuits résonants sont orientés vers mesure, filtrage, qualité de puissance, capteurs, pédagogie et simulation.
- Tout système énergétique réel exige : fusibles, isolation, BMS/EMS, arrêt manuel, tests, conformité locale, supervision qualifiée.
- L'IA ne désactive jamais les protections matérielles.
- Toute optimisation doit préserver ou améliorer la sécurité.

## SafetyGate

Deployment = 1 seulement si :

- ElectricalSafety = 1
- ThermalSafety = 1
- FireSafety = 1
- MechanicalSafety = 1
- CyberSafety = 1
- ManualOverride = 1
- Rollback = 1
