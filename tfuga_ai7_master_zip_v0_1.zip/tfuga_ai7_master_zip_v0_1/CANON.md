# CANON — TFUGA / AI-7 v0.1

## Phrase-canon

TFUGA-AI7 est un moteur de moindre action fractale-mycélienne : il génère beaucoup, relie proprement, teste localement, coupe le bruit, protège le vivant, compresse sans perdre, puis canonise seulement les trajectoires qui survivent au réel.

## Devise

Générer en forêt. Relier en mycélium. Tester en laboratoire. Canoniser en génome.

## Noyau compact

TFUGA-AI7 =
Hypergraphe de flux
+ Générateur profond
+ Fractalité protectrice
+ Mycélium sparse
+ DCT
+ CoherenceGate
+ CommonsGate
+ LedgerStack
+ Canon-génome
+ AI-Bots gouvernés

## Lois

1. No DCT, no strong canon.
2. Safety > Performance > Cost.
3. Generate != Prove.
4. Simulate != Deploy.
5. ClaimStrength <= ProofStatus.
6. No Ledger => No Learning.
7. No Rollback => No Deployment.
8. Fractal != Ingovernable.
9. AI advises; hardware protects.
10. OpenCore + ProtectedRoots.
11. Generate widely, canonize rarely.
12. A link must carry proof, function, prototype, or reuse.

## Promotion canonique

Un cristal peut monter si :

- DCT = true
- Safety = true
- Reconstructible = true
- CommonsGate = true
- Risk <= threshold
- PowerScore >= threshold
