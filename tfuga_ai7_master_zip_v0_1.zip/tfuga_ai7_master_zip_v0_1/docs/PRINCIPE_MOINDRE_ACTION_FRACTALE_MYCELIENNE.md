# Principe de moindre action fractale-mycélienne

## Idée

Une trajectoire d'idée, de théorie, de circuit, de document, d'énergie ou de prototype doit minimiser les pertes destructrices et maximiser l'ordre fertile vérifiable.

## Champ

Psi vit sur un hypergraphe fractal-mycélien avec :

- noeuds
- hyperarêtes
- échelles
- temps/itérations
- états
- flux
- contraintes
- invariants

## Action conceptuelle

S_FM[Psi] = integral(
  generation
+ coherence_fractale
+ recouplage_mycelien
+ preuve
+ prototype
+ reutilisation
+ impact
+ commons
- risque
- bruit
- complexite
- dommage
) dt

## Condition

delta S_FM[Psi] = 0

Puis promotion seulement si :

DCT = 1
Safety = 1
Reconstructible = 1
CommonsGate = 1

## Forme décisionnelle

BestTrajectory = argmax(Fertilite + Preuve + Prototype + Reuse + Impact)
                 under constraints(Risk, Noise, Complexity, Harm, Safety)

## Lecture TFUGA

- Hypergraphe : le monde des relations.
- Fractal : les échelles.
- Mycélium : les ponts transversaux.
- Action : la sélection dynamique.
- DCT : le contact avec le réel.
- Canon : la compression fertile.
