# Roadmap 25 itérations

Chaque itération doit produire : Document + Calcul/Code + Test + prochaine action.

1. OnePageCanon v0.2.
2. HMS-Atlas v0.1 avec 100 familles scorées.
3. DCT-Template v0.1.
4. U3-DomainGenerator v0.1.
5. OmniFlux-MVU v0.1.
6. Circuit RLC-k-T fractal-mycélien toy model.
7. Trace/Zeta/Det module Python.
8. Math-AI7 BestRep module.
9. PowerScore + SurvivalScore engine.
10. Bot-Frein + AntiBullshit engine.
11. LedgerStack templates.
12. OmegaPlaza dashboard schema.
13. OmegaEnergyPlaza dashboard schema.
14. MVU-AI7-Energy simulation safe low-power.
15. Forest-U3-HFM-AI7 toy simulator.
16. Water-Separation-MVU toy model.
17. Raman calibration mini-pipeline.
18. TC-nPCI-kE taxonomy and parameter schema.
19. FFWT-HFM Lossless MiniDemo.
20. VirtualCompute-AI7 scheduler.
21. Auto-AI7 workflow miner.
22. Doc-AI7 document generator extraction.
23. GitHub-AI7 repo skeleton with README/CANON/SCORECARD.
24. Report GOLIATH v0.1.
25. ZIP export package v0.1.
