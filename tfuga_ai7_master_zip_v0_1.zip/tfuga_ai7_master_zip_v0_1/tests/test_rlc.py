import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

import numpy as np
from tfuga_ai7.rlc_fractal import build_recursive_rlc_network, resonant_frequencies, impedance_matrix

def test_rlc_shapes():
    net = build_recursive_rlc_network(levels=4)
    assert net.R.shape == (4,4)
    assert net.L.shape == (4,4)
    assert net.C.shape == (4,4)
    assert net.M.shape == (4,4)

def test_resonances_positive():
    net = build_recursive_rlc_network(levels=4)
    freqs = resonant_frequencies(net)
    assert len(freqs) == 4
    assert np.all(freqs > 0)

def test_impedance_complex():
    net = build_recursive_rlc_network(levels=4)
    Z = impedance_matrix(net, 1000)
    assert Z.shape == (4,4)
    assert np.iscomplexobj(Z)

if __name__ == "__main__":
    test_rlc_shapes()
    test_resonances_positive()
    test_impedance_complex()
    print("test_rlc OK")
