import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from tfuga_ai7.core import generate_crystals, power_score, survival_score

def test_generate_top10000():
    crystals = generate_crystals()
    assert len(crystals) == 10000
    assert crystals[0].id == "C00001"
    assert crystals[-1].id == "C10000"

def test_scores_positive():
    p = power_score(2, 2, 2, 2, 2, 2, 1, 1, 1, 1)
    assert p == 64
    s = survival_score(2, 2, 2, 2, 2, 2, 0, 0, 0, 0, 0)
    assert s == 64

if __name__ == "__main__":
    test_generate_top10000()
    test_scores_positive()
    print("test_core OK")
