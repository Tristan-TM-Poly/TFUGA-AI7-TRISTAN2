H = 6.62607015e-34
C = 299792458.0
KB = 1.380649e-23
EV = 1.602176634e-19
WIEN_B = 2.897771955e-3

def lambda_gap_m(bandgap_eV):
    return H*C/(bandgap_eV*EV)

def wien_peak_m(T):
    return WIEN_B/T
