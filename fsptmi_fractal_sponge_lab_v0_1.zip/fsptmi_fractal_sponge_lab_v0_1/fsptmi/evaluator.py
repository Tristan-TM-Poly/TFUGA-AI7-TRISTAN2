from dataclasses import asdict
from .fractals import metrics_for
from .physics_scores import spectral_match_score, pv_light_trapping_score, laser_score, battery_score, thermal_transport_score, ionic_transport_score
from .delta_phi import geometric_power

def evaluate_design(geometry, dimension, generation, config):
    m = metrics_for(geometry, dimension, generation)
    T = float(config.get('temperature_K', 1200))
    Eg = float(config.get('bandgap_eV', 0.72))
    weights = config.get('weights', {})
    scores = {
        'tpv': spectral_match_score(T, Eg, m.surface_to_volume_proxy, m.porosity),
        'pv': pv_light_trapping_score(m.surface_to_volume_proxy, m.manufacturability, m.stability_proxy),
        'laser': laser_score(m.fractal_dimension, m.surface_to_volume_proxy, m.stability_proxy, m.manufacturability),
        'battery': battery_score(m.surface_to_volume_proxy, m.porosity, m.tortuosity_proxy, m.stability_proxy, m.manufacturability),
        'thermal_transport': thermal_transport_score(m.porosity, m.tortuosity_proxy, m.stability_proxy),
        'ionic_transport': ionic_transport_score(m.porosity, m.tortuosity_proxy, m.manufacturability),
        'manufacturability': m.manufacturability,
        'stability': m.stability_proxy,
    }
    power = geometric_power(scores, weights)
    risk = max(0.0, 1.0-m.manufacturability)*0.45 + max(0.0, 1.0-m.stability_proxy)*0.55
    return {
        'id': f'{geometry}_{dimension}D_g{generation}',
        'geometry': geometry,
        'dimension': dimension,
        'generation': generation,
        'metrics': asdict(m),
        'scores': scores,
        'power': power,
        'risk': risk,
        'status': 'promote_candidate' if power > 0.50 and risk < 0.45 else 'explore',
        'recommended_use': recommend(scores),
    }

def recommend(scores):
    top = sorted(scores.items(), key=lambda kv: kv[1], reverse=True)[0][0]
    mapping = {
        'tpv': 'thermophotovoltaic selective emitter',
        'pv': 'photovoltaic light trapping / radiative cooling texture',
        'laser': 'fractal photonic laser cavity or directional emitter',
        'battery': '3D electrode / electrolyte wetting architecture',
        'thermal_transport': 'thermal radiator / anisotropic heat transport',
        'ionic_transport': 'membrane / ion transport scaffold',
        'manufacturability': 'fabrication reference geometry',
        'stability': 'high-stability structural scaffold',
    }
    return mapping.get(top, top)
