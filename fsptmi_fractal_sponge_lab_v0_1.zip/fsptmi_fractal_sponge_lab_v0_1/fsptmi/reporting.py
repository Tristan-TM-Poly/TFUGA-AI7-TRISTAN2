import json, csv, hashlib, time
from pathlib import Path

def write_outputs(results, base_dir):
    reports = base_dir / 'reports'
    generated = base_dir / 'generated'
    reports.mkdir(exist_ok=True)
    generated.mkdir(exist_ok=True)
    results_sorted = sorted(results, key=lambda r: r['power'], reverse=True)
    summary = {
        'version':'0.1',
        'generated_at': time.strftime('%Y-%m-%d %H:%M:%S UTC', time.gmtime()),
        'design_count': len(results_sorted),
        'top_designs': results_sorted[:10],
        'promote_candidates': [r for r in results_sorted if r['status']=='promote_candidate'],
    }
    (reports/'fsptmi_summary.json').write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding='utf-8')
    (generated/'design_candidates.json').write_text(json.dumps(results_sorted, indent=2, ensure_ascii=False), encoding='utf-8')
    with (reports/'fsptmi_summary.csv').open('w', newline='', encoding='utf-8') as f:
        w=csv.writer(f)
        w.writerow(['rank','id','geometry','dimension','generation','power','risk','status','recommended_use','tpv','pv','laser','battery','thermal_transport','ionic_transport','manufacturability','stability','fractal_dimension','porosity','surface_to_volume_proxy'])
        for idx,r in enumerate(results_sorted,1):
            s=r['scores']; m=r['metrics']
            w.writerow([idx,r['id'],r['geometry'],r['dimension'],r['generation'],f"{r['power']:.6f}",f"{r['risk']:.6f}",r['status'],r['recommended_use'],f"{s['tpv']:.4f}",f"{s['pv']:.4f}",f"{s['laser']:.4f}",f"{s['battery']:.4f}",f"{s['thermal_transport']:.4f}",f"{s['ionic_transport']:.4f}",f"{s['manufacturability']:.4f}",f"{s['stability']:.4f}",f"{m['fractal_dimension']:.4f}",f"{m['porosity']:.4f}",f"{m['surface_to_volume_proxy']:.4f}"])
    md=[]
    md.append('# FSPTMI v0.1 Report\n')
    md.append('Fractal sponge candidates ranked by normalized geometric Power score.\n')
    md.append('## Top 10 Designs\n')
    for idx,r in enumerate(results_sorted[:10],1):
        md.append(f"### {idx}. {r['id']}\n")
        md.append(f"- Power: `{r['power']:.6f}`\n- Risk: `{r['risk']:.6f}`\n- Status: `{r['status']}`\n- Recommended use: **{r['recommended_use']}**\n")
        md.append(f"- Scores: {json.dumps(r['scores'], ensure_ascii=False)}\n")
        md.append(f"- Key metrics: fractal_dimension={r['metrics']['fractal_dimension']:.4f}, porosity={r['metrics']['porosity']:.4f}, surface_to_volume_proxy={r['metrics']['surface_to_volume_proxy']:.4f}\n")
    md.append('\n## Canonical Next Experiments\n')
    md.append('1. Simulate emissivity epsilon(lambda,theta) for the top TPV candidate with FDTD/FEM.\n')
    md.append('2. Build a test surface and compare against a flat control.\n')
    md.append('3. Measure temperature, spectral emission, power conversion, impedance, and degradation.\n')
    md.append('4. Re-rank using measured scores instead of heuristic scores.\n')
    (reports/'FSPTMI_REPORT.md').write_text('\n'.join(md), encoding='utf-8')
    ledger=[]
    for p in list(reports.glob('*'))+list(generated.glob('*')):
        if p.is_file():
            ledger.append({'path':str(p.relative_to(base_dir)), 'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
    (reports/'artifact_ledger.json').write_text(json.dumps(ledger, indent=2), encoding='utf-8')
