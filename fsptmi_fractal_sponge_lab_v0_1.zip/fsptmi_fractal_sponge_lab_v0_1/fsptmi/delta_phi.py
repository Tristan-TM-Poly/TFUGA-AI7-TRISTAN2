import math

def geometric_power(scores, weights, eps=1e-9):
    total_w = sum(max(0.0, w) for w in weights.values())
    if total_w <= 0:
        raise ValueError('positive total weight required')
    logp = 0.0
    for k, w in weights.items():
        wk = max(0.0, w) / total_w
        sk = max(float(scores.get(k, eps)), eps)
        logp += wk * math.log(sk)
    return math.exp(logp)

def delta_phi(old_scores, new_scores, weights, eps=1e-9):
    total_w = sum(max(0.0, w) for w in weights.values())
    if total_w <= 0:
        raise ValueError('positive total weight required')
    value = 0.0
    for k, w in weights.items():
        wk = max(0.0, w) / total_w
        old = max(float(old_scores.get(k, eps)), eps)
        new = max(float(new_scores.get(k, eps)), eps)
        value += wk * math.log(new / old)
    return value
