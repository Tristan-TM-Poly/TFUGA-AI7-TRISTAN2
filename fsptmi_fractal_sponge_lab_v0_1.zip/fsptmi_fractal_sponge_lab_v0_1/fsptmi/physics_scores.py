import math
from .constants import H, C, KB, EV, lambda_gap_m, wien_peak_m

def clamp01(x):
    return max(0.0, min(1.0, x))

def spectral_match_score(T, bandgap_eV, surface_to_volume, porosity):
    peak = wien_peak_m(T)
    lgap = lambda_gap_m(bandgap_eV)
    ratio = peak / lgap
    match = math.exp(-abs(math.log(max(ratio, 1e-12))) ** 2 / 0.7)
    resonance_bonus = clamp01(math.log1p(surface_to_volume) / 10.0)
    porosity_bonus = clamp01(1.0 - abs(porosity - 0.55) / 0.55)
    return clamp01(0.55*match + 0.25*resonance_bonus + 0.20*porosity_bonus)

def pv_light_trapping_score(surface_to_volume, manufacturability, stability):
    trap = clamp01(math.log1p(surface_to_volume) / 9.0)
    return clamp01(0.50*trap + 0.25*manufacturability + 0.25*stability)

def laser_score(fractal_dimension, surface_to_volume, stability, manufacturability):
    target_df = 2.65
    df_match = math.exp(-((fractal_dimension - target_df) ** 2) / 0.35)
    confinement = clamp01(math.log1p(surface_to_volume) / 8.0)
    return clamp01(0.35*df_match + 0.25*confinement + 0.25*stability + 0.15*manufacturability)

def battery_score(surface_to_volume, porosity, tortuosity, stability, manufacturability):
    active = clamp01(math.log1p(surface_to_volume) / 9.0)
    porosity_match = clamp01(1.0 - abs(porosity - 0.45) / 0.45)
    tort = 1.0 / (1.0 + max(0.0, tortuosity - 1.0))
    return clamp01(0.28*active + 0.24*porosity_match + 0.20*tort + 0.16*stability + 0.12*manufacturability)

def thermal_transport_score(porosity, tortuosity, stability):
    flow = clamp01(porosity * 1.2)
    tort = 1.0 / (1.0 + 0.4 * max(0.0, tortuosity - 1.0))
    return clamp01(0.45*flow + 0.25*tort + 0.30*stability)

def ionic_transport_score(porosity, tortuosity, manufacturability):
    pore = clamp01(1.0 - abs(porosity - 0.50) / 0.50)
    tort = 1.0 / (1.0 + max(0.0, tortuosity - 1.0))
    return clamp01(0.50*pore + 0.35*tort + 0.15*manufacturability)
