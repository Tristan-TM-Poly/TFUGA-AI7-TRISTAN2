from dataclasses import dataclass
import math

@dataclass
class FractalMetrics:
    geometry: str
    dimension: int
    generation: int
    kept_ratio: float
    cells_total: int
    cells_kept: int
    porosity: float
    fractal_dimension: float
    surface_proxy: float
    volume_proxy: float
    surface_to_volume_proxy: float
    tortuosity_proxy: float
    manufacturability: float
    stability_proxy: float

KEEP_RULES = {
    'cubic': {
        2: lambda coords: not (coords[0] == 1 and coords[1] == 1),
        3: lambda coords: sum(1 for c in coords if c == 1) <= 1,
        4: lambda coords: sum(1 for c in coords if c == 1) <= 1,
    },
    'triangular': {
        2: lambda coords: not (coords[0] == 1 and coords[1] == 1),
        3: lambda coords: sum(coords) % 3 != 0 or coords == (0,0,0),
        4: lambda coords: sum(coords) % 3 != 0 or coords == (0,0,0,0),
    },
    'hexagonal': {
        2: lambda coords: coords != (1,1),
        3: lambda coords: sum(1 for c in coords if c == 1) <= 2,
        4: lambda coords: sum(1 for c in coords if c == 1) <= 2,
    },
    'pentagonal': {
        2: lambda coords: (coords[0] + 2*coords[1]) % 5 != 0,
        3: lambda coords: (coords[0] + 2*coords[1] + 3*coords[2]) % 5 != 0,
        4: lambda coords: (coords[0] + 2*coords[1] + 3*coords[2] + coords[3]) % 5 != 0,
    },
}

def count_kept(geometry, dimension):
    rule = KEEP_RULES[geometry][dimension]
    kept = 0
    def rec(prefix):
        nonlocal kept
        if len(prefix) == dimension:
            if rule(tuple(prefix)):
                kept += 1
            return
        for v in (0,1,2):
            rec(prefix+[v])
    rec([])
    return kept

def metrics_for(geometry, dimension, generation):
    total_per_gen = 3 ** dimension
    kept_per_gen = count_kept(geometry, dimension)
    kept_ratio = kept_per_gen / total_per_gen
    cells_total = total_per_gen ** generation
    cells_kept = kept_per_gen ** generation
    porosity = 1.0 - kept_ratio ** generation
    fractal_dimension = math.log(kept_per_gen) / math.log(3)
    length_scale = 3 ** (-generation)
    volume_proxy = kept_ratio ** generation
    surface_proxy = cells_kept * (length_scale ** max(dimension - 1, 1))
    surface_to_volume_proxy = surface_proxy / max(volume_proxy, 1e-12)
    geom_factor = {'cubic':1.00,'triangular':1.12,'hexagonal':0.92,'pentagonal':1.28}[geometry]
    tortuosity_proxy = geom_factor * (1.0 + porosity) * (1.0 + 0.08 * generation)
    manufacturability = {'cubic':0.92,'triangular':0.82,'hexagonal':0.86,'pentagonal':0.62}[geometry] / (1.0 + 0.08*generation + 0.05*max(0, dimension-3))
    stability_proxy = {'cubic':0.86,'triangular':0.78,'hexagonal':0.90,'pentagonal':0.70}[geometry] / (1.0 + 0.04*generation)
    return FractalMetrics(geometry, dimension, generation, kept_ratio, cells_total, cells_kept, porosity, fractal_dimension, surface_proxy, volume_proxy, surface_to_volume_proxy, tortuosity_proxy, manufacturability, stability_proxy)
