#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/.."
python3 -S fsptmi_cli.py run
python3 -S tests/test_smoke.py
