# Canon FSPTMI v0.1

Definition:

`FSPTMI_{g,d,n} = (S_{g,d,n}, epsilon, LDOS, kappa, sigma, D_i, A_eff, tau, phi, I(X;Y), T_energy)`

Fractal sponges are modeled as physical operators acting on photons, phonons, electrons, ions, matter, and information.

Promotion rule:

`Promote(Y)=1 iff DeltaPhi(Y)>0 and UnitCheck=1 and TestPlan=1 and Risk < theta_R.`
