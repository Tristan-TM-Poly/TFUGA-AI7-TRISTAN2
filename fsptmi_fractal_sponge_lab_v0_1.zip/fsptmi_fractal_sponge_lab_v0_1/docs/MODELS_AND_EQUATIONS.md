# Models and Equations

## Blackbody / TPV

`B_lambda(T) proportional to lambda^{-5} / (exp(hc/(lambda k_B T))-1)`

Useful TPV proxy:

`P_useful = int_{lambda < lambda_g} epsilon(lambda) B_lambda(T) dlambda`

`lambda_g = hc/E_g`

## Laser

`P_th proportional to V_mode/(Q Gamma)`

Desired: Q up, V_mode down, confinement up, thermal loss down.

## Battery

Desired: active surface up, ionic diffusivity up, electronic conductivity up, charge-transfer resistance down, tortuosity down.

## Delta-Phi

`DeltaPhi_n = sum_i p_i ln(s_i(Y_{n+1})/s_i(Y_n))`
