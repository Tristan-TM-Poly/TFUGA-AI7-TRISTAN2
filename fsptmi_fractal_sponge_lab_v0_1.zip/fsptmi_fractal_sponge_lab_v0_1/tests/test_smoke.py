import json
from pathlib import Path
from fsptmi.evaluator import evaluate_design

def test_one_design():
    config=json.loads(Path('configs/default_config.json').read_text())
    result=evaluate_design('cubic',3,1,config)
    assert result['power'] > 0
    assert 0 <= result['risk'] <= 1
    assert result['metrics']['cells_kept'] > 0

if __name__ == '__main__':
    test_one_design()
    print('smoke test passed')
