# FSPTMI Fractal Sponge Lab v0.1

FSPTMI = Fractal Sponge Photonic-Thermal-Material-Information Systems.

Executable research scaffold for fractal sponge geometries used as physical operators for lasers, batteries, photovoltaic/thermophotovoltaic systems, energy transport, matter transformation, and information transformation.

Run:

```bash
python3 -S fsptmi_cli.py run
```

Outputs:
- `reports/fsptmi_summary.json`
- `reports/fsptmi_summary.csv`
- `reports/FSPTMI_REPORT.md`
- `generated/design_candidates.json`

Core law:

`Delta Phi_n = sum_i p_i ln(s_i(Y_{n+1}) / s_i(Y_n))`

All scores are positive and dimensionless. This package is a measurable scaffold, not a final physical validation.
