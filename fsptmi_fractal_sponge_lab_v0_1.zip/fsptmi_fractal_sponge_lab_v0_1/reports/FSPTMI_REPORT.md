# FSPTMI v0.1 Report

Fractal sponge candidates ranked by normalized geometric Power score.

## Top 10 Designs

### 1. cubic_3D_g2

- Power: `0.693295`
- Risk: `0.205140`
- Status: `promote_candidate`
- Recommended use: **high-stability structural scaffold**

- Scores: {"tpv": 0.6887940777775596, "pv": 0.5252713301982643, "laser": 0.7341415670337197, "battery": 0.6523200818719506, "thermal_transport": 0.6789166732895997, "ionic_transport": 0.7781674402555387, "manufacturability": 0.7931034482758622, "stability": 0.7962962962962963}

- Key metrics: fractal_dimension=2.7268, porosity=0.4513, surface_to_volume_proxy=9.0000

### 2. cubic_3D_g3

- Power: `0.685200`
- Risk: `0.243808`
- Status: `promote_candidate`
- Recommended use: **high-stability structural scaffold**

- Scores: {"tpv": 0.7345850913508951, "pv": 0.562570629469539, "laser": 0.7515321908001082, "battery": 0.5802077474556544, "thermal_transport": 0.7306821680029266, "ionic_transport": 0.6948568795101979, "manufacturability": 0.7419354838709677, "stability": 0.7678571428571428}

- Key metrics: fractal_dimension=2.7268, porosity=0.5936, surface_to_volume_proxy=27.0000

### 3. triangular_3D_g2

- Power: `0.659004`
- Risk: `0.284674`
- Status: `promote_candidate`
- Recommended use: **membrane / ion transport scaffold**

- Scores: {"tpv": 0.7082478750091347, "pv": 0.4852010875418148, "laser": 0.7076383486983646, "battery": 0.5850916940123564, "thermal_transport": 0.670154541724687, "ionic_transport": 0.7802580765289203, "manufacturability": 0.7068965517241379, "stability": 0.7222222222222222}

- Key metrics: fractal_dimension=2.6801, porosity=0.5048, surface_to_volume_proxy=9.0000

### 4. cubic_3D_g1

- Power: `0.641354`
- Risk: `0.161859`
- Status: `promote_candidate`
- Recommended use: **fabrication reference geometry**

- Scores: {"tpv": 0.5960526655724878, "pv": 0.4967100855892817, "laser": 0.7219764373557458, "battery": 0.5629895008991057, "thermal_transport": 0.6066083916083916, "ionic_transport": 0.6443899782135076, "manufacturability": 0.8518518518518519, "stability": 0.8269230769230769}

- Key metrics: fractal_dimension=2.7268, porosity=0.2593, surface_to_volume_proxy=3.0000

### 5. triangular_3D_g3

- Power: `0.635536`
- Risk: `0.319384`
- Status: `promote_candidate`
- Recommended use: **fractal photonic laser cavity or directional emitter**

- Scores: {"tpv": 0.7135055256897108, "pv": 0.5245521962898154, "laser": 0.7265246084153392, "battery": 0.5141687208020549, "thermal_transport": 0.7255023990653411, "ionic_transport": 0.6002627055059342, "manufacturability": 0.6612903225806451, "stability": 0.6964285714285714}

- Key metrics: fractal_dimension=2.6801, porosity=0.6515, surface_to_volume_proxy=27.0000

### 6. cubic_4D_g1

- Power: `0.624490`
- Risk: `0.178821`
- Status: `promote_candidate`
- Recommended use: **high-stability structural scaffold**

- Scores: {"tpv": 0.6499247194445416, "pv": 0.4872869456351682, "laser": 0.41169740997727033, "battery": 0.6219988632391528, "thermal_transport": 0.675030565461029, "ionic_transport": 0.759794459107454, "manufacturability": 0.8141592920353982, "stability": 0.8269230769230769}

- Key metrics: fractal_dimension=3.5237, porosity=0.4074, surface_to_volume_proxy=3.0000

### 7. hexagonal_2D_g3

- Power: `0.618113`
- Risk: `0.245939`
- Status: `promote_candidate`
- Recommended use: **high-stability structural scaffold**

- Scores: {"tpv": 0.6586672480805142, "pv": 0.559402426704562, "laser": 0.477072206941621, "battery": 0.6093225816588207, "thermal_transport": 0.6115169932894495, "ionic_transport": 0.6381261272392872, "manufacturability": 0.6935483870967741, "stability": 0.8035714285714285}

- Key metrics: fractal_dimension=1.8928, porosity=0.2977, surface_to_volume_proxy=27.0000

### 8. cubic_2D_g3

- Power: `0.614600`
- Risk: `0.243808`
- Status: `promote_candidate`
- Recommended use: **high-stability structural scaffold**

- Scores: {"tpv": 0.6586672480805142, "pv": 0.562570629469539, "laser": 0.4754017000291786, "battery": 0.5986067095795643, "thermal_transport": 0.5921201466066989, "ionic_transport": 0.626470125294137, "manufacturability": 0.7419354838709677, "stability": 0.7678571428571428}

- Key metrics: fractal_dimension=1.8928, porosity=0.2977, surface_to_volume_proxy=27.0000

### 9. triangular_3D_g1

- Power: `0.612761`
- Risk: `0.245833`
- Status: `promote_candidate`
- Recommended use: **fabrication reference geometry**

- Scores: {"tpv": 0.6095206790405012, "pv": 0.4543311682103643, "laser": 0.69380311390201, "battery": 0.5398159807788068, "thermal_transport": 0.5887157757496739, "ionic_transport": 0.6333994708994708, "manufacturability": 0.7592592592592592, "stability": 0.75}

- Key metrics: fractal_dimension=2.6801, porosity=0.2963, surface_to_volume_proxy=3.0000

### 10. cubic_4D_g2

- Power: `0.612544`
- Risk: `0.219888`
- Status: `promote_candidate`
- Recommended use: **high-stability structural scaffold**

- Scores: {"tpv": 0.6887441962461966, "pv": 0.517078112757398, "laser": 0.4246004931631923, "battery": 0.5288053480664763, "thermal_transport": 0.7724015283944861, "ionic_transport": 0.6482079939882138, "manufacturability": 0.7603305785123967, "stability": 0.7962962962962963}

- Key metrics: fractal_dimension=3.5237, porosity=0.6488, surface_to_volume_proxy=9.0000


## Canonical Next Experiments

1. Simulate emissivity epsilon(lambda,theta) for the top TPV candidate with FDTD/FEM.

2. Build a test surface and compare against a flat control.

3. Measure temperature, spectral emission, power conversion, impedance, and degradation.

4. Re-rank using measured scores instead of heuristic scores.
