# Validation

## CLI
Exit code: `0`

```text
[FSPTMI] run complete
[FSPTMI] designs evaluated: 36
[FSPTMI] top design: cubic_3D_g2 power=0.693295 use=high-stability structural scaffold

```

## Smoke Test
Exit code: `1`

```text

Traceback (most recent call last):
  File [35m"/mnt/data/fsptmi_fractal_sponge_lab_v0_1/tests/test_smoke.py"[0m, line [35m3[0m, in [35m<module>[0m
    from fsptmi.evaluator import evaluate_design
[1;35mModuleNotFoundError[0m: [35mNo module named 'fsptmi'[0m
```
