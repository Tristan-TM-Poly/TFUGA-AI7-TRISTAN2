#!/usr/bin/env python3
import json
from pathlib import Path
from fsptmi.evaluator import evaluate_design
from fsptmi.reporting import write_outputs

def run():
    config = json.loads(Path('configs/default_config.json').read_text(encoding='utf-8'))
    results=[]
    for geometry in config['geometries']:
        for dimension in config['dimensions']:
            for generation in config['generations']:
                results.append(evaluate_design(geometry, dimension, generation, config))
    write_outputs(results, Path('.'))
    top=max(results, key=lambda r: r['power'])
    print('[FSPTMI] run complete')
    print(f"[FSPTMI] designs evaluated: {len(results)}")
    print(f"[FSPTMI] top design: {top['id']} power={top['power']:.6f} use={top['recommended_use']}")

if __name__ == '__main__':
    run()
