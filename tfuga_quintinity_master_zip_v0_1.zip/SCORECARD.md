# SCORECARD.md — TFUGA / AI-7 Quintinity Scoring

## Power score

\[
Power(X)=\frac{Fertility\cdot Verifiability\cdot Reuse\cdot Impact\cdot Compression\cdot Stability}{Complexity\cdot Noise\cdot UntestedSpeculation\cdot Risk}
\]

This implementation uses a normalized heuristic score in `[0,1]`, designed for triage, not final truth.

## Gates

The engine currently uses 12 heuristic gates, grouped as `(4 + 4 + 4)`:

### Trajectory gates

1. Idea present
2. Theory present
3. System or application present
4. Feedback present

### DCT gates

5. Documentable
6. Calculable/codeable
7. Testable
8. Verifiable

### Scale gates

9. Micro/toy route
10. Meso/system route
11. Macro/application route
12. Safety/scale-up route

## Status thresholds

- `CoreCanon`: score >= 0.82 and verification/safety gates pass
- `CrystalGarden`: score >= 0.62
- `WildGarden`: score >= 0.35
- `Archive`: score < 0.35

## Important warning

A high heuristic score is not a proof. It only means: this trajectory is worth turning into a DCT.
