# CANON.md — Quintinity Genome Engine v0.1

## Canonical alphabet

\[
\mathcal{Q}=\{1,I,T,S,A\}
\]

- `1`: preserve the trunk, keep invariants, stabilize, remember, archive, protect.
- `I`: generate ideas, intuitions, hypotheses, seeds.
- `T`: formalize theories, definitions, equations, proofs, models.
- `S`: build systems, modules, interfaces, flows, architectures, orchestrators.
- `A`: apply, prototype, test, deploy, measure impact.

## Core trajectories

### ITSA
Idea -> Theory -> System -> Application.

Queen descent. Best minimal route for engineering and real-world impact.

### ITSAT
Idea -> Theory -> System -> Application -> Corrected Theory.

Full research loop. Best general genome for fractal LC circuits and major technical projects.

### 1ITSA
Preserve trunk -> Idea -> Theory -> System -> Application.

Canon-safe descent. Best for Yggdrasil growth.

### AITSA
Application/need -> Idea -> Theory -> System -> Application.

Humanitarian and field-first route. Best for water, climate, recycling, energy access.

### TSASA
Theory -> System -> Application -> Improved System -> Improved Application.

AI-7 industrialization route.

## Contraction law

\[
97,656 \rightarrow 625 \rightarrow 120 \rightarrow 24 \rightarrow 16 \rightarrow 5 \rightarrow 1
\]

Generate many, test locally, canonize little.

## Core rule

No CoreCanon promotion without:

\[
DCT=1,\quad Safety=1,\quad Score\geq\theta
\]

## Project signature

\[
\Sigma(P)=(w,q,Power,Status,NextAction)
\]

where:

- `w` is the project genome in \(\mathcal{Q}^{\le 7}\)
- `q` is a maturity gate vector
- `Power` is the scored value
- `Status` is WildGarden, CrystalGarden, CoreCanon, or Archive
- `NextAction` is the next concrete action
