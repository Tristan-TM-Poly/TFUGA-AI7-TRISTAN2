# TFUGA / AI-7 Quintinity Master ZIP v0.1

This archive crystallizes the current **Quintinity Genome Engine**:

\[
\mathcal{Q}=\{1,I,T,S,A\}
\]

where:

- `1` = identity, invariant, stabilization, memory, protected trunk
- `I` = idea, intuition, hypothesis, exploratory seed
- `T` = theory, model, equation, proof, invariant
- `S` = system, architecture, orchestration, network, modules
- `A` = application, prototype, experiment, deployment, impact

The central language is:

\[
\mathcal{Q}^n=\{1,I,T,S,A\}^n, \qquad |\mathcal{Q}^n|=5^n
\]

and the total tree up to depth 7 is:

\[
|\mathcal{Q}^{\le 7}|=\frac{5^8-1}{4}=97,656
\]

The canonical contraction is:

\[
97,656 \rightarrow 625 \rightarrow 120 \rightarrow 24 \rightarrow 16 \rightarrow 5 \rightarrow 1
\]

## Contents

- `src/quintinity_engine.py` — generator, scorer, gates, status classifier, exporters.
- `tests/test_quintinity_engine.py` — sanity tests.
- `data/generated/` — generated rankings and summaries.
- `docs/MASTER_REPORT.md` — explanation and next actions.
- `CANON.md` — compact canonical definitions.
- `SCORECARD.md` — scoring and gates.
- `LEDGER.md` — iteration ledger.
- `examples/projects.json` — example project genomes.
- `run_all.sh` — regenerate outputs and run tests.

## Quick start

```bash
bash run_all.sh
```

or directly:

```bash
python3 src/quintinity_engine.py --out data/generated --max-depth 7
python3 -m unittest discover -s tests
```

## Current top project genomes

- Fractal LC circuit: `ITSAT`
- AI-7 orchestrator: `TSASA`
- Water separation: `AITSA`
- Yggdrasil canon: `1ITSA`
- SourceHub hypergraphizer: `ASTA`

## Status

Version: `v0.1`

Canonical status: `CrystalGarden -> CoreCanon candidate after real DCT use on one project`.
