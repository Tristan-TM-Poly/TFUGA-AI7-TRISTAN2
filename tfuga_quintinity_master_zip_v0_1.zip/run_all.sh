#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
python3 src/quintinity_engine.py --out data/generated --max-depth 7 > data/generated/run_summary_stdout.json
python3 -m unittest discover -s tests
printf '\n[OK] Quintinity Genome Engine outputs regenerated and tests passed.\n'
