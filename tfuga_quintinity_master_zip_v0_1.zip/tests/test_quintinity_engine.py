#!/usr/bin/env python3
import unittest

from src.quintinity_engine import (
    SYMBOLS,
    ACTIVE_SYMBOLS,
    analyze_word,
    gate_vector_12,
    generate_words,
    u120,
    u24,
    u625,
)

class TestQuintinityEngine(unittest.TestCase):
    def test_counts(self):
        self.assertEqual(len(SYMBOLS), 5)
        self.assertEqual(len(ACTIVE_SYMBOLS), 4)
        self.assertEqual(len(list(generate_words(4))), 625)
        self.assertEqual(len(u625()), 625)
        self.assertEqual(len(u120()), 120)
        self.assertEqual(len(u24()), 24)

    def test_canonical_words_score_well(self):
        itsat = analyze_word("ITSAT")
        iiii = analyze_word("IIII")
        self.assertGreater(itsat.power, iiii.power)
        self.assertIn(itsat.status, {"CrystalGarden", "CoreCanon"})

    def test_gate_vector(self):
        gates = gate_vector_12("ITSAT")
        self.assertEqual(len(gates), 12)
        self.assertTrue(set(gates).issubset({"0", "1"}))

    def test_next_action_missing_symbol(self):
        analysis = analyze_word("IIII")
        self.assertIn("Add missing", analysis.next_action)

if __name__ == "__main__":
    unittest.main()
