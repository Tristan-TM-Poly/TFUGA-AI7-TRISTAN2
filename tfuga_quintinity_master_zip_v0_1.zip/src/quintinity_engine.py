#!/usr/bin/env python3
"""
TFUGA / AI-7 Quintinity Genome Engine v0.1

Core alphabet:
    Q = {1, I, T, S, A}

Meanings:
    1 = identity / invariant / stabilization / memory
    I = idea / intuition / hypothesis
    T = theory / model / equation / proof
    S = system / architecture / orchestration / network
    A = application / prototype / experiment / real impact

Mission:
    Generate, score, filter, and contract project trajectories:
        Q^<=7 -> U625 -> U120 -> U24 -> Top16 -> Top5 -> Top1

No external dependency required.
"""

from __future__ import annotations

import argparse
import csv
import itertools
import json
import math
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

SYMBOLS: Tuple[str, ...] = ("1", "I", "T", "S", "A")
ACTIVE_SYMBOLS: Tuple[str, ...] = ("I", "T", "S", "A")

MEANINGS: Dict[str, str] = {
    "1": "identity / invariant / stabilization / memory / protected trunk",
    "I": "idea / intuition / hypothesis / exploratory seed",
    "T": "theory / model / equation / proof / invariant",
    "S": "system / architecture / orchestration / network / modules",
    "A": "application / prototype / experiment / deployment / impact",
}

STATUS_THRESHOLDS = {
    "CoreCanon": 0.82,
    "CrystalGarden": 0.62,
    "WildGarden": 0.35,
}

CANONICAL_PATTERNS = {
    "ITSA": "queen descent: idea -> theory -> system -> application",
    "ITSAT": "full research loop: idea -> theory -> system -> application -> corrected theory",
    "1ITSA": "protected descent: preserve trunk -> idea -> theory -> system -> application",
    "AITSA": "humanitarian / field-first route: application need -> idea -> theory -> system -> application",
    "TSASA": "AI-7 industrialization route: theory -> system -> application -> improved system -> improved application",
    "ASTA": "reverse engineering route: application -> system -> theory -> improved application",
    "ATSA": "experimental engineering route: application -> theory -> system -> improved application",
    "TSAT": "systemic scientific loop: theory -> system -> application -> corrected theory",
}

@dataclass(frozen=True)
class WordAnalysis:
    word: str
    length: int
    counts: Dict[str, int]
    active_coverage: float
    identity_ratio: float
    balance: float
    dct_readiness: float
    safety_readiness: float
    system_readiness: float
    feedback_score: float
    pattern_bonus: float
    risk_penalty: float
    noise_penalty: float
    power: float
    gates_12: str
    status: str
    next_action: str
    interpretation: str


def generate_words(length: int, symbols: Sequence[str] = SYMBOLS) -> Iterable[str]:
    for tup in itertools.product(symbols, repeat=length):
        yield "".join(tup)


def generate_words_up_to(max_depth: int, symbols: Sequence[str] = SYMBOLS) -> Iterable[str]:
    # Include the empty root as "ROOT" for reporting clarity.
    yield "ROOT"
    for length in range(1, max_depth + 1):
        yield from generate_words(length, symbols)


def balanced_score(counts: Dict[str, int], active_symbols: Sequence[str] = ACTIVE_SYMBOLS) -> float:
    n = sum(counts.get(s, 0) for s in active_symbols)
    if n == 0:
        return 0.0
    target = n / len(active_symbols)
    # Max L1 deviation from equal distribution for k categories with n mass is 2n(1-1/k).
    max_dev = 2 * n * (1 - 1 / len(active_symbols))
    dev = sum(abs(counts.get(s, 0) - target) for s in active_symbols)
    return max(0.0, 1.0 - dev / max_dev)


def contains_subsequence(word: str, subsequence: str) -> bool:
    if word == "ROOT":
        return False
    it = iter(word)
    return all(ch in it for ch in subsequence)


def gate_vector_12(word: str) -> str:
    """
    12 gates = 3 groups of 4.
    Trajectory gates: idea, theory, system/application, feedback.
    DCT gates: documentable, calculable/codeable, testable, verifiable.
    Scale gates: micro, meso, macro, safety/scale-up.
    This is a heuristic maturity proxy, not a proof.
    """
    if word == "ROOT":
        return "000000000000"
    has_i = "I" in word
    has_t = "T" in word
    has_s = "S" in word
    has_a = "A" in word
    has_1 = "1" in word

    feedback = ("A" in word and word.rfind("T") > word.find("A")) or word.endswith("T")
    documentable = has_i or has_t or has_1
    calculable = has_t or has_s
    testable = has_a or has_s
    verifiable = has_t and (has_a or has_s)

    micro = has_t or has_i
    meso = has_s
    macro = has_a and has_s
    safety = has_1 or has_s or len(word) <= 5

    bits = [
        has_i,
        has_t,
        has_s or has_a,
        feedback,
        documentable,
        calculable,
        testable,
        verifiable,
        micro,
        meso,
        macro,
        safety,
    ]
    return "".join("1" if b else "0" for b in bits)


def interpret_word(word: str) -> str:
    if word == "ROOT":
        return "root / undifferentiated seed"
    return " -> ".join(MEANINGS[ch].split(" / ")[0] for ch in word)


def next_action_for(word: str, gates: str, power: float) -> str:
    if word == "ROOT":
        return "Choose an initial seed: I, A, or 1I depending on context."
    missing = [s for s in ACTIVE_SYMBOLS if s not in word]
    if missing:
        return f"Add missing active pole(s): {', '.join(missing)}. Aim for ITSA or AITSA."
    if "S" not in word:
        return "Insert S: design architecture/modules/interfaces before claiming application maturity."
    if "A" not in word:
        return "Create a minimal application/prototype/test."
    if not gates[7] == "1":
        return "Strengthen DCT: add verification, limits, and reproducible test."
    if not gates[11] == "1":
        return "Run SafetyGate and scale-up review."
    if power >= STATUS_THRESHOLDS["CoreCanon"]:
        return "Promote candidate carefully, with CANON.md entry and regression tests."
    return "Improve score: reduce noise/risk or add clearer proof/test/impact."


def analyze_word(word: str) -> WordAnalysis:
    if word == "ROOT":
        counts = {s: 0 for s in SYMBOLS}
        return WordAnalysis(
            word=word,
            length=0,
            counts=counts,
            active_coverage=0.0,
            identity_ratio=0.0,
            balance=0.0,
            dct_readiness=0.0,
            safety_readiness=0.0,
            system_readiness=0.0,
            feedback_score=0.0,
            pattern_bonus=0.0,
            risk_penalty=0.0,
            noise_penalty=0.0,
            power=0.0,
            gates_12="000000000000",
            status="WildGarden",
            next_action="Choose an initial seed.",
            interpretation=interpret_word(word),
        )

    counts = {s: word.count(s) for s in SYMBOLS}
    length = len(word)
    active_coverage = sum(1 for s in ACTIVE_SYMBOLS if counts[s] > 0) / len(ACTIVE_SYMBOLS)
    identity_ratio = counts["1"] / length
    balance = balanced_score(counts)

    has_i, has_t, has_s, has_a = (counts[s] > 0 for s in ACTIVE_SYMBOLS)
    dct_readiness = (0.25 * has_i + 0.25 * has_t + 0.25 * has_s + 0.25 * has_a)
    system_readiness = 1.0 if has_s else 0.45 if has_t and has_a else 0.2
    safety_readiness = 1.0 if counts["1"] > 0 or has_s else 0.65 if length <= 4 else 0.45
    feedback_score = 1.0 if ("A" in word and word.rfind("T") > word.find("A")) else 0.75 if word.endswith("T") else 0.4

    pattern_bonus = 0.0
    for pattern in CANONICAL_PATTERNS:
        if pattern in word or contains_subsequence(word, pattern):
            pattern_bonus += 0.035
    pattern_bonus = min(pattern_bonus, 0.16)

    max_repeat = max(counts.values())
    repetition_ratio = max_repeat / length
    noise_penalty = max(0.0, repetition_ratio - 0.45) * 0.35
    risk_penalty = 0.0
    if not has_t:
        risk_penalty += 0.18
    if not has_s and has_a:
        risk_penalty += 0.10
    if not has_a and length >= 4:
        risk_penalty += 0.08
    if identity_ratio > 0.45:
        risk_penalty += 0.10

    base = (
        0.20 * active_coverage
        + 0.15 * balance
        + 0.18 * dct_readiness
        + 0.14 * system_readiness
        + 0.12 * safety_readiness
        + 0.10 * feedback_score
        + 0.11 * (1.0 - min(1.0, identity_ratio))
    )
    power = max(0.0, min(1.0, base + pattern_bonus - risk_penalty - noise_penalty))

    gates = gate_vector_12(word)
    if power >= STATUS_THRESHOLDS["CoreCanon"] and gates[7] == "1" and gates[11] == "1":
        status = "CoreCanon"
    elif power >= STATUS_THRESHOLDS["CrystalGarden"]:
        status = "CrystalGarden"
    elif power >= STATUS_THRESHOLDS["WildGarden"]:
        status = "WildGarden"
    else:
        status = "Archive"

    return WordAnalysis(
        word=word,
        length=length,
        counts=counts,
        active_coverage=round(active_coverage, 6),
        identity_ratio=round(identity_ratio, 6),
        balance=round(balance, 6),
        dct_readiness=round(float(dct_readiness), 6),
        safety_readiness=round(float(safety_readiness), 6),
        system_readiness=round(float(system_readiness), 6),
        feedback_score=round(float(feedback_score), 6),
        pattern_bonus=round(pattern_bonus, 6),
        risk_penalty=round(risk_penalty, 6),
        noise_penalty=round(noise_penalty, 6),
        power=round(power, 6),
        gates_12=gates,
        status=status,
        next_action=next_action_for(word, gates, power),
        interpretation=interpret_word(word),
    )


def u625() -> List[str]:
    return list(generate_words(4, SYMBOLS))


def u120() -> List[str]:
    return ["".join(p) for p in itertools.permutations(SYMBOLS, 5)]


def u24() -> List[str]:
    return ["".join(p) for p in itertools.permutations(ACTIVE_SYMBOLS, 4)]


def rank_words(words: Iterable[str], limit: int | None = None) -> List[WordAnalysis]:
    analyses = [analyze_word(w) for w in words]
    analyses.sort(key=lambda a: (a.power, a.active_coverage, a.balance, -a.length), reverse=True)
    if limit is not None:
        return analyses[:limit]
    return analyses


def write_csv(path: Path, rows: Sequence[WordAnalysis]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = list(asdict(rows[0]).keys()) if rows else ["word"]
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            d = asdict(row)
            d["counts"] = json.dumps(d["counts"], ensure_ascii=False)
            writer.writerow(d)


def write_json(path: Path, obj: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)


def project_examples() -> List[Dict[str, object]]:
    projects = {
        "Fractal LC circuit": "ITSAT",
        "AI-7 orchestrator": "TSASA",
        "Water separation": "AITSA",
        "Yggdrasil canon": "1ITSA",
        "SourceHub hypergraphizer": "ASTA",
    }
    result = []
    for name, word in projects.items():
        analysis = analyze_word(word)
        result.append({"project": name, **asdict(analysis)})
    return result


def generate_outputs(out_dir: Path, max_depth: int = 7) -> Dict[str, object]:
    out_dir.mkdir(parents=True, exist_ok=True)
    all_count = sum(5 ** k for k in range(0, max_depth + 1))
    if max_depth <= 7:
        words_up_to = list(generate_words_up_to(max_depth))
        top_all = rank_words(words_up_to, limit=200)
    else:
        top_all = []

    u625_ranked = rank_words(u625())
    u120_ranked = rank_words(u120())
    u24_ranked = rank_words(u24())
    top16 = top_all[:16] if top_all else rank_words(u625(), limit=16)
    top5 = top_all[:5] if top_all else rank_words(u625(), limit=5)
    top1 = top_all[0] if top_all else rank_words(u625(), limit=1)[0]

    write_csv(out_dir / "u625_ranked.csv", u625_ranked)
    write_csv(out_dir / "u120_ranked.csv", u120_ranked)
    write_csv(out_dir / "u24_ranked.csv", u24_ranked)
    write_csv(out_dir / "top200_all_leq7.csv", top_all)
    write_json(out_dir / "top16.json", [asdict(x) for x in top16])
    write_json(out_dir / "top5.json", [asdict(x) for x in top5])
    write_json(out_dir / "top1.json", asdict(top1))
    write_json(out_dir / "project_examples.json", project_examples())

    summary = {
        "alphabet": SYMBOLS,
        "active_symbols": ACTIVE_SYMBOLS,
        "max_depth": max_depth,
        "count_Q_leq_max_depth": all_count,
        "count_Q_depth_7": 5 ** 7,
        "count_Q_leq_7": sum(5 ** k for k in range(0, 8)),
        "count_U625": len(u625_ranked),
        "count_U120": len(u120_ranked),
        "count_U24": len(u24_ranked),
        "contraction": "97656 -> 625 -> 120 -> 24 -> 16 -> 5 -> 1",
        "canonical_top1": asdict(top1),
        "recommended_project_genomes": project_examples(),
    }
    write_json(out_dir / "summary.json", summary)
    return summary


def main() -> None:
    parser = argparse.ArgumentParser(description="TFUGA / AI-7 Quintinity Genome Engine")
    parser.add_argument("--out", default="data/generated", help="Output directory")
    parser.add_argument("--max-depth", type=int, default=7, help="Maximum depth for Q^<=n")
    args = parser.parse_args()
    summary = generate_outputs(Path(args.out), max_depth=args.max_depth)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
