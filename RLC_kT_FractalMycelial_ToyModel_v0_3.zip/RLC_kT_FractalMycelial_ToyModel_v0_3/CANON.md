# CANON v0.3

## Stable trunk

- Low-power lumped RLC matrix model.
- SafetyGate before promotion.
- DCT before canonization.
- Graph/hypergraph representation of topologies.
- Modal analysis and Pareto comparison as selection tools.

## CrystalGarden v0.3

- Impedance import and model-data comparison.
- TC-2PCI compensation proxy.
- Monte Carlo uncertainty propagation.
- Omega RLC dashboard.
- DOT graph export.

## WildGarden

- 3D EM field solving.
- Real hardware design.
- High-power scaling.
- Autonomous deployment.

These remain explicitly out of scope for v0.3.

## Promotion status

RLC-kT-HFM v0.3 is L5 CrystalCandidate: simulated, scored, documented, multi-topology, uncertainty-aware, and dashboarded. It is not yet L6 because no physical low-power prototype has been tested.
