import fs from 'node:fs';
import { generateRecursiveSolenoid } from './src/recursive_solenoid.js';
import { buildRlcHypergraph } from './src/rlc_hypergraph.js';
import { assembleMatrices, validateMatrices } from './src/matrices.js';
import { solveUndampedModes } from './src/mode_solver.js';
import { runSafetyGate } from './src/safety_gate.js';
import { scoreModes, powerScore } from './src/powerscore.js';
import { ensureDir, writeJson, writeCsv } from './src/exporters.js';
import { makeDctReport } from './src/dct_report.js';

const config = JSON.parse(fs.readFileSync('configs/toy_config.json', 'utf8'));
ensureDir('outputs');
ensureDir('reports');
ensureDir('ledger');

const solenoid = generateRecursiveSolenoid(config);
const hypergraph = buildRlcHypergraph(solenoid);
const matrices = assembleMatrices(solenoid);
validateMatrices(matrices.M, matrices.R, matrices.K);
const rawModes = solveUndampedModes(matrices.M, matrices.R, matrices.K);
const safety = runSafetyGate(config, solenoid);
const modes = scoreModes(rawModes, safety);
const power = powerScore({ risk: safety.pass ? 0.25 : 1.0 });

writeJson('outputs/solenoid.json', solenoid);
writeJson('outputs/hypergraph.json', hypergraph);
writeJson('outputs/matrices.json', matrices);
writeJson('outputs/safety_gate.json', safety);
writeJson('outputs/scorecard.json', { power, top_modes: modes.slice(0, 3), status: safety.pass ? 'simulation_safe_candidate' : 'blocked_review' });
writeCsv('outputs/modes.csv', modes);
fs.writeFileSync('reports/DCT_RLC_kT_HFM_v0_1.md', makeDctReport({ config, solenoid, matrices, modes, safety, power }), 'utf8');

const runCard = {
  id: 'TEST-RLC-HFM-0001',
  timestamp: new Date().toISOString(),
  module: 'RLC-kT-HFM',
  test_type: 'toy_simulation',
  inputs: config,
  measurements: { modes: modes.length, safety_pass: safety.pass, power },
  pass_fail: safety.pass ? 'pass' : 'blocked_review',
  notes: 'Local lumped simulation. No hardware deployment.'
};
writeJson('ledger/test_card_0001.json', runCard);
console.log(JSON.stringify({ ok: true, modes: modes.length, safety_pass: safety.pass, power }, null, 2));
process.exit(0);
