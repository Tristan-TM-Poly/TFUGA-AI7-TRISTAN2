import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { loadTopology, topologyToSolenoid } from './src/topology_loader.js';
import { assembleMatrices, validateMatrices } from './src/matrices.js';
import { solveUndampedModes } from './src/mode_solver.js';
import { runSafetyGate } from './src/safety_gate.js';
import { scoreModes, powerScore } from './src/powerscore.js';
import { writeCsv, writeJson, ensureDir } from './src/exporters.js';
import { frequencyResponse, peakResponse } from './src/frequency_response.js';
import { estimateThermal } from './src/thermal_model.js';
import { auditUnits } from './src/unit_audit.js';
import { paretoFront } from './src/pareto_optimizer.js';
import { modalScaleSignature } from './src/ffwt_modal_cluster.js';
import { impedanceResponse, writeSyntheticMeasuredCsv, loadMeasuredCsv, compareImpedance } from './src/impedance_analysis.js';
import { estimateCompensation } from './src/tc2pci_compensation.js';
import { monteCarloModes } from './src/uncertainty.js';
import { writeDot } from './src/dot_exporter.js';
import { writeDashboard } from './src/html_dashboard.js';

const __filename = fileURLToPath(import.meta.url);
const root = path.dirname(__filename);
const outDir = path.join(root, 'outputs', 'v0_3');
const dataDir = path.join(root, 'data', 'impedance');
const graphDir = path.join(root, 'graphs');
const dashDir = path.join(root, 'dashboards');
ensureDir(outDir); ensureDir(dataDir); ensureDir(graphDir); ensureDir(dashDir);

const topologyPaths = fs.readdirSync(path.join(root, 'topologies'))
  .filter(f => f.endsWith('.json'))
  .map(f => path.join(root, 'topologies', f));

const summaries = [];
for (const topoPath of topologyPaths) {
  const topo = loadTopology(topoPath);
  const solenoid = topologyToSolenoid(topo);
  const { M, R, K } = assembleMatrices(solenoid);
  validateMatrices(M, R, K);
  const unitAudit = auditUnits(solenoid);
  const safetyConfig = {
    safety: {
      V_est: 5,
      V_max: topo.safety?.vMax ?? 12,
      I_est: 0.02,
      I_max: topo.safety?.iMax ?? 0.05,
      E_max_J: topo.safety?.eMax ?? 0.01,
      T_est_C: 28,
      T_max_C: topo.safety?.tMax ?? 45,
      rollback_available: topo.safety?.rollbackDefined === true,
      unknowns: 1,
      thermal_risk: 0.05,
      coupling_risk: 0.1
    }
  };
  const safety = runSafetyGate(safetyConfig, solenoid);
  const modes = scoreModes(solveUndampedModes(M, R, K), safety);
  const response = frequencyResponse(M, R, K, { fMin: 4e4, fMax: 3e5, points: 96, inputNode: 0, outputNode: topo.nodes - 1 });
  const peak = peakResponse(response);
  const impedance = impedanceResponse(M, R, K, { fMin: 4e4, fMax: 3e5, points: 96, inputNode: 0 });
  const measuredPath = path.join(dataDir, `${topo.name}_synthetic_impedance.csv`);
  writeSyntheticMeasuredCsv(measuredPath, impedance, 0.025);
  const measured = loadMeasuredCsv(measuredPath);
  const fit = compareImpedance(impedance, measured);
  const avgR = topo.branches.reduce((s, b) => s + b.R, 0) / topo.branches.length;
  const thermal = estimateThermal({ currentRms: 0.02, resistance: avgR, duration_s: 120, cth_J_per_K: 25, cooling_W_per_K: 0.2, ambient_C: 25 });
  const signature = modalScaleSignature(modes);
  const bestMode = modes.reduce((a, b) => b.mode_score > a.mode_score ? b : a, modes[0]);
  const compensation = estimateCompensation({ freq_Hz: bestMode.freq_Hz, cBridge_F: (topo.capacitive_bridges || []).reduce((s, x) => s + x.C, 0), lLeak_H: avg(M.map((row, i) => row[i])) * 0.025, conductance_S: 1 / Math.max(avgR, 1e-12) });
  const uncertainty = monteCarloModes(solenoid, safety, { samples: 32, relativeUncertainty: 0.04, seed: topo.nodes * 100 + topo.name.length });
  const pScore = powerScore({
    fertility: 0.82,
    verifiability: unitAudit.pass && safety.pass ? 0.92 : 0.5,
    reusability: 0.93,
    impact: 0.78,
    compression: 0.82,
    stability: safety.pass ? 0.88 : 0.4,
    complexity: 0.35 + topo.nodes / 30,
    noise: 0.15 + fit.rmse_rel_mag,
    speculation: 0.24,
    risk: safety.pass ? 0.18 : 0.8
  });
  const summary = {
    topology: topo.name,
    nodes: topo.nodes,
    safety_pass: safety.pass,
    unit_audit_pass: unitAudit.pass,
    best_mode_freq_Hz: bestMode.freq_Hz,
    best_mode_Q: bestMode.Q_approx,
    best_mode_score: bestMode.mode_score,
    peak_response_freq_Hz: peak.freq_Hz,
    peak_response_dB: peak.magnitude_dB,
    estimated_temp_C: thermal.estimatedTemp_C,
    modal_mean_ratio: signature.mean_ratio,
    modal_ratio_spread: signature.ratio_spread,
    impedance_rmse_rel_mag: fit.rmse_rel_mag,
    impedance_rmse_phase_rad: fit.rmse_phase_rad,
    uncertainty_freq_rel_sd: uncertainty.best_freq_Hz.sd / uncertainty.best_freq_Hz.mean,
    tc2pci_recommendation: compensation.recommendation,
    power_score: pScore
  };
  summaries.push(summary);
  const base = topo.name;
  writeJson(path.join(outDir, `${base}_matrices.json`), { M, R, K });
  writeCsv(path.join(outDir, `${base}_modes.csv`), modes);
  writeCsv(path.join(outDir, `${base}_bode.csv`), response);
  writeCsv(path.join(outDir, `${base}_impedance_model.csv`), impedance);
  writeJson(path.join(outDir, `${base}_impedance_fit.json`), fit);
  writeJson(path.join(outDir, `${base}_safety.json`), safety);
  writeJson(path.join(outDir, `${base}_thermal.json`), thermal);
  writeJson(path.join(outDir, `${base}_modal_signature.json`), signature);
  writeJson(path.join(outDir, `${base}_unit_audit.json`), unitAudit);
  writeJson(path.join(outDir, `${base}_uncertainty.json`), uncertainty);
  writeJson(path.join(outDir, `${base}_tc2pci_compensation.json`), compensation);
  writeDot(path.join(graphDir, `${base}.dot`), topo);
}

const front = paretoFront(summaries, [
  { key: 'best_mode_score', direction: 'max' },
  { key: 'power_score', direction: 'max' },
  { key: 'estimated_temp_C', direction: 'min' },
  { key: 'impedance_rmse_rel_mag', direction: 'min' },
  { key: 'uncertainty_freq_rel_sd', direction: 'min' }
]);
writeJson(path.join(outDir, 'topology_summary.json'), summaries);
writeJson(path.join(outDir, 'pareto_front.json'), front);
writeCsv(path.join(outDir, 'topology_summary.csv'), summaries);

const dctPath = path.join(root, 'reports', 'DCT_RLC_kT_HFM_v0_3.md');
const dct = `# DCT RLC-kT-HFM v0.3\n\n## Hypothesis\nA recursive/fractal-mycelial RLC topology can be promoted from modal toy model to reusable engineering pre-prototype when it includes topology comparison, frequency response, impedance-data import, uncertainty, TC-2PCI compensation proxy, graph export, dashboard and SafetyGate.\n\n## Equation core\nM q'' + R q' + K q = u(t)\n\nFrequency domain: (-omega^2 M + i omega R + K) qhat = uhat.\n\n## Tested topologies\n${summaries.map(s => `- ${s.topology}: nodes=${s.nodes}, safety=${s.safety_pass}, best f=${s.best_mode_freq_Hz.toFixed(2)} Hz, Q=${s.best_mode_Q.toFixed(2)}, Power=${s.power_score.toFixed(3)}, impedance RMSE=${s.impedance_rmse_rel_mag.toFixed(5)}, uncertainty freq rel SD=${s.uncertainty_freq_rel_sd.toFixed(5)}`).join('\n')}\n\n## Pareto front\n${front.map(s => `- ${s.topology}: modeScore=${s.best_mode_score.toFixed(4)}, Power=${s.power_score.toFixed(3)}, T=${s.estimated_temp_C.toFixed(3)} C, fit=${s.impedance_rmse_rel_mag.toFixed(5)}`).join('\n')}\n\n## v0.3 additions\n1. Impedance response proxy and synthetic measured CSV import.\n2. Impedance model-data comparison.\n3. TC-2PCI compensation proxy.\n4. Monte Carlo uncertainty on L, C, R.\n5. DOT graph export.\n6. Omega RLC HTML dashboard.\n\n## Limits\nThis remains a lumped low-power toy model. It is not a 3D EM solver, not a high-voltage design, not a medical/safety-certified system, and not a deployment plan. Real hardware requires certified electrical, thermal, fire, insulation, mechanical and cyber-safety review.\n\n## Next actions v0.4\n1. Add arbitrary incidence-matrix components between arbitrary pairs.\n2. Add measured laboratory impedance import from real CSV.\n3. Add full damped state-space solver.\n4. Add SVG rendering from DOT.\n5. Add optimization-generated topologies.\n6. Add uncertainty bands on Bode/impedance plots.\n7. Add unit-aware parser.\n8. Add TC-nPCI-kE family generator.\n9. Add Omega RLC interactive controls.\n10. Add formal promotion score L5 -> L6.\n`;
fs.writeFileSync(dctPath, dct, 'utf8');
writeDashboard(path.join(dashDir, 'omega_rlc_dashboard_v0_3.html'), { summaries, pareto: front, dctPath: 'reports/DCT_RLC_kT_HFM_v0_3.md' });
writeJson(path.join(outDir, 'run_log.json'), { ok: true, version: '0.3.0', topologies: summaries.length, pareto: front.map(x => x.topology), generated_at: new Date().toISOString() });
console.log(JSON.stringify({ ok: true, version: '0.3.0', topologies: summaries.length, pareto: front.map(x => x.topology) }, null, 2));
process.exit(0);

function avg(xs) { return xs.reduce((a, b) => a + b, 0) / xs.length; }
