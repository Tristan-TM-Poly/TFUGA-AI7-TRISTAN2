# RLC-kT Fractal-Mycelial Toy Model v0.3

AI-assisted architecture, code, documentation, and crystallization support by ChatGPT, OpenAI. Project author and owner: Tristan Tardif-Morency.

## Mission

This project is a low-power analytical/numerical toy model for recursive solenoid and RLC-kT fractal-mycelial circuit families. It represents circuit candidates as typed topologies, builds coupled RLC matrices, solves modal spectra, evaluates frequency and impedance response, runs SafetyGate, estimates thermal proxy, computes PowerScore, compares Pareto candidates, exports DOT graphs, and generates a DCT report.

It is not a high-voltage design, not a weaponizable system, not a deployment plan, and not a certified hardware design.

## Core equation

M q'' + R q' + K q = u(t)

Frequency domain:

(-omega^2 M + i omega R + K) qhat = uhat

## v0.3 additions

- Impedance response proxy.
- Synthetic measured impedance CSV generation and comparison.
- TC-2PCI compensation proxy.
- Monte Carlo uncertainty over L, C and R.
- DOT graph export.
- Omega RLC HTML dashboard.
- Expanded Pareto selection.
- DCT v0.3.

## Run

```bash
npm run test:v03
npm run run:v03
```

Outputs are written to:

```text
outputs/v0_3/
data/impedance/
graphs/
dashboards/
reports/DCT_RLC_kT_HFM_v0_3.md
```

## Safety invariant

AI may optimize; hardware protection and certified human review must dominate before any physical test.
