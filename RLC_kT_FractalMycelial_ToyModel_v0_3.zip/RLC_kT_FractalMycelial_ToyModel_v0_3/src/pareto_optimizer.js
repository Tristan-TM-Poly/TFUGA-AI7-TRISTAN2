export function paretoFront(items, objectives) {
  return items.filter(a => !items.some(b => dominates(b, a, objectives)));
}

function dominates(a, b, objectives) {
  let better = false;
  for (const obj of objectives) {
    const av = a[obj.key];
    const bv = b[obj.key];
    if (obj.direction === 'max') {
      if (av < bv) return false;
      if (av > bv) better = true;
    } else {
      if (av > bv) return false;
      if (av < bv) better = true;
    }
  }
  return better;
}
