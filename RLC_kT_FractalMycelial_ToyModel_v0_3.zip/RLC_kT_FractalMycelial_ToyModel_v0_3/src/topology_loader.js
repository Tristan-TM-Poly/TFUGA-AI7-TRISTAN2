import fs from 'fs';

export function loadTopology(path) {
  const topo = JSON.parse(fs.readFileSync(path, 'utf8'));
  validateTopology(topo);
  return topo;
}

export function validateTopology(topo) {
  if (!topo.name) throw new Error('Topology missing name');
  if (!Number.isInteger(topo.nodes) || topo.nodes <= 0) throw new Error('Topology nodes must be positive integer');
  if (!Array.isArray(topo.branches) || topo.branches.length !== topo.nodes) throw new Error('Topology must have one branch per node in v0.2');
  for (const b of topo.branches) {
    if (!(b.L > 0)) throw new Error(`Branch ${b.id} L must be positive`);
    if (!(b.C > 0)) throw new Error(`Branch ${b.id} C must be positive`);
    if (!(b.R >= 0)) throw new Error(`Branch ${b.id} R must be nonnegative`);
  }
  for (const m of topo.mutuals || []) {
    if (m.i === m.j) throw new Error('Mutual self-coupling is not allowed');
    if (m.i < 0 || m.i >= topo.nodes || m.j < 0 || m.j >= topo.nodes) throw new Error('Mutual index out of range');
    if (!(Math.abs(m.k) < 0.98)) throw new Error('Mutual k must satisfy |k| < 0.98 for positive-definite safety margin');
  }
  for (const c of topo.capacitive_bridges || []) {
    if (!(c.C > 0)) throw new Error('Capacitive bridge C must be positive');
  }
  return true;
}

export function topologyToSolenoid(topo) {
  const levels = topo.branches.map((b, idx) => ({
    id: b.id ?? `b${idx}`,
    level: idx,
    L_H: b.L,
    C_F: b.C,
    R_ohm: b.R
  }));
  const couplings = (topo.mutuals || []).map(m => {
    const from = levels[m.i].id;
    const to = levels[m.j].id;
    const M_H = m.k * Math.sqrt(levels[m.i].L_H * levels[m.j].L_H);
    return { from, to, k: m.k, M_H, type: 'magnetic_mutual' };
  });
  return { levels, couplings, name: topo.name, safety: topo.safety || {} };
}
