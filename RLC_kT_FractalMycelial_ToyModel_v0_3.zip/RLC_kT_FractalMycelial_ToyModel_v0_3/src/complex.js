export function c(re, im = 0) { return { re, im }; }
export function add(a, b) { return c(a.re + b.re, a.im + b.im); }
export function sub(a, b) { return c(a.re - b.re, a.im - b.im); }
export function mul(a, b) { return c(a.re * b.re - a.im * b.im, a.re * b.im + a.im * b.re); }
export function div(a, b) {
  const d = b.re * b.re + b.im * b.im;
  if (d === 0) throw new Error('Complex division by zero');
  return c((a.re * b.re + a.im * b.im) / d, (a.im * b.re - a.re * b.im) / d);
}
export function abs(a) { return Math.hypot(a.re, a.im); }
export function phase(a) { return Math.atan2(a.im, a.re); }
