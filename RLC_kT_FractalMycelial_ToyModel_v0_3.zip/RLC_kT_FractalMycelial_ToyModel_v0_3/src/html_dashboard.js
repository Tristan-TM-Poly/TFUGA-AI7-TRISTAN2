import fs from 'fs';

export function writeDashboard(filePath, { summaries, pareto, dctPath }) {
  const rows = summaries.map(s => `<tr><td>${s.topology}</td><td>${s.nodes}</td><td>${s.safety_pass}</td><td>${fmt(s.best_mode_freq_Hz)}</td><td>${fmt(s.best_mode_Q)}</td><td>${fmt(s.power_score)}</td><td>${fmt(s.impedance_rmse_rel_mag)}</td><td>${fmt(s.uncertainty_freq_rel_sd)}</td></tr>`).join('\n');
  const p = pareto.map(x => `<li>${x.topology} | Power=${fmt(x.power_score)} | f=${fmt(x.best_mode_freq_Hz)} Hz</li>`).join('\n');
  const html = `<!doctype html><html><head><meta charset="utf-8"><title>Omega RLC v0.3</title><style>body{font-family:Arial,sans-serif;margin:2rem;line-height:1.45}table{border-collapse:collapse;width:100%}td,th{border:1px solid #ccc;padding:.45rem}code{background:#f3f3f3;padding:.1rem .25rem}.card{border:1px solid #ddd;border-radius:12px;padding:1rem;margin:1rem 0}</style></head><body><h1>Omega RLC Dashboard v0.3</h1><div class="card"><p><strong>Mission:</strong> comparer des topologies RLC-kT fractales-mycéliennes basse puissance avec modes, SafetyGate, réponse fréquentielle, incertitude, compensation TC-2PCI proxy et DCT.</p><p><strong>DCT:</strong> ${dctPath}</p></div><h2>Pareto front</h2><ul>${p}</ul><h2>Topologies</h2><table><thead><tr><th>Topology</th><th>N</th><th>Safety</th><th>Best f Hz</th><th>Q</th><th>Power</th><th>Impedance RMSE</th><th>Freq rel SD</th></tr></thead><tbody>${rows}</tbody></table><h2>Safety note</h2><p>This is a low-power lumped toy model. It is not a high-voltage design or deployment plan.</p></body></html>`;
  fs.writeFileSync(filePath, html, 'utf8');
}
function fmt(x) { return typeof x === 'number' && Number.isFinite(x) ? x.toFixed(4) : String(x); }
