export function modalScaleSignature(modes) {
  const freqs = modes.map(m => m.freq_Hz).filter(f => f > 0).sort((a, b) => a - b);
  const ratios = [];
  for (let i = 1; i < freqs.length; i++) ratios.push(freqs[i] / freqs[i - 1]);
  const meanRatio = ratios.length ? ratios.reduce((a, b) => a + b, 0) / ratios.length : 1;
  const spread = ratios.length ? Math.sqrt(ratios.reduce((s, r) => s + (r - meanRatio) ** 2, 0) / ratios.length) : 0;
  return { freqs_Hz: freqs, adjacent_ratios: ratios, mean_ratio: meanRatio, ratio_spread: spread, interpretation: spread < 0.08 ? 'near self-similar modal ladder' : 'heterogeneous modal ladder' };
}
