import { zeros } from './linear_algebra.js';

function clone(A) { return A.map(r => r.slice()); }

function solveComplex(Are, Aim, bre, bim) {
  const n = Are.length;
  const N = 2 * n;
  const A = zeros(N, N);
  const b = Array(N).fill(0);
  for (let i = 0; i < n; i++) {
    b[i] = bre[i];
    b[i + n] = bim[i];
    for (let j = 0; j < n; j++) {
      A[i][j] = Are[i][j];
      A[i][j + n] = -Aim[i][j];
      A[i + n][j] = Aim[i][j];
      A[i + n][j + n] = Are[i][j];
    }
  }
  const x = gaussian(A, b);
  return { re: x.slice(0, n), im: x.slice(n) };
}

function gaussian(Ain, bin) {
  const A = clone(Ain), b = bin.slice();
  const n = b.length;
  for (let k = 0; k < n; k++) {
    let pivot = k;
    for (let i = k + 1; i < n; i++) if (Math.abs(A[i][k]) > Math.abs(A[pivot][k])) pivot = i;
    if (Math.abs(A[pivot][k]) < 1e-18) throw new Error('Singular complex response matrix');
    [A[k], A[pivot]] = [A[pivot], A[k]];
    [b[k], b[pivot]] = [b[pivot], b[k]];
    const div = A[k][k];
    for (let j = k; j < n; j++) A[k][j] /= div;
    b[k] /= div;
    for (let i = 0; i < n; i++) {
      if (i === k) continue;
      const f = A[i][k];
      for (let j = k; j < n; j++) A[i][j] -= f * A[k][j];
      b[i] -= f * b[k];
    }
  }
  return b;
}

export function frequencyResponse(M, R, K, opts = {}) {
  const n = M.length;
  const fMin = opts.fMin ?? 5e4;
  const fMax = opts.fMax ?? 3e5;
  const points = opts.points ?? 160;
  const inputNode = opts.inputNode ?? 0;
  const outputNode = opts.outputNode ?? n - 1;
  const rows = [];
  for (let p = 0; p < points; p++) {
    const t = points === 1 ? 0 : p / (points - 1);
    const f = fMin * Math.pow(fMax / fMin, t);
    const omega = 2 * Math.PI * f;
    const Are = zeros(n, n);
    const Aim = zeros(n, n);
    for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) {
      Are[i][j] = K[i][j] - omega * omega * M[i][j];
      Aim[i][j] = omega * R[i][j];
    }
    const bre = Array(n).fill(0); bre[inputNode] = 1;
    const bim = Array(n).fill(0);
    const x = solveComplex(Are, Aim, bre, bim);
    const re = x.re[outputNode], im = x.im[outputNode];
    const mag = Math.sqrt(re * re + im * im);
    const phase = Math.atan2(im, re);
    rows.push({ freq_Hz: f, omega_rad_s: omega, magnitude: mag, magnitude_dB: 20 * Math.log10(mag + 1e-30), phase_rad: phase });
  }
  return rows;
}

export function peakResponse(rows) {
  return rows.reduce((best, r) => r.magnitude > best.magnitude ? r : best, rows[0]);
}
