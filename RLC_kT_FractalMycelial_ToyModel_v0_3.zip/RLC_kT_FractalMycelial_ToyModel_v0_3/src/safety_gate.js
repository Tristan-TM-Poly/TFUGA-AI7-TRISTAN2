export function runSafetyGate(config, solenoid) {
  const s = config.safety;
  const maxCapEnergy = solenoid.levels.reduce((sum, level) => sum + 0.5 * level.C_F * s.V_est * s.V_est, 0);
  const checks = {
    voltage: s.V_est <= s.V_max,
    current: s.I_est <= s.I_max,
    energy: maxCapEnergy <= s.E_max_J,
    temperature: s.T_est_C <= s.T_max_C,
    rollback: s.rollback_available === true
  };
  const margins = {
    Margin_V: s.V_max / Math.max(s.V_est, 1e-12),
    Margin_I: s.I_max / Math.max(s.I_est, 1e-12),
    Margin_E: s.E_max_J / Math.max(maxCapEnergy, 1e-12),
    Margin_T: (s.T_max_C + 273.15) / Math.max(s.T_est_C + 273.15, 1e-12),
    Rollback: s.rollback_available ? 1 : 0
  };
  const pass = Object.values(checks).every(Boolean);
  const numerator = margins.Margin_V * margins.Margin_I * margins.Margin_E * margins.Margin_T * margins.Rollback;
  const denominator = 1 + (s.unknowns ?? 0) + (s.thermal_risk ?? 0) + (s.coupling_risk ?? 0);
  return { pass, checks, margins, estimated_capacitive_energy_J: maxCapEnergy, safety_score: numerator / denominator };
}
