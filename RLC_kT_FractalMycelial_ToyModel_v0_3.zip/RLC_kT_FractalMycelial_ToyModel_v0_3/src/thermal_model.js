export function estimateThermal({ currentRms = 0.02, resistance = 1.0, duration_s = 60, cth_J_per_K = 25, cooling_W_per_K = 0.2, ambient_C = 25 }) {
  const qGen = currentRms * currentRms * resistance;
  const steadyRise = cooling_W_per_K > 0 ? qGen / cooling_W_per_K : Infinity;
  const tau = cooling_W_per_K > 0 ? cth_J_per_K / cooling_W_per_K : Infinity;
  const rise = Number.isFinite(tau) ? steadyRise * (1 - Math.exp(-duration_s / tau)) : qGen * duration_s / cth_J_per_K;
  return {
    qGen_W: qGen,
    steadyRise_C: steadyRise,
    tau_s: tau,
    estimatedTemp_C: ambient_C + rise,
    rise_C: rise
  };
}
