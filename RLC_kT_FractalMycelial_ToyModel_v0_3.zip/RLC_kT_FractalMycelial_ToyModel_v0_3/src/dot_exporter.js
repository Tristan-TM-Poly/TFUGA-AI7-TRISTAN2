import fs from 'fs';

export function topologyToDot(topo) {
  const lines = ['graph RLC_HFM {', '  rankdir=LR;', '  node [shape=circle];'];
  for (let i = 0; i < topo.nodes; i++) lines.push(`  ${i} [label="${i}"];`);
  for (const m of topo.mutuals || []) lines.push(`  ${m.i} -- ${m.j} [label="M k=${m.k}", color="blue"];`);
  for (const c of topo.capacitive_bridges || []) lines.push(`  ${c.i} -- ${c.j} [label="C=${c.C}", color="green", style="dashed"];`);
  lines.push('}');
  return lines.join('\n');
}

export function writeDot(filePath, topo) { fs.writeFileSync(filePath, topologyToDot(topo), 'utf8'); }
