import { assembleMatrices, validateMatrices } from './matrices.js';
import { solveUndampedModes } from './mode_solver.js';
import { scoreModes } from './powerscore.js';

function lcg(seed) {
  let s = seed >>> 0;
  return () => {
    s = (1664525 * s + 1013904223) >>> 0;
    return s / 0x100000000;
  };
}

function perturb(x, frac, rnd) {
  return x * (1 + frac * (2 * rnd() - 1));
}

export function monteCarloModes(solenoid, safety, opts = {}) {
  const samples = opts.samples ?? 24;
  const frac = opts.relativeUncertainty ?? 0.05;
  const rnd = lcg(opts.seed ?? 12345);
  const records = [];
  for (let s = 0; s < samples; s++) {
    const perturbed = {
      ...solenoid,
      levels: solenoid.levels.map(l => ({ ...l, L_H: perturb(l.L_H, frac, rnd), C_F: perturb(l.C_F, frac, rnd), R_ohm: Math.max(0, perturb(l.R_ohm, frac, rnd)) })),
      couplings: solenoid.couplings.map(c => ({ ...c }))
    };
    for (const c of perturbed.couplings) {
      const i = perturbed.levels.find(x => x.id === c.from);
      const j = perturbed.levels.find(x => x.id === c.to);
      c.M_H = c.k * Math.sqrt(i.L_H * j.L_H);
    }
    const { M, R, K } = assembleMatrices(perturbed);
    validateMatrices(M, R, K);
    const modes = scoreModes(solveUndampedModes(M, R, K), safety);
    const best = modes.reduce((a, b) => b.mode_score > a.mode_score ? b : a, modes[0]);
    records.push({ sample: s, best_freq_Hz: best.freq_Hz, best_Q: best.Q_approx, best_mode_score: best.mode_score });
  }
  return summarize(records);
}

function summarize(records) {
  const keys = ['best_freq_Hz', 'best_Q', 'best_mode_score'];
  const out = { samples: records.length, records };
  for (const key of keys) {
    const xs = records.map(r => r[key]).sort((a, b) => a - b);
    const mean = xs.reduce((a, b) => a + b, 0) / xs.length;
    const sd = Math.sqrt(xs.reduce((s, x) => s + (x - mean) ** 2, 0) / xs.length);
    out[key] = { mean, sd, min: xs[0], max: xs[xs.length - 1], p10: xs[Math.floor(0.1 * (xs.length - 1))], p90: xs[Math.floor(0.9 * (xs.length - 1))] };
  }
  return out;
}
