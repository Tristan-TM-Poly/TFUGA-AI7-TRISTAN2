export function auditUnits(solenoid) {
  const issues = [];
  for (const s of solenoid.levels) {
    if (!(s.L_H > 0 && s.L_H < 10)) issues.push(`${s.id}: L_H outside toy expected range`);
    if (!(s.C_F > 0 && s.C_F < 1)) issues.push(`${s.id}: C_F outside toy expected range`);
    if (!(s.R_ohm >= 0 && s.R_ohm < 1e4)) issues.push(`${s.id}: R_ohm outside toy expected range`);
    const f0 = 1 / (2 * Math.PI * Math.sqrt(s.L_H * s.C_F));
    if (!Number.isFinite(f0)) issues.push(`${s.id}: invalid f0`);
  }
  return { pass: issues.length === 0, issues };
}
