export function makeDctReport({ config, solenoid, matrices, modes, safety, power }) {
  const topMode = modes.slice().sort((a, b) => b.mode_score - a.mode_score)[0];
  return `# DCT Report — RLC-kT-HFM v0.1

## 1. Identity

- Module: RLC-kT Fractal-Mycelial Toy Model
- Config: ${config.name}
- Status: L4/L5 candidate

## 2. Hypothesis

A recursive solenoid can be modeled as a coupled lumped RLC system whose eigenmodes reveal useful low-power resonances, losses, and safety constraints.

## 3. Governing equation

M q'' + R q' + K q = u(t)

Undamped modes:

K psi = omega^2 M psi

## 4. Generated structure

- Levels: ${solenoid.levels.length}
- Couplings: ${solenoid.couplings.length}
- Matrix size: ${matrices.M.length} x ${matrices.M.length}

## 5. Top mode

- mode_id: ${topMode.mode_id}
- frequency_Hz: ${topMode.freq_Hz}
- Q_approx: ${topMode.Q_approx}
- mode_score: ${topMode.mode_score}

## 6. SafetyGate

- pass: ${safety.pass}
- estimated capacitive energy J: ${safety.estimated_capacitive_energy_J}
- safety score: ${safety.safety_score}

## 7. PowerScore

- PowerScore: ${power}

## 8. Limits

- Lumped model only.
- No full 3D electromagnetic validation.
- No distributed transmission-line effects in v0.1.
- No real prototype validation yet.
- SafetyGate is advisory and must not replace real engineering safety review.

## 9. Next actions

1. Add arbitrary topology YAML/JSON input.
2. Add frequency response H(omega).
3. Add Bode plot export.
4. Add Pareto optimizer for Q, loss, safety, complexity.
5. Add low-power measured prototype DCT when safe and available.
`;
}
