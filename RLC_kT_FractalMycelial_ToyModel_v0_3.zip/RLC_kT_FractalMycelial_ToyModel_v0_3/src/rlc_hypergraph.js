export function buildRlcHypergraph(solenoid) {
  const nodes = solenoid.levels.map(x => ({ id: x.id, level: x.level, kind: "scale_node" }));
  const edges = [];
  for (const s of solenoid.levels) {
    edges.push({ type: "L", from: s.id, to: "gnd", value: s.L_H, unit: "H" });
    edges.push({ type: "C", from: s.id, to: "gnd", value: s.C_F, unit: "F" });
    edges.push({ type: "R", from: s.id, to: "gnd", value: s.R_ohm, unit: "ohm" });
    edges.push({ type: "SAFE", from: s.id, to: "SafetyGate", value: 1, unit: "status" });
    edges.push({ type: "CTRL", from: s.id, to: "DCT", value: 1, unit: "status" });
  }
  for (const c of solenoid.couplings) {
    edges.push({ type: "M", from: c.from, to: c.to, k: c.k, value: c.M_H, unit: "H" });
    edges.push({ type: "T", from: c.from, to: c.to, ratio: 1, unit: "dimensionless" });
  }
  return { nodes, edges, metadata: { model: "RLC-kT-HFM", version: "0.1" } };
}
