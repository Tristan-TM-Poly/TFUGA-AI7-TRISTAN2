import fs from 'fs';
import { c, abs, phase } from './complex.js';
import { solveComplex } from './complex_linear_solver.js';

export function impedanceResponse(M, R, K, opts = {}) {
  const fMin = opts.fMin ?? 2e4;
  const fMax = opts.fMax ?? 4e5;
  const points = opts.points ?? 120;
  const inputNode = opts.inputNode ?? 0;
  const rows = [];
  for (let p = 0; p < points; p++) {
    const alpha = points === 1 ? 0 : p / (points - 1);
    const f = fMin * Math.pow(fMax / fMin, alpha);
    const w = 2 * Math.PI * f;
    const A = M.map((row, i) => row.map((mij, j) => c(K[i][j] - w * w * mij, w * R[i][j])));
    const u = M.map((_, i) => c(i === inputNode ? 1 : 0, 0));
    const q = solveComplex(A, u);
    const qIn = q[inputNode];
    const current = c(0, w); // I = i w q for unit generalized voltage proxy
    const iIn = { re: -current.im * qIn.im + current.re * qIn.re, im: current.re * qIn.im + current.im * qIn.re };
    const z = c(1, 0);
    const yMag = abs(iIn);
    const zMag = yMag > 0 ? 1 / yMag : Infinity;
    rows.push({ freq_Hz: f, omega_rad_s: w, Zin_mag_ohm_proxy: zMag, current_mag_proxy: yMag, phase_rad: phase(iIn) });
  }
  return rows;
}

export function writeSyntheticMeasuredCsv(filePath, response, noiseFraction = 0.035) {
  let s = 'freq_Hz,Zmag_ohm,phase_rad\n';
  for (const r of response) {
    const n1 = 1 + noiseFraction * Math.sin(r.freq_Hz * 1e-5);
    const n2 = noiseFraction * Math.cos(r.freq_Hz * 1.7e-5);
    s += `${r.freq_Hz},${r.Zin_mag_ohm_proxy * n1},${r.phase_rad + n2}\n`;
  }
  fs.writeFileSync(filePath, s, 'utf8');
}

export function loadMeasuredCsv(filePath) {
  const lines = fs.readFileSync(filePath, 'utf8').trim().split(/\r?\n/);
  const header = lines.shift().split(',');
  return lines.map(line => {
    const cols = line.split(',').map(Number);
    return Object.fromEntries(header.map((h, i) => [h, cols[i]]));
  });
}

export function compareImpedance(modelRows, measuredRows) {
  const n = Math.min(modelRows.length, measuredRows.length);
  let seMag = 0, sePhase = 0, maxRel = 0;
  for (let i = 0; i < n; i++) {
    const m = modelRows[i], d = measuredRows[i];
    const rel = Math.abs(m.Zin_mag_ohm_proxy - d.Zmag_ohm) / Math.max(Math.abs(d.Zmag_ohm), 1e-12);
    maxRel = Math.max(maxRel, rel);
    seMag += rel * rel;
    const dp = m.phase_rad - d.phase_rad;
    sePhase += dp * dp;
  }
  return { points: n, rmse_rel_mag: Math.sqrt(seMag / n), rmse_phase_rad: Math.sqrt(sePhase / n), max_rel_mag: maxRel };
}
