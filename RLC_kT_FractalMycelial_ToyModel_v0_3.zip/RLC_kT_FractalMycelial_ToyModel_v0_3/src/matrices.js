import { zeros } from './linear_algebra.js';

export function assembleMatrices(solenoid) {
  const n = solenoid.levels.length;
  const M = zeros(n, n);
  const R = zeros(n, n);
  const K = zeros(n, n);
  for (let i = 0; i < n; i++) {
    const s = solenoid.levels[i];
    M[i][i] = s.L_H;
    R[i][i] = s.R_ohm;
    K[i][i] = 1 / s.C_F;
  }
  const index = Object.fromEntries(solenoid.levels.map((s, i) => [s.id, i]));
  for (const c of solenoid.couplings) {
    const i = index[c.from], j = index[c.to];
    M[i][j] = c.M_H;
    M[j][i] = c.M_H;
  }
  return { M, R, K };
}

export function validateMatrices(M, R, K) {
  const n = M.length;
  if (R.length !== n || K.length !== n) throw new Error('Matrix row count mismatch');
  for (const A of [M, R, K]) {
    for (const row of A) if (row.length !== n) throw new Error('Matrix is not square');
  }
  for (let i = 0; i < n; i++) {
    if (!(M[i][i] > 0)) throw new Error(`M diagonal must be positive at ${i}`);
    if (!(K[i][i] > 0)) throw new Error(`K diagonal must be positive at ${i}`);
    if (!(R[i][i] >= 0)) throw new Error(`R diagonal must be nonnegative at ${i}`);
  }
  return true;
}
