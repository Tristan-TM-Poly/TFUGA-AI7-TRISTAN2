import { cholesky, invertLowerTriangular, transpose, multiply, jacobiEigenSymmetric, dot } from './linear_algebra.js';

export function solveUndampedModes(M, R, K) {
  const L = cholesky(M);
  const Linv = invertLowerTriangular(L);
  const LinvT = transpose(Linv);
  const A = multiply(multiply(Linv, K), LinvT);
  const eigen = jacobiEigenSymmetric(A);
  const modes = eigen.values.map((lambda, idx) => {
    const omega = Math.sqrt(Math.max(lambda, 0));
    const y = eigen.vectors[idx];
    const psi = multiply(LinvT, y.map(v => [v])).map(row => row[0]);
    const mEff = dot(psi, matVecSafe(M, psi));
    const rEff = dot(psi, matVecSafe(R, psi));
    const q = rEff > 0 ? (omega * mEff / rEff) : Infinity;
    const damping = rEff / (2 * mEff);
    return {
      mode_id: idx,
      lambda,
      omega_rad_s: omega,
      freq_Hz: omega / (2 * Math.PI),
      damping_approx: damping,
      Q_approx: q,
      vector: psi
    };
  });
  return modes;
}

function matVecSafe(A, x) {
  return A.map(row => row.reduce((s, a, i) => s + a * x[i], 0));
}
