import fs from 'node:fs';

export function ensureDir(path) { fs.mkdirSync(path, { recursive: true }); }

export function writeJson(path, obj) {
  fs.writeFileSync(path, JSON.stringify(obj, null, 2), 'utf8');
}

export function writeCsv(path, rows) {
  if (rows.length === 0) { fs.writeFileSync(path, '', 'utf8'); return; }
  const keys = Object.keys(rows[0]).filter(k => k !== 'vector');
  const lines = [keys.join(',')];
  for (const row of rows) lines.push(keys.map(k => row[k]).join(','));
  fs.writeFileSync(path, lines.join('\n') + '\n', 'utf8');
}
