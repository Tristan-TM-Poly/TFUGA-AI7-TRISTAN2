import { c, add, sub, mul, div } from './complex.js';

export function solveComplex(Ain, bin) {
  const n = Ain.length;
  const A = Ain.map(row => row.map(z => c(z.re, z.im)));
  const b = bin.map(z => c(z.re, z.im));
  for (let k = 0; k < n; k++) {
    let pivot = k;
    let best = mag2(A[k][k]);
    for (let i = k + 1; i < n; i++) {
      const m = mag2(A[i][k]);
      if (m > best) { best = m; pivot = i; }
    }
    if (best < 1e-30) throw new Error(`Singular complex matrix near column ${k}`);
    if (pivot !== k) { [A[pivot], A[k]] = [A[k], A[pivot]]; [b[pivot], b[k]] = [b[k], b[pivot]]; }
    for (let i = k + 1; i < n; i++) {
      const factor = div(A[i][k], A[k][k]);
      A[i][k] = c(0, 0);
      for (let j = k + 1; j < n; j++) A[i][j] = sub(A[i][j], mul(factor, A[k][j]));
      b[i] = sub(b[i], mul(factor, b[k]));
    }
  }
  const x = Array(n).fill(null).map(() => c(0, 0));
  for (let i = n - 1; i >= 0; i--) {
    let s = b[i];
    for (let j = i + 1; j < n; j++) s = sub(s, mul(A[i][j], x[j]));
    x[i] = div(s, A[i][i]);
  }
  return x;
}

function mag2(z) { return z.re * z.re + z.im * z.im; }
