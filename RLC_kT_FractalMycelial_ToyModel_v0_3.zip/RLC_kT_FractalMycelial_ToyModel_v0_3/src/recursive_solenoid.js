export function generateRecursiveSolenoid(config) {
  const n = config.levels;
  const levels = [];
  for (let m = 0; m < n; m++) {
    const L = config.L0_H * Math.pow(config.lambda_L, m);
    const C = config.C0_F * Math.pow(config.lambda_C, m);
    const R = config.R0_ohm * Math.pow(config.lambda_R, m);
    if (!(L > 0) || !(C > 0) || !(R >= 0)) throw new Error(`Invalid RLC parameters at level ${m}`);
    levels.push({ id: `S${m}`, level: m, L_H: L, C_F: C, R_ohm: R, omega0_rad_s: 1 / Math.sqrt(L * C), freq0_Hz: 1 / (2 * Math.PI * Math.sqrt(L * C)) });
  }
  const couplings = [];
  const k = config.magnetic_coupling_adjacent ?? 0;
  for (let m = 0; m < n - 1; m++) {
    couplings.push({ from: `S${m}`, to: `S${m + 1}`, k, M_H: k * Math.sqrt(levels[m].L_H * levels[m + 1].L_H) });
  }
  return { levels, couplings };
}
