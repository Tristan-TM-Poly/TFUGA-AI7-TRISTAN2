export function estimateCompensation({ freq_Hz, cBridge_F = 0, lLeak_H = 0, conductance_S = 0 }) {
  const w = 2 * Math.PI * freq_Hz;
  const Bc = w * cBridge_F;
  const Bl = lLeak_H > 0 ? -1 / (w * lLeak_H) : 0;
  const Btotal = Bc + Bl;
  const Ccomp_F = Btotal < 0 ? (-Btotal / w) : 0;
  const Lcomp_H = Btotal > 0 ? (1 / (w * Btotal)) : Infinity;
  return {
    freq_Hz,
    Bc_S: Bc,
    Bl_S: Bl,
    Btotal_S: Btotal,
    G_S: conductance_S,
    recommendation: Btotal > 0 ? 'add_series_or_shunt_inductive_compensation_proxy' : (Btotal < 0 ? 'add_capacitive_compensation_proxy' : 'already_balanced'),
    Ccomp_F,
    Lcomp_H,
    note: 'Toy proxy only. Real TC-2PCI compensation requires measured impedance, insulation review, protection coordination, and certified safety review.'
  };
}
