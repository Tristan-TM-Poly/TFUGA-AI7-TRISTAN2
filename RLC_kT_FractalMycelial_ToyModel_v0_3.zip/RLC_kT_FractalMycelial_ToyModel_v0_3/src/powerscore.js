export function scoreModes(modes, safety) {
  const safetyFactor = safety.pass ? Math.min(1, safety.safety_score / 10) : 0;
  return modes.map(m => {
    const Q = Number.isFinite(m.Q_approx) ? Math.max(0, m.Q_approx) : 1e6;
    const selectivity = Math.log10(1 + Q);
    const stability = m.damping_approx >= 0 ? 1 : 0;
    const measurability = m.freq_Hz > 1 && m.freq_Hz < 1e9 ? 1 : 0.5;
    const loss = 1 / Math.max(Q, 1e-9);
    const thermalRisk = safety.pass ? 0.05 : 10;
    const parasiticCoupling = 0.2;
    const complexity = modes.length / 10;
    const mode_score = (selectivity * stability * measurability * safetyFactor) / (1 + loss + thermalRisk + parasiticCoupling + complexity);
    return { ...m, selectivity, stability, measurability, safety_factor: safetyFactor, loss_proxy: loss, mode_score };
  });
}

export function powerScore({ fertility=0.7, verifiability=0.8, reusability=0.85, impact=0.7, compression=0.75, stability=0.8, complexity=0.35, noise=0.2, speculation=0.35, risk=0.25 } = {}) {
  const numerator = fertility * verifiability * reusability * impact * compression * stability;
  const denominator = Math.max(1e-12, complexity * noise * speculation * risk);
  return numerator / denominator;
}
