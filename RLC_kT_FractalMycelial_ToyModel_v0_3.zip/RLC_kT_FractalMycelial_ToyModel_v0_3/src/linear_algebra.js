export function zeros(n, m) {
  return Array.from({ length: n }, () => Array(m).fill(0));
}

export function identity(n) {
  const I = zeros(n, n);
  for (let i = 0; i < n; i++) I[i][i] = 1;
  return I;
}

export function cloneMatrix(A) {
  return A.map(row => row.slice());
}

export function transpose(A) {
  const n = A.length, m = A[0].length;
  const T = zeros(m, n);
  for (let i = 0; i < n; i++) for (let j = 0; j < m; j++) T[j][i] = A[i][j];
  return T;
}

export function matVec(A, x) {
  return A.map(row => row.reduce((s, a, i) => s + a * x[i], 0));
}

export function dot(a, b) {
  return a.reduce((s, x, i) => s + x * b[i], 0);
}

export function norm2(a) {
  return Math.sqrt(dot(a, a));
}

export function add(A, B) {
  return A.map((row, i) => row.map((v, j) => v + B[i][j]));
}

export function subtract(A, B) {
  return A.map((row, i) => row.map((v, j) => v - B[i][j]));
}

export function multiply(A, B) {
  const n = A.length, p = A[0].length, m = B[0].length;
  const C = zeros(n, m);
  for (let i = 0; i < n; i++) {
    for (let k = 0; k < p; k++) {
      const aik = A[i][k];
      for (let j = 0; j < m; j++) C[i][j] += aik * B[k][j];
    }
  }
  return C;
}

export function maxAbsOffDiag(A) {
  let max = 0, p = 0, q = 1;
  for (let i = 0; i < A.length; i++) {
    for (let j = i + 1; j < A.length; j++) {
      const v = Math.abs(A[i][j]);
      if (v > max) { max = v; p = i; q = j; }
    }
  }
  return { max, p, q };
}

export function jacobiEigenSymmetric(Ain, opts = {}) {
  const A = cloneMatrix(Ain);
  const n = A.length;
  const V = identity(n);
  const tol = opts.tol ?? 1e-12;
  const maxIter = opts.maxIter ?? 100 * n * n;
  for (let iter = 0; iter < maxIter; iter++) {
    const { max, p, q } = maxAbsOffDiag(A);
    if (max < tol) break;
    const app = A[p][p], aqq = A[q][q], apq = A[p][q];
    const phi = 0.5 * Math.atan2(2 * apq, aqq - app);
    const c = Math.cos(phi), s = Math.sin(phi);
    for (let k = 0; k < n; k++) {
      const akp = A[k][p], akq = A[k][q];
      A[k][p] = c * akp - s * akq;
      A[k][q] = s * akp + c * akq;
    }
    for (let k = 0; k < n; k++) {
      const apk = A[p][k], aqk = A[q][k];
      A[p][k] = c * apk - s * aqk;
      A[q][k] = s * apk + c * aqk;
    }
    for (let k = 0; k < n; k++) {
      const vkp = V[k][p], vkq = V[k][q];
      V[k][p] = c * vkp - s * vkq;
      V[k][q] = s * vkp + c * vkq;
    }
  }
  const values = A.map((row, i) => row[i]);
  const order = values.map((v, i) => [v, i]).sort((a, b) => a[0] - b[0]).map(x => x[1]);
  return {
    values: order.map(i => values[i]),
    vectors: order.map(i => V.map(row => row[i]))
  };
}

export function cholesky(A) {
  const n = A.length;
  const L = zeros(n, n);
  for (let i = 0; i < n; i++) {
    for (let j = 0; j <= i; j++) {
      let sum = A[i][j];
      for (let k = 0; k < j; k++) sum -= L[i][k] * L[j][k];
      if (i === j) {
        if (sum <= 0) throw new Error(`Matrix is not positive definite at diagonal ${i}: ${sum}`);
        L[i][j] = Math.sqrt(sum);
      } else {
        L[i][j] = sum / L[j][j];
      }
    }
  }
  return L;
}

export function forwardSubstitution(L, b) {
  const n = L.length;
  const x = Array(n).fill(0);
  for (let i = 0; i < n; i++) {
    let sum = b[i];
    for (let j = 0; j < i; j++) sum -= L[i][j] * x[j];
    x[i] = sum / L[i][i];
  }
  return x;
}

export function backwardSubstitution(U, b) {
  const n = U.length;
  const x = Array(n).fill(0);
  for (let i = n - 1; i >= 0; i--) {
    let sum = b[i];
    for (let j = i + 1; j < n; j++) sum -= U[i][j] * x[j];
    x[i] = sum / U[i][i];
  }
  return x;
}

export function invertLowerTriangular(L) {
  const n = L.length;
  const Inv = zeros(n, n);
  for (let col = 0; col < n; col++) {
    const e = Array(n).fill(0); e[col] = 1;
    const x = forwardSubstitution(L, e);
    for (let i = 0; i < n; i++) Inv[i][col] = x[i];
  }
  return Inv;
}

export function isSymmetric(A, tol = 1e-9) {
  for (let i = 0; i < A.length; i++) {
    for (let j = i + 1; j < A.length; j++) {
      if (Math.abs(A[i][j] - A[j][i]) > tol) return false;
    }
  }
  return true;
}
