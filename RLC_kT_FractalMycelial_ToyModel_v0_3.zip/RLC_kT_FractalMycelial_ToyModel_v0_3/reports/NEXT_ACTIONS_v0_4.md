# Next actions v0.4

1. Add arbitrary graph incidence matrix assembly for R, L, C and M components.
2. Add real laboratory CSV import for impedance magnitude and phase.
3. Add damped state-space solver and time-domain transient simulation.
4. Add SVG or HTML graph visualization.
5. Add topology generator with safety constraints.
6. Add uncertainty bands on response curves.
7. Add unit-aware input parser.
8. Add TC-nPCI-kE schema and family generator.
9. Add Omega RLC interactive dashboard.
10. Add promotion score L5 to L6 with prototype readiness checks.
