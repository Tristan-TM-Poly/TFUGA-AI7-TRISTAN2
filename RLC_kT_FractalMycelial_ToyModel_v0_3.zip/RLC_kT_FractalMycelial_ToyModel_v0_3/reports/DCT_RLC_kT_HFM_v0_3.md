# DCT RLC-kT-HFM v0.3

## Hypothesis
A recursive/fractal-mycelial RLC topology can be promoted from modal toy model to reusable engineering pre-prototype when it includes topology comparison, frequency response, impedance-data import, uncertainty, TC-2PCI compensation proxy, graph export, dashboard and SafetyGate.

## Equation core
M q'' + R q' + K q = u(t)

Frequency domain: (-omega^2 M + i omega R + K) qhat = uhat.

## Tested topologies
- chain_5_low_power: nodes=5, safety=true, best f=147507.04 Hz, Q=51.50, Power=105.095, impedance RMSE=0.01834, uncertainty freq rel SD=0.07594
- mycelium_sparse_7_low_power: nodes=7, safety=true, best f=144985.88 Hz, Q=55.91, Power=93.084, impedance RMSE=0.01834, uncertainty freq rel SD=0.01254
- star_5_low_power: nodes=5, safety=true, best f=124583.36 Hz, Q=39.92, Power=105.095, impedance RMSE=0.01834, uncertainty freq rel SD=0.07935

## Pareto front
- chain_5_low_power: modeScore=0.9721, Power=105.095, T=25.001 C, fit=0.01834
- mycelium_sparse_7_low_power: modeScore=0.8919, Power=93.084, T=25.001 C, fit=0.01834
- star_5_low_power: modeScore=0.9081, Power=105.095, T=25.001 C, fit=0.01834

## v0.3 additions
1. Impedance response proxy and synthetic measured CSV import.
2. Impedance model-data comparison.
3. TC-2PCI compensation proxy.
4. Monte Carlo uncertainty on L, C, R.
5. DOT graph export.
6. Omega RLC HTML dashboard.

## Limits
This remains a lumped low-power toy model. It is not a 3D EM solver, not a high-voltage design, not a medical/safety-certified system, and not a deployment plan. Real hardware requires certified electrical, thermal, fire, insulation, mechanical and cyber-safety review.

## Next actions v0.4
1. Add arbitrary incidence-matrix components between arbitrary pairs.
2. Add measured laboratory impedance import from real CSV.
3. Add full damped state-space solver.
4. Add SVG rendering from DOT.
5. Add optimization-generated topologies.
6. Add uncertainty bands on Bode/impedance plots.
7. Add unit-aware parser.
8. Add TC-nPCI-kE family generator.
9. Add Omega RLC interactive controls.
10. Add formal promotion score L5 -> L6.
