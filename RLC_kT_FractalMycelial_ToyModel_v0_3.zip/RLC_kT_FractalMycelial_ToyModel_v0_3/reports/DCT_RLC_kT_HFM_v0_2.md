# DCT RLC-kT-HFM v0.2

## Hypothesis
A recursive/fractal-mycelial RLC topology can be compared through modal spectra, frequency response, thermal proxy, unit audit, SafetyGate and Pareto selection.

## Tested topologies
- chain_5_low_power: nodes=5, safety=true, best f=147507.04 Hz, Q=51.50, Power=56.964
- mycelium_sparse_7_low_power: nodes=7, safety=true, best f=144985.88 Hz, Q=55.91, Power=50.454
- star_5_low_power: nodes=5, safety=true, best f=124583.36 Hz, Q=39.92, Power=56.964

## Pareto front
- chain_5_low_power: modeScore=0.9721, Power=56.964, T=25.001 C
- star_5_low_power: modeScore=0.9081, Power=56.964, T=25.001 C

## Limits
This is a lumped low-power toy model. It is not a 3D EM field solver and not a deployment plan. Real hardware requires certified electrical, thermal, mechanical and fire safety review.

## Next actions
1. Add arbitrary graph incidence matrices.
2. Add calibrated parasitic capacitances.
3. Add measured impedance data import.
4. Add HTML dashboard.
5. Add TC-2PCI source compensation module.
