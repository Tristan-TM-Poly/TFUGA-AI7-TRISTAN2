# NEXT_ACTIONS — v0.2 Roadmap

## Top 10 next improvements

1. Add arbitrary topology JSON input instead of only recursive chain generation.
2. Add frequency response H(omega) and export response curves.
3. Add Bode magnitude/phase CSV export.
4. Add graph topology families: chain, tree, star, ring, fractal-tree, mycelial-random-sparse.
5. Add Pareto optimizer for Q, stability, safety, complexity, and component count.
6. Add TC-2PCI source compensation model as optional module.
7. Add simple thermal model Cth dT/dt = I^2 R - h(T-Ta).
8. Add unit audit report for all inputs and outputs.
9. Add FFWT/modal clustering concept demo.
10. Add HTML report generation.

## Canonical next DCT

RLC-kT-HFM v0.2 should produce:

- topology comparison table,
- H(omega) response CSV,
- Pareto scorecard,
- expanded SafetyGate,
- DCT report with limits and next prototype guidance.
