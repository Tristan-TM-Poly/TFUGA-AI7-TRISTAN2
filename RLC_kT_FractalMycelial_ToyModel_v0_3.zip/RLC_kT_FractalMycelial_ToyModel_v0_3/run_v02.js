import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { loadTopology, topologyToSolenoid } from './src/topology_loader.js';
import { assembleMatrices, validateMatrices } from './src/matrices.js';
import { solveUndampedModes } from './src/mode_solver.js';
import { runSafetyGate } from './src/safety_gate.js';
import { scoreModes, powerScore } from './src/powerscore.js';
import { writeCsv, writeJson, ensureDir } from './src/exporters.js';
import { frequencyResponse, peakResponse } from './src/frequency_response.js';
import { estimateThermal } from './src/thermal_model.js';
import { auditUnits } from './src/unit_audit.js';
import { paretoFront } from './src/pareto_optimizer.js';
import { modalScaleSignature } from './src/ffwt_modal_cluster.js';

const __filename = fileURLToPath(import.meta.url);
const root = path.dirname(__filename);
const outDir = path.join(root, 'outputs', 'v0_2');
ensureDir(outDir);

const topologyPaths = fs.readdirSync(path.join(root, 'topologies'))
  .filter(f => f.endsWith('.json'))
  .map(f => path.join(root, 'topologies', f));

const summaries = [];
for (const topoPath of topologyPaths) {
  const topo = loadTopology(topoPath);
  const solenoid = topologyToSolenoid(topo);
  const { M, R, K } = assembleMatrices(solenoid);
  validateMatrices(M, R, K);
  const unitAudit = auditUnits(solenoid);
  const safetyConfig = {
    safety: {
      V_est: 5,
      V_max: topo.safety?.vMax ?? 12,
      I_est: 0.02,
      I_max: topo.safety?.iMax ?? 0.05,
      E_max_J: topo.safety?.eMax ?? 0.01,
      T_est_C: 28,
      T_max_C: topo.safety?.tMax ?? 45,
      rollback_available: topo.safety?.rollbackDefined === true,
      unknowns: 1,
      thermal_risk: 0.05,
      coupling_risk: 0.1
    }
  };
  const safety = runSafetyGate(safetyConfig, solenoid);
  const modes = scoreModes(solveUndampedModes(M, R, K), safety);
  const response = frequencyResponse(M, R, K, { fMin: 4e4, fMax: 3e5, points: 80, inputNode: 0, outputNode: topo.nodes - 1 });
  const peak = peakResponse(response);
  const avgR = topo.branches.reduce((s, b) => s + b.R, 0) / topo.branches.length;
  const thermal = estimateThermal({ currentRms: 0.02, resistance: avgR, duration_s: 120, cth_J_per_K: 25, cooling_W_per_K: 0.2, ambient_C: 25 });
  const signature = modalScaleSignature(modes);
  const bestMode = modes.reduce((a, b) => b.mode_score > a.mode_score ? b : a, modes[0]);
  const pScore = powerScore({
    fertility: 0.78,
    verifiability: unitAudit.pass && safety.pass ? 0.9 : 0.5,
    reusability: 0.9,
    impact: 0.75,
    compression: 0.78,
    stability: safety.pass ? 0.86 : 0.4,
    complexity: 0.35 + topo.nodes / 30,
    noise: 0.18,
    speculation: 0.30,
    risk: safety.pass ? 0.20 : 0.8
  });
  const summary = {
    topology: topo.name,
    nodes: topo.nodes,
    safety_pass: safety.pass,
    unit_audit_pass: unitAudit.pass,
    best_mode_freq_Hz: bestMode.freq_Hz,
    best_mode_Q: bestMode.Q_approx,
    best_mode_score: bestMode.mode_score,
    peak_response_freq_Hz: peak.freq_Hz,
    peak_response_dB: peak.magnitude_dB,
    estimated_temp_C: thermal.estimatedTemp_C,
    modal_mean_ratio: signature.mean_ratio,
    modal_ratio_spread: signature.ratio_spread,
    power_score: pScore
  };
  summaries.push(summary);
  const base = topo.name;
  writeJson(path.join(outDir, `${base}_matrices.json`), { M, R, K });
  writeCsv(path.join(outDir, `${base}_modes.csv`), modes);
  writeCsv(path.join(outDir, `${base}_bode.csv`), response);
  writeJson(path.join(outDir, `${base}_safety.json`), safety);
  writeJson(path.join(outDir, `${base}_thermal.json`), thermal);
  writeJson(path.join(outDir, `${base}_modal_signature.json`), signature);
  writeJson(path.join(outDir, `${base}_unit_audit.json`), unitAudit);
}
const front = paretoFront(summaries, [
  { key: 'best_mode_score', direction: 'max' },
  { key: 'power_score', direction: 'max' },
  { key: 'estimated_temp_C', direction: 'min' }
]);
writeJson(path.join(outDir, 'topology_summary.json'), summaries);
writeJson(path.join(outDir, 'pareto_front.json'), front);
writeCsv(path.join(outDir, 'topology_summary.csv'), summaries);

const dct = `# DCT RLC-kT-HFM v0.2\n\n## Hypothesis\nA recursive/fractal-mycelial RLC topology can be compared through modal spectra, frequency response, thermal proxy, unit audit, SafetyGate and Pareto selection.\n\n## Tested topologies\n${summaries.map(s => `- ${s.topology}: nodes=${s.nodes}, safety=${s.safety_pass}, best f=${s.best_mode_freq_Hz.toFixed(2)} Hz, Q=${s.best_mode_Q.toFixed(2)}, Power=${s.power_score.toFixed(3)}`).join('\n')}\n\n## Pareto front\n${front.map(s => `- ${s.topology}: modeScore=${s.best_mode_score.toFixed(4)}, Power=${s.power_score.toFixed(3)}, T=${s.estimated_temp_C.toFixed(3)} C`).join('\n')}\n\n## Limits\nThis is a lumped low-power toy model. It is not a 3D EM field solver and not a deployment plan. Real hardware requires certified electrical, thermal, mechanical and fire safety review.\n\n## Next actions\n1. Add arbitrary graph incidence matrices.\n2. Add calibrated parasitic capacitances.\n3. Add measured impedance data import.\n4. Add HTML dashboard.\n5. Add TC-2PCI source compensation module.\n`;
fs.writeFileSync(path.join(root, 'reports', 'DCT_RLC_kT_HFM_v0_2.md'), dct, 'utf8');
console.log(JSON.stringify({ ok: true, topologies: summaries.length, pareto: front.map(x => x.topology) }, null, 2));
process.exit(0);
