# ModeScore and PowerScore

ModeScore_j = (Q_j Selectivity_j Stability_j Measurability_j Safety_j) / (1 + Loss_j + ThermalRisk_j + ParasiticCoupling_j + Complexity_j)

Power(Y) = (Fertility Verifiability Reusability Impact Compression Stability) / (Complexity Noise UntestedSpeculation Risk)

Recommended interpretation:

- Use ModeScore to rank modes inside a topology.
- Use PowerScore to compare whole architectures or iterations.
- Never use a high score to bypass SafetyGate.
