# SafetyGate

SafetyGate = S_V S_I S_E S_T S_rollback

S_V = 1(V <= V_max)
S_I = 1(I <= I_max)
S_E = 1(E <= E_max)
S_T = 1(T <= T_max)
S_rollback = 1(rollback_available)

If any factor is zero, deployment is zero.

SafetyScore = (Margin_V Margin_I Margin_E Margin_T Rollback) / (1 + Unknowns + ThermalRisk + CouplingRisk)

In v0.1 all examples use simulated low-power values only.
