# RLC Hypergraph Model

## Hypergraph

H_RLC = (V, E_R, E_C, E_L, E_M, E_T, E_safe, E_ctrl)

Each edge has a type, parameters, units, and a status.

## Lumped dynamics

M q'' + R q' + K q = u(t)

where M is the inductive/magnetic matrix, R is damping/resistive loss, and K is capacitive stiffness, approximated as C^{-1} in modal coordinates.

## Harmonic form

q(t) = q_hat exp(i omega t)

(-omega^2 M + i omega R + K) q_hat = u_hat

## Undamped modes

K psi_j = omega_j^2 M psi_j

For diagonal M,K without coupling, omega_j = 1/sqrt(L_j C_j).

## Damping and Q estimate

For a lightly damped single modal coordinate:

Q_j approx omega_j m_eff_j / r_eff_j

where m_eff_j = psi_j^T M psi_j and r_eff_j = psi_j^T R psi_j.
