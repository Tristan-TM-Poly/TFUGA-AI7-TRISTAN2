# Recursive Solenoid Model

## Scale law

For m = 0,...,n-1:

L_m = L0 lambda_L^m
C_m = C0 lambda_C^m
R_m = R0 lambda_R^m

Local angular frequency:

omega_0,m = 1 / sqrt(L_m C_m)

omega_0,m = omega_0,0 (lambda_L lambda_C)^(-m/2)

## Magnetic coupling

M_ij = k_ij sqrt(L_i L_j)

with |k_ij| < 1 for passive coupling.

## Transformer-like bridge

A transformer bridge can be encoded as a coupling relation with ratio mu = Ns/Np.
In v0.1 this ratio affects metadata and future extension but not ideal high-power transfer.
