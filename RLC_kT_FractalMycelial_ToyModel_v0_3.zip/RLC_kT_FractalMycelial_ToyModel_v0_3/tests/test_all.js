import assert from 'node:assert/strict';
import { generateRecursiveSolenoid } from '../src/recursive_solenoid.js';
import { buildRlcHypergraph } from '../src/rlc_hypergraph.js';
import { assembleMatrices, validateMatrices } from '../src/matrices.js';
import { isSymmetric } from '../src/linear_algebra.js';
import { solveUndampedModes } from '../src/mode_solver.js';
import { runSafetyGate } from '../src/safety_gate.js';

const config = {
  name: 'test',
  levels: 3,
  L0_H: 1e-5,
  C0_F: 1e-7,
  R0_ohm: 0.5,
  lambda_L: 2,
  lambda_C: 0.5,
  lambda_R: 1.2,
  magnetic_coupling_adjacent: 0.2,
  safety: {
    V_max: 12,
    I_max: 0.5,
    E_max_J: 0.5,
    T_max_C: 45,
    V_est: 5,
    I_est: 0.1,
    T_est_C: 25,
    rollback_available: true,
    unknowns: 1,
    thermal_risk: 0.1,
    coupling_risk: 0.2
  }
};

const solenoid = generateRecursiveSolenoid(config);
assert.equal(solenoid.levels.length, 3);
for (const level of solenoid.levels) {
  assert.ok(level.L_H > 0);
  assert.ok(level.C_F > 0);
  assert.ok(level.R_ohm >= 0);
}

const hypergraph = buildRlcHypergraph(solenoid);
assert.ok(hypergraph.nodes.length === 3);
assert.ok(hypergraph.edges.some(e => e.type === 'M'));

const matrices = assembleMatrices(solenoid);
assert.ok(validateMatrices(matrices.M, matrices.R, matrices.K));
assert.ok(isSymmetric(matrices.M));
assert.equal(matrices.M.length, 3);
assert.equal(matrices.R.length, 3);
assert.equal(matrices.K.length, 3);

const modes = solveUndampedModes(matrices.M, matrices.R, matrices.K);
assert.equal(modes.length, 3);
for (const mode of modes) {
  assert.ok(Number.isFinite(mode.freq_Hz));
  assert.ok(mode.freq_Hz > 0);
  assert.ok(mode.Q_approx > 0);
}

const safety = runSafetyGate(config, solenoid);
assert.equal(safety.pass, true);

const unsafe = JSON.parse(JSON.stringify(config));
unsafe.safety.V_est = 1000;
const unsafeResult = runSafetyGate(unsafe, solenoid);
assert.equal(unsafeResult.pass, false);

console.log('All tests passed.');
process.exit(0);
