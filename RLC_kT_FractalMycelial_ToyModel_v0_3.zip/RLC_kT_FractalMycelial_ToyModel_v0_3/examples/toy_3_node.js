import { generateRecursiveSolenoid } from '../src/recursive_solenoid.js';
import { assembleMatrices } from '../src/matrices.js';
import { solveUndampedModes } from '../src/mode_solver.js';

const config = {
  levels: 3,
  L0_H: 1e-5,
  C0_F: 1e-7,
  R0_ohm: 0.5,
  lambda_L: 2,
  lambda_C: 0.5,
  lambda_R: 1.2,
  magnetic_coupling_adjacent: 0.2
};
const solenoid = generateRecursiveSolenoid(config);
const matrices = assembleMatrices(solenoid);
const modes = solveUndampedModes(matrices.M, matrices.R, matrices.K);
console.log(modes.map(m => ({ id: m.mode_id, freq_Hz: m.freq_Hz, Q: m.Q_approx })));
