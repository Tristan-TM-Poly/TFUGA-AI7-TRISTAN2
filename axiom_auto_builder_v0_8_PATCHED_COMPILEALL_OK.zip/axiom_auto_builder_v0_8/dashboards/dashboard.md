# Axiom Dashboard v0.6

## Promotion
promoted

## Global score
5.34

## Passed
13

## Failed
0

## Canon guard
passed
