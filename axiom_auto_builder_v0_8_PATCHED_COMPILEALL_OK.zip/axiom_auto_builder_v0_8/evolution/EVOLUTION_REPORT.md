# Axiom Evolution Loop v0.7

Generated: 2026-04-28T10:57:09.020992+00:00

## Summary

- status: completed
- executed_until_generation: 110
- best_score: 17.049743
- population: 4
- checkpoint_every: 5

## Best genome

- generation: 103
- genome_id: 57e745eeeeaadebe
- mutation_rate: 0.11933192185985772
- canon_weight: 3.0
- validation_weight: 3.0
- automation_weight: 3.0
- synergy_weight: 3.0
- risk_penalty: 0.01757
- complexity_penalty: 0.0
- modules_target: 10
- test_intensity: 6
- report_depth: 6

## Recent lineage
- generation 101: 17.037952 / 22fda1e75f3ce82b
- generation 102: 17.042093 / e75d1649f7008ba4
- generation 103: 17.049743 / 57e745eeeeaadebe
- generation 104: 16.849015 / 375420bfc0c2b864
- generation 105: 16.973731 / 7e238df5b76574d6
- generation 106: 16.882483 / 0de48acbf0bdd83a
- generation 107: 16.986325 / 1e1c90f4057addb4
- generation 108: 17.010696 / e770821cefe00b99
- generation 109: 16.9373 / 012a6f7d6071b480
- generation 110: 16.85346 / 0cb3dc4ed856b111

## Resume

`python3 -S axiom.py evolve --generations 1000 --population 12 --checkpoint-every 100`
