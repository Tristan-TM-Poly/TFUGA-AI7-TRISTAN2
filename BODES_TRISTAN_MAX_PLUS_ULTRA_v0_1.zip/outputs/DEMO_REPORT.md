# Bodes-Tristan demo result

Network topology: `parallel` with 7 fractal branches and 24.0 dB active gain.

| Packet | f0 [Hz] | sigma_f [Hz] | min_dt [s] | gain [dB] | tau_g mean [s] | distortion proxy |
|---|---:|---:|---:|---:|---:|---:|
| P1_2MHz_narrow | 2e+06 | 80000 | 9.947184e-07 | 18.430 | 6.177234e-06 | 2.4023 |
| P2_18MHz_medium | 1.8e+07 | 800000 | 9.947184e-08 | 18.553 | 5.994354e-07 | 2.25847 |
| P3_162MHz_wide | 1.62e+08 | 9e+06 | 8.841941e-09 | 18.199 | 5.902491e-08 | 2.59779 |
| P4_486MHz_probe | 4.86e+08 | 1.8e+07 | 4.420971e-09 | 19.701 | 2.105632e-08 | 1.25638 |

Coherence offdiag/diag ratio: `6.30197e-57`.

Files generated:
- `outputs/bodes_tristan_demo_analysis.json`
- `outputs/packet_metrics.csv`
- `results/bt_gain_response.png`
- `results/bt_group_delay.png`
- `results/bt_coherence_matrix.png`