from __future__ import annotations

from pathlib import Path
import sys
import unittest
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))

from bodes_tristan import WavePacket, fractal_resonator_network, bodes_tristan_analysis


class TestBodesTristanCore(unittest.TestCase):
    def test_time_bandwidth_minimum(self):
        p = WavePacket('test', 2*np.pi*1e6, 2*np.pi*1e4)
        self.assertAlmostEqual(p.delta_t_min * p.sigma_omega, 0.5, places=12)

    def test_coherence_matrix_is_hermitian_positive(self):
        omega = 2*np.pi*np.logspace(4, 8, 6000)
        network = fractal_resonator_network(1e5, 4, 4.0, q_base=20, topology='parallel', normalize_peak=True)
        packets = [WavePacket('p1', 2*np.pi*1e5, 2*np.pi*1e4), WavePacket('p2', 2*np.pi*4e5, 2*np.pi*2e4)]
        analysis = bodes_tristan_analysis(omega, network, packets)
        k = np.array(analysis['coherence_matrix_real']) + 1j*np.array(analysis['coherence_matrix_imag'])
        self.assertLess(np.max(np.abs(k - k.conjugate().T)), 1e-8)
        evals = np.linalg.eigvalsh(k)
        self.assertGreaterEqual(np.min(evals), -1e-8)

    def test_metrics_have_expected_fields(self):
        omega = 2*np.pi*np.logspace(4, 7, 4000)
        network = fractal_resonator_network(1e5, 3, 3.0, q_base=10, active_gain_db=6, normalize_peak=True)
        p = WavePacket('p', 2*np.pi*1e5, 2*np.pi*2e4)
        analysis = bodes_tristan_analysis(omega, network, [p])
        m = analysis['packet_metrics'][0]
        for key in ['gain_db', 'group_delay_mean_s', 'distortion_proxy', 'time_bandwidth_product']:
            self.assertIn(key, m)
        self.assertTrue(np.isfinite(m['gain_db']))


if __name__ == '__main__':
    unittest.main()
