# Bodes-Tristan v1: lieu spectral-temporel-hypergraphique

## Objet

Un Bode classique mesure `|H(i omega)|` et `arg H(i omega)`. Bodes-Tristan mesure ce qu'un systeme fait a des paquets d'ondes finis en largeur temporelle et frequentielle, puis a des familles de paquets recouples.

\[
\mathcal{BT}_n = (\mathbf H(\omega), \{\psi_p\}_{p=1}^n, \mathbf K_{out}, \mathfrak H_{BT}, \mathcal C_{phys}).
\]

- `H(omega)` ou `H_matrix(omega)`: transfert scalaire ou multiport.
- `psi_p`: paquet spectral avec centre, largeur, phase, amplitude.
- `K_out`: matrice gain/coherence.
- `H_BT`: hypergraphe des modes, branches, materiaux, ports et paquets.
- `C_phys`: contraintes energie, bruit, chaleur, stabilite, adaptation et Bode-Fano.

## Un paquet

Pour un paquet gaussien minimal:

\[
\Delta t_p\,\Delta\omega_p \geq \frac12.
\]

Le gain reel vu par le paquet est:

\[
G_p = 10\log_{10}\frac{\int |H(\omega)|^2 S_p(\omega)d\omega}{\int S_p(\omega)d\omega}.
\]

Le delai de groupe est:

\[
\tau_g(\omega) = -\frac{d}{d\omega}\arg H(\omega).
\]

Une approximation utile de l'elargissement temporel est:

\[
(\Delta t_{out})^2 \approx (\Delta t_{in})^2 + (\beta_2\Delta\omega)^2 + \sigma_{\tau_g}^2.
\]

## n paquets

Pour

\[
x(t)=\sum_{p=1}^{n} a_p\psi_p(t),
\]

l'energie de sortie est:

\[
E_{out}=\mathbf a^\dagger \mathbf K_{out}\mathbf a,
\]

avec

\[
K_{out,pq}=\int \Psi_p^*(\omega)H^*(\omega)H(\omega)\Psi_q(\omega)d\omega.
\]

La diagonale donne l'amplification par paquet. Les termes hors diagonale donnent interference, recouplage, contamination ou synergie coherente.

## Serie, parallele, mixte

Serie:

\[
H_{series}(\omega)=\prod_{\ell=1}^{L}H_\ell(\omega).
\]

Parallele:

\[
H_{parallel}(\omega)=\sum_{b=1}^{B}\alpha_b H_b(\omega)e^{-i\omega\tau_b}.
\]

Mixte et multiport:

\[
\mathbf H(s)=\mathbf C(s\mathbf I-\mathbf A)^{-1}\mathbf B+\mathbf D.
\]

## Fractal LC

Un niveau LC a:

\[
f_\ell=\frac{1}{2\pi\sqrt{L_\ell C_\ell}}, \qquad L_\ell=L_0\alpha^\ell, \quad C_\ell=C_0\beta^\ell.
\]

Donc:

\[
f_\ell=f_0(\alpha\beta)^{-\ell/2}.
\]

Pour une cascade octave: `alpha beta = 4`. Pour une cascade decade: `alpha beta = 100`.

## Principe de gouvernance

Bodes-Tristan ne promet pas une amplification passive infinie. Il impose:

\[
\max_\Theta Power_{BT}(\Theta) \quad \text{sous contraintes physiques}.
\]

Avec:

\[
Power_{BT}=\frac{G_{utile}B_{utile}C_{coh}\eta St M}{D_{dist}N_{bruit}P_{perte}R_{risque}C_{complexite}}.
\]

