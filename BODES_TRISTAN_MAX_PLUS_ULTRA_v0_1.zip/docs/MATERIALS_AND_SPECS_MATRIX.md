# Materiaux et specs cibles Bodes-Tristan

Ces specs sont des cibles de conception plausibles par sous-systeme, pas des mesures d'un prototype TFUGA complet.

| Bande | Materiaux/nanostructures fortes | Architecture | Cibles v1/v2 |
|---|---|---|---|
| 50/60 Hz - 10 kHz | cuivre OFHC, fil de Litz, noyaux ferrite/nanocristallins, condensateurs film polypropylene | correction reactive, TC-nPCI-kE energetique, filtres harmoniques | rendement >95% si design bien dimensionne; facteur de puissance >0.99; THD a mesurer |
| 10 kHz - 10 MHz | Litz, ferrites MnZn/NiZn, C0G/NP0, interdigites, couches minces cuivre/argent | LC fractal multi-niveaux, branches accordables | Q_eff ~50-500 ambiant; gain actif 0-40 dB/module |
| 10 MHz - 10 GHz | GaN-on-SiC, SiC, alumine, Rogers, argent/cuivre, metamateriaux RF | RF fractal, branches paralleles, matching Bode-Fano, amplis actifs | -20 a +40 dB v1; +60 dB possible par chaine active multi-etage avec bruit/chaleur/saturation controles |
| cryo 1-20 GHz | NbTiN/NbN, Al, saphir, Si haute resistivite | resonateurs supraconducteurs, inductance cinetique, filtres accordables | Q_i > 1e5 comme cible credible; couplage accordable |
| 0.1-10 THz | graphène, hBN, VO2, GaAs, SiO2, Au, metasurfaces | absorbeurs/coupleurs accordables, sensing | absorption >90% sur bandes ciblees; accordabilite par potentiel chimique ou phase VO2 |
| optique/NIR/MIR | TFLN, SiN, Si, TiO2, SiC, diamant | modulators EO, PICs, metasurfaces | EO >50-100 GHz selon design; multi-longueurs d'onde |
| mecanique/acoustique | SiN contraint, diamant, SiC, phononic crystals | filtres phononiques, capteurs, resonateurs | Q tres eleve possible avec dilution de dissipation; a specifier par mode |

Stack max recommande:

1. Energie basse frequence: cuivre Litz + ferrite/nanocristallin + film capacitors + refroidissement fractal.
2. RF/micro-ondes: GaN-on-SiC + substrat faible perte + reseaux LC distribues + matching adaptatif.
3. Cryo: NbTiN/NbN + saphir/Si + geometrique haute inductance cinetique.
4. THz/optique: graphene/hBN + VO2 + TFLN + SiN/TiO2/SiC + metasurfaces fractales.

