"""Bodes-Tristan: packet-aware Bode analysis for wave packets and fractal/mycelial transfer networks."""
from .core import (
    WavePacket,
    ResonatorBranch,
    NetworkSpec,
    gaussian_packet_spectrum,
    fractal_resonator_network,
    packet_metrics,
    coherence_matrix,
    bodes_tristan_analysis,
)

__all__ = [
    'WavePacket', 'ResonatorBranch', 'NetworkSpec', 'gaussian_packet_spectrum',
    'fractal_resonator_network', 'packet_metrics', 'coherence_matrix', 'bodes_tristan_analysis'
]
