from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Iterable, Sequence
import numpy as np


@dataclass(frozen=True)
class WavePacket:
    """Gaussian spectral packet centered at omega0 with RMS spectral width sigma_omega."""
    name: str
    omega0: float
    sigma_omega: float
    amplitude: complex = 1.0 + 0.0j
    phase: float = 0.0

    @property
    def delta_t_min(self) -> float:
        # For a minimum-uncertainty Gaussian with angular-frequency RMS width sigma_omega.
        return 1.0 / (2.0 * self.sigma_omega)

    def as_dict(self) -> dict:
        d = asdict(self)
        d['amplitude'] = [float(np.real(self.amplitude)), float(np.imag(self.amplitude))]
        d['delta_t_min'] = self.delta_t_min
        return d


@dataclass(frozen=True)
class ResonatorBranch:
    """Second-order band-pass-like branch with tunable gain and delay."""
    name: str
    omega0: float
    q: float
    gain_linear: float = 1.0
    delay_s: float = 0.0
    weight: complex = 1.0 + 0.0j

    def response(self, omega: np.ndarray) -> np.ndarray:
        # Stable normalized resonant response. x = omega/omega0.
        x = np.maximum(omega / self.omega0, 1e-30)
        # H = gain / (1 + j Q (x - 1/x)) times programmed phase delay.
        h = self.gain_linear / (1.0 + 1j * self.q * (x - 1.0 / x))
        return self.weight * h * np.exp(-1j * omega * self.delay_s)

    def as_dict(self) -> dict:
        d = asdict(self)
        d['weight'] = [float(np.real(self.weight)), float(np.imag(self.weight))]
        return d


@dataclass(frozen=True)
class NetworkSpec:
    branches: tuple[ResonatorBranch, ...]
    topology: str = 'parallel'  # parallel or cascade
    active_gain_db: float = 0.0
    normalize_peak: bool = False

    def response(self, omega: np.ndarray) -> np.ndarray:
        if not self.branches:
            h = np.ones_like(omega, dtype=complex)
        elif self.topology == 'cascade':
            h = np.ones_like(omega, dtype=complex)
            for branch in self.branches:
                h = h * branch.response(omega)
        elif self.topology == 'parallel':
            h = np.zeros_like(omega, dtype=complex)
            for branch in self.branches:
                h = h + branch.response(omega)
        else:
            raise ValueError(f'Unsupported topology: {self.topology}')
        if self.normalize_peak:
            peak = np.max(np.abs(h))
            if peak > 0:
                h = h / peak
        h = h * 10.0 ** (self.active_gain_db / 20.0)
        return h

    def as_dict(self) -> dict:
        return {
            'topology': self.topology,
            'active_gain_db': self.active_gain_db,
            'normalize_peak': self.normalize_peak,
            'branches': [b.as_dict() for b in self.branches],
        }


def gaussian_packet_spectrum(omega: np.ndarray, packet: WavePacket) -> np.ndarray:
    """Complex Gaussian spectral amplitude Ψ(ω), normalized so ∫|Ψ|²dω ≈ 1."""
    sigma = packet.sigma_omega
    amp = np.exp(-0.5 * ((omega - packet.omega0) / sigma) ** 2)
    phase = np.exp(1j * packet.phase)
    # normalize by numerical integral of power spectral density
    psd = np.abs(amp) ** 2
    norm = np.trapezoid(psd, omega)
    if norm <= 0:
        raise ValueError('Packet norm vanished. Check omega grid and packet width.')
    return packet.amplitude * phase * amp / np.sqrt(norm)


def _unwrap_phase(h: np.ndarray) -> np.ndarray:
    return np.unwrap(np.angle(h))


def _derivative(y: np.ndarray, x: np.ndarray) -> np.ndarray:
    return np.gradient(y, x, edge_order=2)


def packet_metrics(omega: np.ndarray, h: np.ndarray, packet: WavePacket) -> dict:
    psi = gaussian_packet_spectrum(omega, packet)
    s = np.abs(psi) ** 2
    in_energy = float(np.trapezoid(s, omega))
    out_energy_density = np.abs(h) ** 2 * s
    out_energy = float(np.trapezoid(out_energy_density, omega))
    gain_linear = out_energy / max(in_energy, 1e-300)
    gain_db = 10.0 * np.log10(max(gain_linear, 1e-300))

    phase = _unwrap_phase(h)
    tau_g = -_derivative(phase, omega)
    beta2 = _derivative(tau_g, omega)
    weight = out_energy_density / max(out_energy, 1e-300)
    tau_mean = float(np.trapezoid(weight * tau_g, omega))
    tau_rms = float(np.sqrt(max(np.trapezoid(weight * (tau_g - tau_mean) ** 2, omega), 0.0)))
    beta2_mean = float(np.trapezoid(weight * beta2, omega))

    # Time broadening proxy: minimal input width plus dispersion and group-delay ripple.
    dt_in = packet.delta_t_min
    dt_out_proxy = float(np.sqrt(dt_in ** 2 + (beta2_mean * packet.sigma_omega) ** 2 + tau_rms ** 2))
    distortion_proxy = float(abs(dt_out_proxy / dt_in - 1.0))

    # Phase linearity proxy within packet support.
    phase_fit_weight = s / max(np.trapezoid(s, omega), 1e-300)
    center = float(np.trapezoid(phase_fit_weight * omega, omega))
    # Weighted first-order phase fit residual.
    a1 = -tau_mean
    intercept = float(np.trapezoid(phase_fit_weight * (phase - a1 * (omega - center)), omega))
    residual = phase - (intercept + a1 * (omega - center))
    phase_rms_error = float(np.sqrt(max(np.trapezoid(phase_fit_weight * residual ** 2, omega), 0.0)))

    return {
        'name': packet.name,
        'omega0_rad_s': packet.omega0,
        'f0_hz': packet.omega0 / (2.0 * np.pi),
        'sigma_omega_rad_s': packet.sigma_omega,
        'sigma_f_hz': packet.sigma_omega / (2.0 * np.pi),
        'delta_t_min_s': dt_in,
        'time_bandwidth_product': dt_in * packet.sigma_omega,
        'gain_linear': float(gain_linear),
        'gain_db': float(gain_db),
        'group_delay_mean_s': tau_mean,
        'group_delay_rms_s': tau_rms,
        'beta2_mean_s2': beta2_mean,
        'delta_t_out_proxy_s': dt_out_proxy,
        'distortion_proxy': distortion_proxy,
        'phase_rms_error_rad': phase_rms_error,
    }


def coherence_matrix(omega: np.ndarray, h: np.ndarray, packets: Sequence[WavePacket]) -> np.ndarray:
    psis = [gaussian_packet_spectrum(omega, p) for p in packets]
    k = np.zeros((len(packets), len(packets)), dtype=complex)
    h2 = np.conjugate(h) * h
    for i, psi_i in enumerate(psis):
        for j, psi_j in enumerate(psis):
            k[i, j] = np.trapezoid(np.conjugate(psi_i) * h2 * psi_j, omega)
    return k


def fractal_resonator_network(
    f0_hz: float,
    levels: int,
    scale_ratio: float,
    q_base: float,
    gain_per_branch_db: float = 0.0,
    topology: str = 'parallel',
    active_gain_db: float = 0.0,
    delay_step_s: float = 0.0,
    normalize_peak: bool = False,
) -> NetworkSpec:
    branches = []
    for ell in range(levels):
        f = f0_hz * scale_ratio ** ell
        # modestly decrease Q at high levels to imitate additional distributed loss.
        q = max(q_base / (1.0 + 0.08 * ell), 1.0)
        gain = 10.0 ** (gain_per_branch_db / 20.0)
        # deterministic mycelial phase/weight pattern: stable and testable.
        phase = (ell * 2.399963229728653) % (2.0 * np.pi)
        weight = np.exp(1j * phase) / np.sqrt(levels) if topology == 'parallel' else 1.0 + 0.0j
        branches.append(
            ResonatorBranch(
                name=f'L{ell}_f{f:.6g}',
                omega0=2.0 * np.pi * f,
                q=q,
                gain_linear=gain,
                delay_s=ell * delay_step_s,
                weight=weight,
            )
        )
    return NetworkSpec(tuple(branches), topology=topology, active_gain_db=active_gain_db, normalize_peak=normalize_peak)


def bodes_tristan_analysis(
    omega: np.ndarray,
    network: NetworkSpec,
    packets: Sequence[WavePacket],
) -> dict:
    h = network.response(omega)
    metrics = [packet_metrics(omega, h, p) for p in packets]
    k = coherence_matrix(omega, h, packets)
    eigvals = np.linalg.eigvalsh((k + k.conjugate().T) / 2.0)
    offdiag_norm = float(np.linalg.norm(k - np.diag(np.diag(k))))
    diag_norm = float(np.linalg.norm(np.diag(np.diag(k))))
    return {
        'network': network.as_dict(),
        'packets': [p.as_dict() for p in packets],
        'packet_metrics': metrics,
        'coherence_matrix_real': np.real(k).tolist(),
        'coherence_matrix_imag': np.imag(k).tolist(),
        'coherence_eigenvalues': eigvals.tolist(),
        'coherence_offdiag_over_diag': offdiag_norm / max(diag_norm, 1e-300),
        'frequency_grid': {
            'omega_min_rad_s': float(np.min(omega)),
            'omega_max_rad_s': float(np.max(omega)),
            'points': int(len(omega)),
        },
    }
