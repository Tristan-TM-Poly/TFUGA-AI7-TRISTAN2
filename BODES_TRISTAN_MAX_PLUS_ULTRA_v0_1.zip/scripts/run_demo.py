#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from bodes_tristan import WavePacket, fractal_resonator_network, bodes_tristan_analysis


def main() -> int:
    out = ROOT / 'outputs'
    out.mkdir(exist_ok=True)
    results = ROOT / 'results'
    results.mkdir(exist_ok=True)

    f_min, f_max = 1e4, 2e9
    omega = 2 * np.pi * np.logspace(np.log10(f_min), np.log10(f_max), 9000)

    # Demo: five-level RF/MHz/GHz fractal packet-aware Bode network.
    network = fractal_resonator_network(
        f0_hz=2e6,
        levels=7,
        scale_ratio=3.0,
        q_base=65,
        gain_per_branch_db=0.0,
        topology='parallel',
        active_gain_db=24.0,
        delay_step_s=0.25e-9,
        normalize_peak=True,
    )
    packets = [
        WavePacket('P1_2MHz_narrow', 2*np.pi*2e6, 2*np.pi*0.08e6, amplitude=1+0j),
        WavePacket('P2_18MHz_medium', 2*np.pi*18e6, 2*np.pi*0.8e6, amplitude=0.9+0j, phase=0.3),
        WavePacket('P3_162MHz_wide', 2*np.pi*162e6, 2*np.pi*9e6, amplitude=0.7+0j, phase=1.1),
        WavePacket('P4_486MHz_probe', 2*np.pi*486e6, 2*np.pi*18e6, amplitude=0.5+0j, phase=2.0),
    ]
    analysis = bodes_tristan_analysis(omega, network, packets)
    (out / 'bodes_tristan_demo_analysis.json').write_text(json.dumps(analysis, indent=2), encoding='utf-8')

    # CSV summary
    rows = analysis['packet_metrics']
    header = list(rows[0].keys())
    with (out / 'packet_metrics.csv').open('w', encoding='utf-8') as f:
        f.write(','.join(header) + '\n')
        for row in rows:
            f.write(','.join(str(row[k]) for k in header) + '\n')

    h = network.response(omega)
    f_hz = omega / (2*np.pi)
    gain_db = 20*np.log10(np.maximum(np.abs(h), 1e-300))
    phase = np.unwrap(np.angle(h))
    tau_g = -np.gradient(phase, omega, edge_order=2)

    fig = plt.figure(figsize=(10, 5.5))
    plt.semilogx(f_hz, gain_db)
    for p in packets:
        plt.axvline(p.omega0/(2*np.pi), linestyle='--', linewidth=0.8)
    plt.xlabel('Frequency [Hz]')
    plt.ylabel('|H| [dB]')
    plt.title('Bodes-Tristan demo: fractal packet-aware transfer gain')
    plt.grid(True, which='both', alpha=0.3)
    fig.tight_layout()
    fig.savefig(results / 'bt_gain_response.png', dpi=180)
    plt.close(fig)

    fig = plt.figure(figsize=(10, 5.5))
    plt.semilogx(f_hz, tau_g * 1e9)
    for p in packets:
        plt.axvline(p.omega0/(2*np.pi), linestyle='--', linewidth=0.8)
    plt.xlabel('Frequency [Hz]')
    plt.ylabel('Group delay [ns]')
    plt.title('Bodes-Tristan demo: group delay')
    plt.grid(True, which='both', alpha=0.3)
    fig.tight_layout()
    fig.savefig(results / 'bt_group_delay.png', dpi=180)
    plt.close(fig)

    k = np.array(analysis['coherence_matrix_real']) + 1j*np.array(analysis['coherence_matrix_imag'])
    fig = plt.figure(figsize=(6, 5.5))
    plt.imshow(np.abs(k), origin='lower')
    plt.colorbar(label='|K_out|')
    plt.xticks(range(len(packets)), [p.name.split('_')[0] for p in packets])
    plt.yticks(range(len(packets)), [p.name.split('_')[0] for p in packets])
    plt.title('Bodes-Tristan coherence/gain matrix')
    fig.tight_layout()
    fig.savefig(results / 'bt_coherence_matrix.png', dpi=180)
    plt.close(fig)

    report_lines = [
        '# Bodes-Tristan demo result',
        '',
        f"Network topology: `{network.topology}` with {len(network.branches)} fractal branches and {network.active_gain_db:.1f} dB active gain.",
        '',
        '| Packet | f0 [Hz] | sigma_f [Hz] | min_dt [s] | gain [dB] | tau_g mean [s] | distortion proxy |',
        '|---|---:|---:|---:|---:|---:|---:|',
    ]
    for m in rows:
        report_lines.append(
            f"| {m['name']} | {m['f0_hz']:.6g} | {m['sigma_f_hz']:.6g} | {m['delta_t_min_s']:.6e} | {m['gain_db']:.3f} | {m['group_delay_mean_s']:.6e} | {m['distortion_proxy']:.6g} |"
        )
    report_lines += [
        '',
        f"Coherence offdiag/diag ratio: `{analysis['coherence_offdiag_over_diag']:.6g}`.",
        '',
        'Files generated:',
        '- `outputs/bodes_tristan_demo_analysis.json`',
        '- `outputs/packet_metrics.csv`',
        '- `results/bt_gain_response.png`',
        '- `results/bt_group_delay.png`',
        '- `results/bt_coherence_matrix.png`',
    ]
    (out / 'DEMO_REPORT.md').write_text('\n'.join(report_lines), encoding='utf-8')
    print(json.dumps({'ok': True, 'analysis': str(out/'bodes_tristan_demo_analysis.json'), 'packets': len(packets)}, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
