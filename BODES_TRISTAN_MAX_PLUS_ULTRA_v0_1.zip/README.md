# BODES_TRISTAN_MAX_PLUS_ULTRA_v0_1

Bodes-Tristan est un prototype de lieu de Bode generalise pour paquets d'ondes, multi-paquets, reseaux fractals LC/RF/THz/optiques, et hypergraphes myceliens.

## Installation rapide

```bash
python -m pip install numpy matplotlib pytest
```

## Lancer la demo

```bash
python scripts/run_demo.py
```

Sorties:

- `outputs/bodes_tristan_demo_analysis.json`
- `outputs/packet_metrics.csv`
- `outputs/DEMO_REPORT.md`
- `results/bt_gain_response.png`
- `results/bt_group_delay.png`
- `results/bt_coherence_matrix.png`

## Lancer les tests

```bash
python -m pytest tests
```

## Ce que ce pack fait

- definit des paquets gaussiens avec largeur temporelle/frequentielle;
- construit des reseaux de resonateurs fractals en serie ou parallele;
- calcule gain par paquet, delai de groupe, dispersion proxy, distorsion proxy;
- construit la matrice de coherence/gain `K_out` pour n paquets;
- donne un premier cadre de score et promotion AI-7.

## Ce que ce pack ne pretend pas encore

- pas une preuve physique finale;
- pas une promesse d'amplification passive illimitee;
- pas un solveur EM/FDTD complet;
- pas un modele bruit/thermique/saturation complet.

Statut: branche cristallisable pilote, non canonique.
